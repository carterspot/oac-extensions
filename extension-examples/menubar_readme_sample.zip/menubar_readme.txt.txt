The Menu Bar.
**** import the provided .zip file into the console > extensions of OAC.
**** create a visualization
**** specify The Menu Bar plugin and drag onto the canvas.
**** use the provided samplemenu.json in the configuration string properties 