define(['jquery',
    'knockout',
    'ojs/ojcore',
    'obitech-framework/jsx',
    "obitech-application/extendable-ui-definitions",
    'obitech-application/bi-definitions',
    'obitech-framework/actioncontext',
    "obitech-appservices/contextmenumanager",
    'obitech-appservices/logger',
    'obitech-report/reportnode',
    'obitech-appservices/events',
    'obitech-report/datavisualization',
    'obitech-report/visualization',
    'obitech-report/parameterutils',
    "obitech-reportservices/parameterdefinitions",
    'obitech-reportservices/datamodelshapes',
    'obitech-application/gadgets',
    'obitech-report/gadgetdialog',
        'ojL10n!com-company-ogldataviz/nls/messages',
        'obitech-framework/messageformat',
        'skin!css!com-company-ogldataviz/oglDatavizstyles'],
    function ($,
        ko,
        oj,
        jsx,
        euidef,
        definitions,
        actioncontext,
        contextmenu,
        logger,
        reportnode,
        events,
        dataviz,
        viz,
        parameterutils,
        parameterdefinitions,
        datamodelshapes,
        gadgets,
        gadgetdialog,
                 messages) {
   "use strict";

   var MODULE_NAME = 'com-company-ogldataviz/oglDataviz';

   //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   jsx.assertAllNotNullExceptLastN(arguments, "oglDataviz.js arguments", 2);

   var _logger = new logger.Logger(MODULE_NAME);

   // The version of our Plugin
   OglDataviz.VERSION = "1.0.0";

   /**
    * The implementation of the oglDataviz visualization.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @extends {module:obitech-report/visualization.Visualization}
    * @memberof module:com-company-ogldataviz/oglDataviz#
    */
   function OglDataviz(sID, sDisplayName, sOrigin, sVersion) {
      // Argument validation done by base class
       OglDataviz.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);
       this.loadConfig = function () {

           var oConfig = this.getVizSpecificViewConfigSettingJSON() || {};
           var oConf = oConfig.Settings || {};
       }
   };
   jsx.extend(OglDataviz, dataviz.DataVisualization);
   /**
    * Called whenever new data is ready and this visualization needs to update.
    * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
    */

        OglDataviz.prototype._generateData = function (oDataLayout, oTransientRenderingContext) {
            var oDataModel = this.getRootDataModel();
            if (!oDataModel || !oDataLayout) {
                return;
            }
           var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
            var nRowLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
            var oDataLayoutHelper = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT_HELPER);
            var outputMap = [];
 
            for (var nRow = 0; nRow < Math.max(nRows, 1); nRow++) {
                var row = "", name = "";
                for (var nRowLayer = 0; nRowLayer < Math.max((nRowLayerCount - 1), 1); nRowLayer++) {
                  var rowType = oDataLayoutHelper.getLogicalEdgeName(datamodelshapes.Physical.ROW, nRowLayer);
                    
                    switch (rowType) {
                        case "row":
                            var name = row != "" ? row + ", " + oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false)
                                : oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                            outputMap.push(name);
                            break;
                    }
                }
            }
            return outputMap;
        }

   OglDataviz.prototype.render = function(oTransientRenderingContext) {
       try {
           var self = this;
          var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
          var oData = this._generateData(oDataLayout, oTransientRenderingContext);
          var oConfig = self.getVizSpecificViewConfigSettingJSON() || {};
           var oConf = oConfig.Settings || {};
           self.loadConfig();
          var elContainer = this.getContainerElem();

          if (!oConf.AppID) {
              var oMsgComponentManager = this.getService(definitions.MessageComponentManager_SERVICE_NAME);
              oMsgComponentManager.displayMessage(this, {
                  message: "Provide App ID to launch OGL",
                  type: definitions.MessageTypeStyles.WARNING,
                  //    type: definitions.MessageTypeStyles.INFO,
                  isInline: false,
                  closeTimeout: 30000,
                  position: {
                      my: "center top-50",
                      at: "center top",
                      of: $(this.getContainerElem()),
                      collision: "fit flip"
                  }
              });
          }

         
          var AppID, OGL_Server;

          if (oConf.AppID) {
              AppID = parameterutils.resolveParameterValuesInText(this, oConf.AppID, parameterdefinitions.ParameterContext.TEXT);
          }
          OGL_Server = parameterutils.resolveParameterValuesInText(this, oConf.OGL_Server || 'https://guidedlearning.oracle.com', parameterdefinitions.ParameterContext.TEXT);
          var username = oData[0];
          if (AppID != null && OGL_Server != null) {

              window.iridize = window.iridize || function (e, t, n) { return iridize.api.call(e, t, n); };
              iridize.api = iridize.api || { q: [], call: function (e, t, n) { iridize.api.q.push({ method: e, data: t, callback: n }); } };
              iridize.appId = AppID;
              /*FOR YOUR DEV OR STAGING ENVIRONMENTS PLEASE UNCOMMENT THE NEXT LINE*/
              iridize.env = "dev";   // remove this line during production  CHECK WITH PL
              iridize.autoSegmentation = true;
              iridize.routing = { type: 'naive' }
              /*TO ENABLE USER CONDITIONS UNCOMMENT THE NEXT LINE.
              Add as many fields as you would like (e.g. user_role, user_name, etc.) */
              iridize("api.fields.set", {user_id: username});
              var e = document.createElement("script");
              var t = document.body;
              iridize.useSessionStorage = true
              e.src = OGL_Server + "/player/latest/static/js/iridizeLoader.min.js";
              e.type = "text/javascript"; e.async = true; t.appendChild(e);

          };
      }
      finally {
         this._setIsRendered(true);
      }
    };

   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the visualization
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {string=} sVersion 
    * @returns {module:com-company-ogldataviz/oglDataviz.OglDataviz}
    * @memberof module:com-company-ogldataviz/oglDataviz
    */

        /**
             * Resize the visualization
             * @param {Object} oVizDimensions - contains two properties, width and height
             * @param {module:obitech-report/vizcontext#VizContext} oTransientVizContext the viz context
             */
        OglDataviz.prototype.resizeVisualization = function (oVizDimensions, oTransientVizContext) {
            var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
            this.render(oTransientRenderingContext);
        };


        OglDataviz.prototype._onDefaultSettingsChanged = function () {

            var oTransientVizContext = this.assertOrCreateVizContext();
            var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
            this.render(oTransientRenderingContext);
            this._setIsRendered(true);
        };

        /**
               * Override to add in options to the context menu
               *
               * @param {module:obitech-report/vizcontext#VizContext} oTransientVizContext the viz context
               * @param {string} sMenuType The menu type associated with the context menu being populated
               * @param {Array} The array of resulting menu options
               * @param {module:obitech-appservices/contextmenu} contextmenu The contextmenu namespace object (used to reduce dependencies)
               * @param {object} evtParams The entire 'params' object that is extracted from client evt
               * @param {object} oTransientRenderingContext the current transient rendering context
               */

        OglDataviz.prototype._addVizSpecificPropsDialog = function (oTabbedPanelsGadgetInfo) {
            OglDataviz.superClass._addVizSpecificPropsDialog.call(this, oTabbedPanelsGadgetInfo);
        };
        /**
           * TODO: Legend should take care of this
           * Given an options / config object, configure it with default options for the visualization.
           *
           * @param {object} oOptions the options
           * @param {module:obitech-framework/actioncontext#ActionContext} oActionContext The ActionContext instance associated with this action
           * @protected
           */

        OglDataviz.prototype._addVizSpecificMenuOptions = function (oTransientVizContext, sMenuType, aResults, contextmenu, evtParams, oTransientRenderingContext) {
            aResults.shift();

            OglDataviz.superClass._addVizSpecificMenuOptions.call(this, oTransientVizContext, sMenuType, aResults, contextmenu, evtParams, oTransientRenderingContext);
            if (sMenuType === euidef.CM_TYPE_VIZ_PROPS) {

                // Set up the column context for the last column in the ROWS bucket
                var oColumnContext = this.getDrillPathColumnContext(oTransientVizContext, datamodelshapes.Logical.ROW);
                var hasselections = (this.getSelectedItems && this.getSelectedItems().size > 0);  // only when something is selected - remove and keep selected gets listed in the context menu
                // Set up events
                if (!this.isViewOnlyLimit() && hasselections) {

                    this._addFilterMenuOption(oTransientVizContext, aResults, null, null, oTransientRenderingContext);
                    this._addRemoveSelectedMenuOption(oTransientVizContext, aResults, null, null, oTransientRenderingContext);
                }

            }
        };

        OglDataviz.prototype.getCurrentViewConfigVersion = function () {
            return "1.0.0";
        };

        OglDataviz.prototype._addVizSpecificPropsDialog = function (oTabbedPanelsGadgetInfo) {

            OglDataviz.superClass._addVizSpecificPropsDialog.call(this, oTabbedPanelsGadgetInfo);
            var oGadgetFactory = this.getGadgetFactory();
            var oConfig = this.getVizSpecificViewConfigSettingJSON() || {};
            var oConf = oConfig.Settings || {};

         //   var oConf = this.getVizSpecificViewConfigSettingJSON() || {};

            var oGeneralPanel = gadgetdialog.forcePanelByID(oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_GENERAL);
            oGeneralPanel.setBodyCSSClass("bi_gadgets_no_cell_separator");
            var nOrder = euidef.GD_FIELD_ORDER_GENERAL_VIZ_SPECIFIC;

            //   var oGadgetValueProperties = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_AREA, oConf.AppID || 'E6HJFuVUTkW9ka4I2vyatg');
            var oGadgetValueProperties = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, oConf.AppID);
            var sGadgetId = "Set_Values";
            nOrder += 1;
            var oGadgetInfo = oGadgetFactory.createGadgetInfo(sGadgetId, "App ID", "Add text", oGadgetValueProperties, nOrder);
            oGeneralPanel.addChild(oGadgetInfo);

            var oGadgetValueProperties = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, oConf.OGL_Server || 'https://guidedlearning.oracle.com');
            //     var oGadgetValueProperties = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_AREA, oConf.OGL_Server);
            var sGadgetId = "OGLServer";
            var sGadgetId = "OGLServer";
            nOrder += 1;
            var oGadgetInfo = oGadgetFactory.createGadgetInfo(sGadgetId, "OGL Server", "Add text", oGadgetValueProperties, nOrder);
            oGeneralPanel.addChild(oGadgetInfo);

        };

        OglDataviz.prototype._handlePropChange = function (sGadgetID, oPropChange, oViewSettings, oActionContext) {
            jsx.assertString(sGadgetID, 'sGadgetID');
            jsx.assertObject(oPropChange, 'oPropChange');
            jsx.assertObject(oViewSettings, 'oViewSettings');
            jsx.assertInstanceOf(oActionContext, actioncontext.ActionContext, "oActionContext", "actioncontext.ActionContext");

            //Allow the super class an attempt to handle the changes
            var bUpdateSettings = OglDataviz.superClass._handlePropChange.call(this, sGadgetID, oPropChange, oViewSettings, oActionContext);
            //     var conf = oViewSettings.getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
            var oConfig = this.getVizSpecificViewConfigSettingJSON() || {};
            var oConf = oConfig.Settings || {};
            if (!bUpdateSettings) {
                switch (sGadgetID) {
                    case "Set_Values":
                        if (!jsx.isNull(oPropChange.value)) {
                     //       this.setVizSpecificViewConfigSetting(oViewSettings, "AppID", oPropChange.value);
                            oConf.AppID = oPropChange.value;
                            this.setVizSpecificViewConfigSetting(oViewSettings, "Settings", oConf);
                            //     this.setAppID(oPropChange.value);
                            bUpdateSettings = true;
                        }
                        break;
                    case "OGLServer":
                        if (!jsx.isNull(oPropChange.value)) {
                            this.setVizSpecificViewConfigSetting(oViewSettings, "OGL_Server", oPropChange.value);
                            //       this.setOGL_Server(oPropChange.value);
                            bUpdateSettings = true;
                        }
                        break;
                }
            }
            //if (bUpdateSettings) {
            //    this.refreshPropertiesDialog();
            //    this.render();
            //}
            return bUpdateSettings;
        };
   function createClientComponent(sID, sDisplayName, sOrigin) {
     // Argument validation done by base class
      return new OglDataviz(sID, sDisplayName, sOrigin, OglDataviz.VERSION);
   };

   return {
      createClientComponent : createClientComponent
   };
});