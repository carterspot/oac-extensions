define({
    "OGLDATAVIZ_DISPLAY_NAME": "OGL Plugin",
    "OGLDATAVIZ_SHORT_DISPLAY_NAME": "OGL Plugin",
    "OGLDATAVIZ_CATEGORY":"OGL",
    "OGLDATAVIZ_ROW_LABEL":"User Name (For Usage Tracking)",
    "OGLDATAVIZ_ITEM_SIZE":"Item Size",
    "TEXT_MESSAGE": "Hello!  This is the {0} visualization and I have {1} rows of data."

});