define({
    "CALCMODIFIER_DISPLAY_NAME": "CalcModifier Plugin",
    "CALCMODIFIER_SHORT_DISPLAY_NAME": "CalcModifier Plugin",
    "CALCMODIFIER_CATEGORY":"CalcModifier Plugin",
    "CALCMODIFIER_ROW_LABEL":"CalcModifier Plugin Row",
    "CALCMODIFIER_ITEM_SIZE":"Item Size",
    "TEXT_MESSAGE": "Hello!  This is the {0} visualization and I have {1} rows of data."

});