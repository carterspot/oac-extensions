define(['jquery',
        'obitech-framework/jsx',
        'obitech-report/visualization',
        'obitech-appservices/logger',
        'ojL10n!com-company-calcModifier/nls/messages',
        'obitech-framework/messageformat',
        'skin!css!com-company-calcModifier/calcModifierstyles'],
        function($,
                 jsx,
                 visualization,
                 logger,
                 messages) {
   "use strict";

   var MODULE_NAME = 'com-company-calcModifier/calcModifier';

   //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   //jsx.assertAllNotNullExceptLastN(arguments, "calcModifier.js arguments", 2);

   var _logger = new logger.Logger(MODULE_NAME);

   // The version of our Plugin
   CalcModifier.VERSION = "1.0.0";   

   /**
    * The implementation of the calcModifier visualization.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @extends {module:obitech-report/visualization.Visualization}
    * @memberof module:com-company-calcModifier/calcModifier#
    */
	
   function CalcModifier(sID, sDisplayName, sOrigin, sVersion) {
      // Argument validation done by base class
      CalcModifier.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);
   };
   jsx.extend(CalcModifier, visualization.Visualization);
   
   CalcModifier.prototype.getVarsList = function (){
		var aExprArray = this.buildExprArray();
		var varValues = [];
		for (var i=0; i<aExprArray.length; i++){
			var myString = aExprArray[i].expr; //"something @{format}{this}_abc@{another}{}";
			var myRegexp = /@{([^}]*)}{([^}]*)}/g;
			var match = myRegexp.exec(myString);
			while (match != null) {
			  var name=match[1], value=match[2], present=false;
			  for(var j=0; j < varValues.length; j++) { 
				if(varValues[j].name==name) { present=true; break;} 
			  }
			  if (!present)	
				varValues.push({"name":name, "value": value});
			  match = myRegexp.exec(myString);
			}
		}
		return varValues;
	}
	
	CalcModifier.prototype.buildExprArray = function (){
		var outArray = [];
		var reportJSON = this.getReportManager().getReportJSON(); 
		/*Column object structure -
				"columnID": "test",
				"userExpression": true,
				"type": "saw:regularColumn",
				"columnFormula": {
				  "expr": {
					"children": [],
					"type": "sawx:sqlExpression",
					"expression": "'joe_test'"
				  }
				}
		*/
		var aExprArray=[];
		var objs = reportJSON.criteria.columns.children;
		
		for (var t =0; t<objs.length; t++)
			if (objs[t].userExpression)
				aExprArray.push(objs[t]);
		
		for (var i=0; i<aExprArray.length; i++){
			 var e = aExprArray[i];
			 outArray.push ({
				columnName: e.columnHeading.caption.text,
				columnID:e.columnID, 
				expr: e.columnFormula.expr.expression
			 });
		}
		return outArray;
	}
	
	CalcModifier.prototype.getCalcsTobeModified = function (aExprArray, sVarName){
		var modList = [];
		for (var i=0; i<aExprArray.length; i++){
			 var e = aExprArray[i];
			 if(e.expr.indexOf('@{'+sVarName+'}')!=-1) {
				 modList.push(aExprArray[i]);				 
			 }
		 }
		 return modList;
	}
	
	function sleep(milliseconds) {
	  var start = new Date().getTime();
	  for (var i = 0; i < 1e7; i++) {
		if ((new Date().getTime() - start) > milliseconds){
		  break;
		}
	  }
	}

	CalcModifier.prototype.setVariable = function (sVarName, sVarValue){
		var aExprArray = this.buildExprArray();
		var modList = this.getCalcsTobeModified(aExprArray, sVarName);		
		
		if (modList.length>0) {
			var r = "@{"+ sVarName + "}{[^}]*}";
			var regex = new RegExp(r,"g");  
			var toval = "@{"+ sVarName + "}{" + sVarValue + "}";
			var j = 0;
			var oViz = this;
			var i = setInterval(function(){
				var sColumnId = modList[j].columnID;
				var sName = modList[j].columnName;
				var expr = modList[j].expr;
				var sNewExpr = expr.replace(regex, toval);
				var oExprMngr = oViz.getReportContext().getExpressionManager()
				oExprMngr.saveUserExpressionColumn(sName, sNewExpr, sColumnId);

				j++;
				console.log('Modifying Calc:  ' + sName);
				if(j === modList.length) {
					clearInterval(i);
				}
			}, 800);
		}
		
		
	}
	
   CalcModifier.prototype.render = function(oTransientRenderingContext) {
      try {
         // Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
         // but may be used to render.
         var root = this.getContainerElem();
         $(root).html("<div align=left style='padding:15px;' >\
				 <div id=novardiv>No variables were found in any calculations! \
				 <br><br>Add variables to your calculations and select refresh viz button.\
				 <br>Variable syntax: <font color=grey>@{MyVar}{10}</font>. \
				 Example calculation: <font color=grey>Sales * CAST('@{MyVar}{10}' as double)</font>\
				 <br><br><button id=refreshviz1>Refresh Viz</button><br></div> \
				 <div id=vardiv>\
				 Select Variable: <select id='vardropdwn' style='width:120px'/>\
				 &nbsp;<span class='help-tip'>\
				 <p>This is a listing of variables in your calculations. Variable syntax: <font color=grey>@{MyVar}{10}</font> \
				 <br/>Example calculation: <font color=grey>Sales * CAST('@{MyVar}{10}' as double)</font></p></span>&nbsp;\
				 &nbsp;&nbsp;<button id=refreshviz2>Refresh</button>\
				 <br/>Current value: <b><span id='varcurrvalue'></span></b><br><br>\
				 Target Values (eg. 10,20): <input id='varvalue' type='text' style='width:80px'>\
				 &nbsp;&nbsp;<button id=setexpr>Update</button></div><br><br>\
			 </div>");

			 //<hr style='display: block;margin-top: 0.5em;margin-bottom: 0.5em;border-style: inset;border-width: 1px;' />
			 
		 var eCurrValue = $(root).find("#varcurrvalue");
		 var eVarValue = $(root).find("#varvalue");
		 var eVarlist = $(root).find("#vardropdwn");
		 var eSetExprBtn = $(root).find("#setexpr");		 
		 var eRefreshViz1 = $(root).find("#refreshviz1");
		 var eRefreshViz2 = $(root).find("#refreshviz2");
		 var sVarName = null, sVarValue = null;	
		 var oViz = this;		 
		 
		 var populateList = function(){
			 if(typeof oViz.valIdx == 'undefined') 
				 oViz.valIdx=0;
			 
			 if(typeof oViz.sVarValue == 'undefined') {
				 oViz.sVarValue='';
			 } else {
				 $(eVarValue).val(oViz.sVarValue);
			 }		 
			 
			 var varsArray = oViz.getVarsList();
			 if(varsArray.length==0){
				$(root).find("#novardiv").show();
				$(root).find("#vardiv").hide();
			 } else {
				 $(root).find("#novardiv").hide();
				 $(root).find("#vardiv").show();
				 $(eVarlist).empty();
				 $.each(varsArray, function (i, item) {
					$(eVarlist).append($('<option>', { 
						value: item.value,
						text : item.name 
					}));
				 });
					
				 sVarValue = $(eVarlist).val();
				 sVarName = $(eVarlist).find(':selected').text();
				 if (sVarValue)
					eCurrValue.html('<b>'+sVarValue+'</b>');
			 }
		 };
		 
		 populateList();
		 
		 $(eVarlist).on('change', function() {
			 sVarValue = $(eVarlist).val();
			 sVarName = $(eVarlist).find(':selected').text();
			 eCurrValue.html('<b>'+sVarValue+'</b>');
			 oViz.valIdx = 0;
		 });
		 
		 $(eVarValue).on('input', function() {
			 oViz.valIdx = 0;
		 });		 
			
		 $(eSetExprBtn).click(function(){			
			var valList = '' + $(eVarValue).val();
			oViz.sVarValue = valList;
			if (valList == '') return;
			
			var valArray = valList.split(',');			
			if (oViz.valIdx > valArray.length - 1) 
				oViz.valIdx = 0; 
			
			sVarName = $(eVarlist).find(':selected').text();
			var newval = valArray[oViz.valIdx];
			oViz.setVariable(sVarName, newval);
			eCurrValue.html('<b>'+newval+'</b>');
			oViz.valIdx = oViz.valIdx + 1;
		 });
		 
		 $(eRefreshViz1).click(function(){
			populateList();
		 });
		 
		  $(eRefreshViz2).click(function(){
			populateList();
		 });
	 }
      finally {
         this._setIsRendered(true);
      }
    };

    CalcModifier.prototype.resizeVisualization = function(oVizDimensions, oTransientVizContext){
		var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
		this.render(oTransientRenderingContext);
	};
	
   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the visualization
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {string=} sVersion 
    * @returns {module:com-company-calcModifier/calcModifier.CalcModifier}
    * @memberof module:com-company-calcModifier/calcModifier
    */
   function createClientComponent(sID, sDisplayName, sOrigin) {
     // Argument validation done by base class
      return new CalcModifier(sID, sDisplayName, sOrigin, CalcModifier.VERSION);
   };

   return {
      createClientComponent : createClientComponent
   };
});