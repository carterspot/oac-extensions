define(['jquery',
    'obitech-framework/jsx',
    'obitech-report/datavisualization',
    'obitech-reportservices/datamodelshapes',
    'obitech-reportservices/data',
    'd3js',
    'obitech-reportservices/events',
    'obitech-reportservices/interactionservice',
    'obitech-appservices/logger',
    'ojL10n!com-company-forceDirectedGraph/nls/messages',
    'obitech-framework/messageformat',
    'skin!css!com-company-forceDirectedGraph/forceDirectedGraphstyles'],
        function($,
                jsx,
                dataviz,
                datamodelshapes,
                data,
                d3,
                events,
                interactions,
                logger,
                messages) {
   "use strict";

   var MODULE_NAME = 'com-company-forceDirectedGraph/forceDirectedGraph';

   //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   jsx.assertAllNotNullExceptLastN(arguments, "forceDirectedGraph.js arguments", 2);

   var _logger = new logger.Logger(MODULE_NAME);

   // The version of our Plugin
   forceDirectedGraph.VERSION = "1.0.0";


   /**
    * The implementation of the forceDirectedGraph visualization.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @extends {module:obitech-report/visualization.Visualization}
    * @memberof module:com-company-forceDirectedGraph/forceDirectedGraph#
    */
   function forceDirectedGraph(sID, sDisplayName, sOrigin, sVersion) {
      // Argument validation done by base class
      forceDirectedGraph.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);
   };
   jsx.extend(forceDirectedGraph, dataviz.DataVisualization);
   
   //for storing variables for bug checking and use in other parts of code
   forceDirectedGraph.prototype._varStore=function(){
	   var main=this;
	   main.SVG={};
	   main.data={};
   }
   /**
    * Called whenever new data is ready and this visualization needs to update.
    * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
    */
   forceDirectedGraph.prototype._render = function(oTransientRenderingContext) {
      try {
         // Note: all events will be received after initialize and start complete.  We may get other events
         // such as 'resize' before the render, i.e. this might not be the first event.

         // Retrieve the data object for this visualization
         var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
        
         
         // Determine the number of records available for rendering on ROW
         // Because we specified that Category should be placed on ROW in the data model handler,
         // this returns the number of rows for the data in Category.
         //var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);

         // Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
         // but may be used to render.
         var elContainer = this.getContainerElem();
      // Lets track our visualization for function calls where the 'this' context changes
         var oViz = this;
         
         var myOptions = new oViz._varStore;
         
         var aCircles,aTextNodes;
      // Let's reset our container on render
         $(elContainer).addClass("forceDirectedGraphRootContainer");
         var sVizContainerId = this.getSubElementIdFromParent(this.getContainerElem(), "hvc");
         $(elContainer).html ("<div id=\"" + sVizContainerId + "\" class=\"forceDirectedGraphContainer\" />");
         var elVizContainer = document.getElementById(sVizContainerId); 
          
         // Get the width and height of our container
         var nWidth = $(elContainer).width();
         var nHeight = $(elContainer).height();
         // Calculate our margin and diameter
         var nMargin = 15,
            nDiameter = Math.min(nWidth, nHeight);
          
         var fFormat = d3.format(",d");
         var fColor = d3.scale.linear()
            .domain([-1, 5])
            .range(["hsl(198, 84%, 61%)", "hsl(230,31%,42%)"])
            .interpolate(d3.interpolateHcl);
         
         var oSVG = d3.select(elVizContainer).append("svg") 
            .attr("width", nWidth)
            .attr("height", nHeight)
            .append("g")
            .attr("transform", "translate(" + nWidth / 2 + "," + nHeight / 2 + ")");
          
			
         var oData = this._generateData(oDataLayout,myOptions);
         if(!oData) {
            return;
         } 
         
         
         
         var fRenderData = function(oData) {
            var oFocus = oData,
            oView;
            
            
         
           //create force directed layout 
            var force = d3.layout.force()
            .linkDistance(25)
            .charge(-120)
            .gravity(.05)
            .size([nWidth/2, nHeight/2])
            .on("tick", tick);
            
            var drag = force.drag()
            .on("dragstart", dragstart)
            .on("dragend",dragend);
            
            var link = oSVG.selectAll(".link"),
            node = oSVG.selectAll(".VSSnode");
            
            //data for layout
            var root =oData;
            
            //array for max/min by level
            var rval=[];
            
            //function for max/min array population
            function small(obj,rval){
					if(obj.hasOwnProperty('children')==false){
						rval.push({level:obj.level,size:obj.size}); 
					}
					else
					{var childCount=obj.children.length;
						obj.children.forEach(
					function(x){ x.levelCount=childCount;
					rval.push({level:x.level,size:x.size}); 
						 return small(x,rval)
					})
					} 
				
			}
            
            //pop max/min array
            small(oData,rval)
            
            console.log('test')
            console.log(oData)
            
            myOptions.data.layerRval=[];
            
            for(var ii=0;ii<myOptions.data.layerCount-1;ii++){
            	myOptions.data.layerRval.push(
            	{layer:ii,lMin:rval.filter(function(lay){return lay.level==ii;}).reduce(function(prev, current) {
            		return (prev.size < current.size) ? {size:prev.size} : {size:current.size}
            	}).size,lMax:rval.filter(function(lay){return lay.level==ii;}).reduce(function(prev, current) {
    				
            		return (prev.size > current.size) ? {size:prev.size} : {size:current.size}
            	}).size
            	})
            }
            	
            console.log(myOptions)
           
        	
        	var rMin=10, rMax=30;
            
            start();
            
            var nodes,links;
            
            function start(){
            	nodes = flatten(root),
            	links = d3.layout.tree().links(nodes);
            	for(var i=0; i<nodes.length; i++){
            		if(nodes[i].levelDisplayDefault<=nodes[i].level){
            			nodes[i]._children = nodes[i].children;
            			nodes[i].children = null;;
            		}
            		if(nodes[i].name=='root'){
            			nodes[i].fixed=true;
            			nodes[i].x=0;
            			nodes[i].y= 0;
            			nodes[i].px=0;
            			nodes[i].py= 0;
            		}
            	}
            	restart();
            }

            function restart(){update();}
            
            function update() {
            	nodes = flatten(root),
                links = d3.layout.tree().links(nodes);

              // Restart the force layout.
              force
                  .nodes(nodes)
                  .links(links)
                  .charge(function(node) {/*return chargeScale(node.size);})
                   function(node) { */
                	  var lay=myOptions.data.layerRval.filter(function(x){return x.layer==node.level;})
                	  
                	  if(node.name!='root'){return node.charge=d3.scale.linear()
              		    .domain([lay[0].lMin,lay[0].lMax])
            		    .range([-500,-1000])(node.size)}
                	  else{return node.charge=-500;
                	  } 
                	  })
                  .start();

              // Update links.
              link = link.data(links, function(d) { return d.target.id; });

              link.exit().remove();

              link.enter().insert("line", ".VSSnode")
                  .attr("class", "link");

              // Update nodes.
              node = node.data(nodes, function(d) { return d.id; });

              node.exit().remove();
              
              function numberWithCommas (x) {
            	  return parseInt(x).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            	}

              var nodeEnter = node.enter().append("g")
                  .attr("class", "VSSnode")
                  .attr("id",function(d){return 'g_'+d.name;})
                  .on("click", click)
                  .on("dblclick", dblclick)
                  .call(force.drag);

               aCircles=nodeEnter.append("circle")
               .attr("class",function(d){var cStr=''; if(d.fixed==true){cStr+=' fixed ';console.log('happened')}
               return cStr+="VSSnodeShape "+"q"+d.level;
               })
                  .attr("r", function(d) { 
                	  var lay=myOptions.data.layerRval.filter(function(x){return x.layer==d.level;})
                	  if(d.name!='root'){
                		  
                		  var r=d3.scale.linear()
                		    .domain([lay[0].lMin,lay[0].lMax])
                		    .range([rMin,rMax])(d.size);
                		  
                		  if(d.levelDisplayText<d.level){d.renderText=1;}
                		  else if(d.levelDisplayTextCount>=d.levelCount){d.renderText=0;}
                		  
                	
                		  return d.r=r;
            		    }
                	  else{return d.r=rMin;
                	  } 
                	  })
                  .append("title").text(function(d) {return d.columnLabel+': '+d.name+'\n'+d.mLabel+': '+numberWithCommas(d.size)+'\n Level: '+d.level;});
              
               console.log('nodes')
               console.log(nodes)
               
               aTextNodes= nodeEnter.append("text")
                  .text(function(d) { if(d.name!='root'){if(d.renderText==0){return d.name; }}});
               
            }
            
            function tick() {
            	node.attr("cx", function(d) { return d.x = Math.max(-nWidth/2+d.r, Math.min(nWidth/2- d.r, d.x)); })
                .attr("cy", function(d) { return d.y = Math.max(-nHeight/2+d.r, Math.min(nHeight/2 - d.r, d.y)); });
            	
                link.attr("x1", function(d) { return d.source.x; })
                    .attr("y1", function(d) { return d.source.y; })
                    .attr("x2", function(d) { return d.target.x; })
                    .attr("y2", function(d) { return d.target.y; }
                    );

                node.attr("transform", function(d) { return "translate(" + d.x + "," + d.y + ")"; });
              }

            function dblclick(d) {
            	console.log('double click')
            	
                d3.select(this).select('.VSSnodeShape').classed("fixed", d.fixed = false);
            	
            	if (d.children) {
                    d._children = d.children;
                    d.children = null;
                  } else {
                    d.children = d._children;
                    d._children = null;
                  }
                  update();
            	if(d3.select(this).attr("id")=='g_root'){
            		start();
            	}
            	}

            	function dragstart(d) {
            		console.log('dragstart')
        
            	  d3.select(this).select('.VSSnodeShape').classed("fixed", d.fixed = true );
            	}
            	function dragend(d) {
            		console.log('dragend')
            	}
            	
              
              function toggle(d) {
            	  if (d.children) {
            	    d._children = d.children;
            	    d.children = null;
            	  } else {
            	    d.children = d._children;
            	    d._children = null;
            	  }
            	}

              // Toggle children on click.
              function click(d) {
            	  if (d3.event.defaultPrevented) return;
            	  console.log('click')
               
            	  
                if (d.children) {
                  d._children = d.children;
                  d.children = null;
                } else {
                  d.children = d._children;
                  d._children = null;
                }
                update();
              }

              // Returns a list of all nodes under the root.
              function flatten(root) {
                var nodes = [], i = 0;

                function recurse(node) {
                	
                  if (node.children){
                	  if (node.children[0].columnLabel!='LevelDisplayText'&&node.children[0].columnLabel!='LevelDisplayTextCount'&&node.children[0].columnLabel!='LevelDisplayDefault'){
                	  node.children.forEach(recurse);
                	  }
                  }
                  if (!node.id) node.id = ++i;
                  
                  if (node.columnLabel!='LevelDisplayText'&&node.columnLabel!='LevelDisplayTextCount'&&node.columnLabel!='LevelDisplayDefault'){
                	  nodes.push(node);
                  }
                  
                }

                recurse(root);
                return nodes;
              }
            
          
         };
          
         fRenderData(oData);
      }
      finally {
         this._setIsRendered(true);
      }
    };
    
    /**
     * Generate oData object for visualization
     * @param {Object} oDataLayout - contains data object for visualization
     */
    
    forceDirectedGraph.prototype._generateData = function(oDataLayout,myOptions){
    	   var oData = {
    	     "name":     "root",
    	     "columnLabel":"none",
    	     "level": -1,
    	     "bottom":0,
    	     "levelDisplayText":100,
    	     "levelDisplayTextCount":1000,
    	     "levelDisplayDefault":1,
    	     "renderText":1,
    	     "children": []
    	   };
    	    
    	   var oDataModel = this.getRootDataModel();
    	   if(!oDataModel || !oDataLayout){
    	      return;
    	   }
    	   var aAllMeasures = oDataModel.getColumnIDsIn(datamodelshapes.Physical.DATA);
    	   var aAllColumns = oDataModel.getColumnIDsIn(datamodelshapes.Physical.ROW);
    	   myOptions.data.colomnLabels = aAllColumns;
    	   myOptions.data.measureLabels=aAllMeasures;

    	   var nMeasures = aAllMeasures.length;
    	    
    	   var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
    	   var nRowLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
    	   myOptions.data.layerCount=nRowLayerCount;
    	   var nCols = oDataLayout.getEdgeExtent(datamodelshapes.Physical.COLUMN);
    	   var nColLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.COLUMN);
    	   var measureName = aAllMeasures[0];
    	   
    	   // Measure labels layer
    	   var isMeasureLabelsLayer = function (eEdgeType, nLayer) {
    	      return oDataLayout.getLayerMetadata(eEdgeType, nLayer, data.LayerMetadata.LAYER_ISMEASURE_LABELS);
    	   };
    	    
    	   // In the last layer get the data values and colors from this layer
    	   var getLastNonMeasureLayer = function (eEdge) {
    	      var nLayerCount = oDataLayout.getLayerCount(eEdge);
    	      for (var i = nLayerCount - 1; i >= 0; i--) {
    	         if (!isMeasureLabelsLayer(eEdge, i))
    	            return i;
    	      }
    	      return -1;
    	   };
    	    
    	   var nLastEdge = datamodelshapes.Physical.COLUMN; // check column edge first
    	    
    	   var nLastLayer = getLastNonMeasureLayer(datamodelshapes.Physical.COLUMN);
    	   if (nLastLayer < 0) { // if not on column edge look on row edge
    	      nLastEdge = datamodelshapes.Physical.ROW;
    	      nLastLayer = getLastNonMeasureLayer(datamodelshapes.Physical.ROW);
    	   }
    	    
    	   var hasCategoryOrColor = function () {
    	      return nLastLayer >= 0;
    	   };
    	    
    	   function buildTree(oParentNode, eEdgeType, nLayerCount, nLayer, nRowSlice, nColSlice, nParentEndSlice, nTreeLevel) {
    	      if (nLayer === nLayerCount) {
    	         // This is a leaf node on row (category), build column (color) next
    	         if (eEdgeType === datamodelshapes.Physical.ROW) {
    	             buildTree(oParentNode, datamodelshapes.Physical.COLUMN, nColLayerCount, 0, nRowSlice, 0, nCols, nTreeLevel);  
    	         }
    	         return;
    	      }
    	      // Skip measure labels
    	      if (isMeasureLabelsLayer(eEdgeType, nLayer) && hasCategoryOrColor()) {
    	         return buildTree(oParentNode, eEdgeType, nLayerCount, nLayer + 1, nRowSlice, nColSlice, nParentEndSlice, nTreeLevel);
    	      }
    	      var isLastLayer = function () {
    	         return (nLastLayer === -1) || (nLastEdge === eEdgeType && nLastLayer === nLayer);
    	      };
    	      var isDuplicateLayer = function () {
    	         return nLastLayer > -1 &&
    	                eEdgeType === datamodelshapes.Physical.COLUMN;
    	      };
    	       
    	      var nEndSlice;
    	      for (var nSlice = (eEdgeType === datamodelshapes.Physical.COLUMN) ? nColSlice : nRowSlice;
    	               nSlice < nParentEndSlice;
    	               nSlice = nEndSlice) {
    	         nEndSlice = oDataLayout.getItemEndSlice(eEdgeType, nLayer, nSlice) + 1;
    	         var nRowIndex = (eEdgeType === datamodelshapes.Physical.COLUMN) ? nRowSlice : nSlice;
    	         var nColIndex = (eEdgeType === datamodelshapes.Physical.ROW) ? nColSlice : nSlice;
    	          
    	         var nValue = null;
    	         if (isLastLayer()) {
    	            var val = 1; // default to rendering equally sized boxes when there are no measures
    	            var valLabel='None';
    	            if (nMeasures > 0) {
    	               val = oDataLayout.getValue(datamodelshapes.Physical.DATA, nRowIndex, nColIndex, false);
    	               valLabel=measureName;
    	               // Skip no data
    	               if (typeof val !== 'string' || val.length === 0){
    	                  continue;
    	               }
    	            }
    	            nValue = parseFloat(val);
    	            // Skip negative and zero values for now. 
    	            if (nValue <= 0)
    	               continue;
    	         }
    	         var oNode;
    	         // Ensure that the same layer isn't rendered twice in  row (Detail) and column (Color) edge
    	         if (!isDuplicateLayer()) {
    	        	
    	        	 
    	            // Create new node
    	            oNode = {};
    	            oNode.size = 0;
    	            oNode.level=nLayer;
    	            oNode.columnLabel=aAllColumns[nLayer];
    	            oNode.bottom=0;
    	            oNode.renderText=1;
    	            oNode.levelDisplayText=100;
    	            oNode.levelDisplayTextCount=1000;
    	            oNode.levelDisplayDefault=1;
    	            var sId = oDataLayout.getValue(eEdgeType, nLayer, nSlice, true);
    	            oNode.id = (oParentNode.id || '') + '.' + sId;
    	            
    	            oNode.name = oDataLayout.getValue(eEdgeType, nLayer, nSlice, false);
    	            
    	            if (isLastLayer()){
    	            	oNode.size = nValue;
    	            	oNode.bottom=1;
    	            	oNode.mLabel=valLabel;
    	            }
    	           
    	            if(aAllColumns[nLayer]=='LevelDisplayText'){
   	        		 oNode.levelDisplayText=parseInt(oNode.name);
   	        	 	}
    	            if(aAllColumns[nLayer]=='LevelDisplayTextCount'){
    	            	if(oParentNode.columnLabel=="LevelDisplayText"){oNode.levelDisplayText=oParentNode.levelDisplayText;}
    	            	
      	        		 oNode.levelDisplayTextCount=parseInt(oDataLayout.getValue(eEdgeType, nLayer, nSlice, false));
      	        	 }
    	            if(aAllColumns[nLayer]=='LevelDisplayDefault'){
    	            	if(oParentNode.columnLabel=="LevelDisplayTextCount"){
    	            		oNode.levelDisplayText=oParentNode.levelDisplayText;
    	            		oNode.levelDisplayTextCount=oParentNode.levelDisplayTextCount;
    	            	}
    	            	
      	        		 oNode.levelDisplayDefault=parseInt(oDataLayout.getValue(eEdgeType, nLayer, nSlice, false));
      	        	 }
    	            
    	            // Append new node to parent node
    	            oParentNode.children = oParentNode.children || [];
    	            oParentNode.children.push(oNode);
    	            buildTree(oNode, eEdgeType, nLayerCount, nLayer + 1, nRowIndex, nColIndex, nEndSlice, nTreeLevel + 1);
    	            // Aggregate values into parent node
    	            oParentNode.size = oParentNode.size || 0;
    	            if (oNode.size){
    	               oParentNode.size += oNode.size;
    	            	oParentNode.mLabel= oNode.mLabel;
    	            	oParentNode.levelDisplayText= oNode.levelDisplayText;
    	            	oParentNode.levelDisplayTextCount= oNode.levelDisplayTextCount;
    	            	oParentNode.levelDisplayDefault= oNode.levelDisplayDefault;
    	            }
    	         }
    	         else {
    	            oNode = oParentNode;
    	            if (isLastLayer())
    	               oNode.size = nValue;
    	            oNode.mLabel=valLabel;
    	            console.log('duplicate')
    	            buildTree(oNode, eEdgeType, nLayerCount, nLayer + 1, nRowIndex, nColIndex, nEndSlice, nTreeLevel + 1);
    	         }
    	      }
    	      return;
    	   }
    	    
    	   // Build a treemap starting with DETAIL logical edge (see getLogicalMapper)
    	   buildTree(oData, datamodelshapes.Physical.ROW, nRowLayerCount, 0, 0, 0, nRows, 0);
    	    
    	   // There isn't anything on Category, try COLOR logical edge (see getLogicalMapper)
    	   if (oData.children.length === 0){
    	      buildTree(oData, datamodelshapes.Physical.COLUMN, nColLayerCount, 0, 0, 0, nCols, 0);  
    	   }
    	   return oData;
    	} 
    /**
     * Resize the visualization
     * @param {Object} oVizDimensions - contains two properties, width and height
     * @param {module:obitech-report/vizcontext#VizContext} oTransientVizContext the viz context
     */
    forceDirectedGraph.prototype.resizeVisualization = function(oVizDimensions, oTransientVizContext){
       var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
       this._render(oTransientRenderingContext);
    }; 
    
    /**
     * Called whenever new data is ready and this visualization needs to update.
     * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
     */
    forceDirectedGraph.prototype.render = function(oTransientRenderingContext) {
       // Note: all events are received after initialize and start complete. The results can return other events
       // such as 'resize' before the onDataReady, for example, this might not be the first event.
        
       this._render(oTransientRenderingContext);
    }; 

   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the visualization
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {string=} sVersion 
    * @returns {module:com-company-forceDirectedGraph/forceDirectedGraph.forceDirectedGraph}
    * @memberof module:com-company-forceDirectedGraph/forceDirectedGraph
    */
   function createClientComponent(sID, sDisplayName, sOrigin) {
     // Argument validation done by base class
      return new forceDirectedGraph(sID, sDisplayName, sOrigin, forceDirectedGraph.VERSION);
   };

   return {
      createClientComponent : createClientComponent
   };
});