define({
    "FORCEDIRECTEDGRAPH_DISPLAY_NAME": "Force Directed Graph",
    "FORCEDIRECTEDGRAPH_SHORT_DISPLAY_NAME": "Force Directed Graph",
    "FORCEDIRECTEDGRAPH_CATEGORY":"ForceDirectedGraph Plugin",
    "FORCEDIRECTEDGRAPH_ROW_LABEL":"Nodes",
    "FORCEDIRECTEDGRAPH_ITEM_SIZE":"Item Size",
    "TEXT_MESSAGE": "Hello!  This is the {0} visualization and I have {1} rows of data."

});