define({
    "IMAGEGALLERYVIZ_DISPLAY_NAME": "ImageGalleryViz Plugin",
    "IMAGEGALLERYVIZ_SHORT_DISPLAY_NAME": "ImageGalleryViz Plugin",
    "IMAGEGALLERYVIZ_CATEGORY":"ImageGalleryViz Plugin",
    "IMAGEGALLERYVIZ_ROW_LABEL":"Image URL",
    "IMAGEGALLERYVIZ_ITEM_SIZE":"Item Size",
	"IMAGEGALLERYVIZ_COLOR_LABEL": "Description",
	"IMAGEGALLERYVIZ_SIZE_LABEL": "Tooltip",
    "TEXT_MESSAGE": "Hello!  This is the {0} visualization and I have {1} rows of data."

});