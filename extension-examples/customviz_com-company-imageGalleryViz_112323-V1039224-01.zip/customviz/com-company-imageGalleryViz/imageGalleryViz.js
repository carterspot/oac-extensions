define(['jquery',
		'obitech-framework/jsx',
		'obitech-report/datavisualization',
		'obitech-reportservices/datamodelshapes',
		'obitech-reportservices/data',
		'obitech-reportservices/interactionservice',
		'obitech-reportservices/markingservice',
		'obitech-application/gadgets',
		'obitech-report/visualization',
		'obitech-report/gadgetdialog',
		'obitech-application/bi-definitions',
		'obitech-application/extendable-ui-definitions',
		'obitech-reportservices/events',
		'obitech-appservices/logger',
		'obitech-framework/actioncontext',
		'ojL10n!com-company-imageGalleryViz/nls/messages',
		'obitech-framework/messageformat',
		'skin!css!com-company-imageGalleryViz/imageGalleryVizstyles'],
	function($,
			 jsx,
			 dataviz,
			 datamodelshapes,
			 data,
			 interactions,
			 marking,
			 gadgets,
			 viz,
			 gadgetdialog,
			 definitions,
			 euidef,
			 events,
			 logger,
			 actioncontext,
			 messages) {
		"use strict";

		var MODULE_NAME = 'com-company-imageGalleryViz/imageGalleryViz';

		//Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
		jsx.assertAllNotNullExceptLastN(arguments, "imageGalleryViz.js arguments", 2);
		var _logger = new logger.Logger(MODULE_NAME);
		var sNameSpace = "imageGalleryViz";
		ImageGalleryViz.Config ={
			start_index:0
		}
		// The version of our Plugin
		ImageGalleryViz.VERSION = "1.0.0";

		/**
		 * The implementation of the imageGalleryViz visualization.
		 *
		 * @constructor
		 * @param {string} sID
		 * @param {string} sDisplayName
		 * @param {string} sOrigin
		 * @param {string} sVersion
		 * @extends {module:obitech-report/visualization.Visualization}
		 * @memberof module:com-company-imageGalleryViz/imageGalleryViz#
		 */
		function ImageGalleryViz(sID, sDisplayName, sOrigin, sVersion) {
			// Argument validation done by base class
			ImageGalleryViz.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);


			this.Config = {
				x_axis : '3',
				y_axis : '3'
			}

			this._saveSettings = function() {
				this.getSettings().setViewConfigJSON(dataviz.SettingsNS.CHART, this.Config);
			};

			this.loadConfig = function (){
				var conf = this.getSettings().getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
				if (conf.x_axis) this.Config.x_axis = conf.x_axis;
				if (conf.y_axis) this.Config.y_axis = conf.y_axis;
			};

			this.setActiveVar = function (o){
				var conf_ = this.getViewConfig(sNameSpace) || {};
				conf_.start_index=o;
				this._saveSettings(conf_);
			};

			this.getActiveVar = function (){
				var obj = this.getViewConfig(sNameSpace) || {};
				return obj.start_index;
			};


			var flag = true;
			var filter_flag = false;
			var settings_changed = false;
			var strt_index = 0;

			this.getStrt = function(){
				return(strt_index);
			};

			this.setStrt = function(o){
				strt_index = o;
			};

			this.getX = function(){
				return(this.Config.x_axis);
			};

			this.getY = function(){
				return(this.Config.y_axis);
			};

			this.setX = function(o){
				this.Config.x_axis = o;
				this._saveSettings();
			};

			this.setY = function(o){
				this.Config.y_axis = o;
				this._saveSettings();
			};

			this.getFlag = function(){
				return(flag);
			};

			this.setFlag = function(o){
				flag = o;
			};

			this.getFilterFlag = function(){
				return(filter_flag);
			};

			this.setFilterFlag = function(o){
				filter_flag = o;
			};

			this.getSettings1 = function(){
				return(settings_changed);
			};

			this.setSettings1 = function(o){
				settings_changed = o;
			};

		};
		jsx.extend(ImageGalleryViz, dataviz.DataVisualization);
		/**
		 * Called whenever new data is ready and this visualization needs to update.
		 * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
		 */

		ImageGalleryViz.prototype._generateData = function(oDataLayout,oDataLayoutHelper){

			var oDataModel = this.getRootDataModel();
			if(!oDataModel || !oDataLayout){
				return;
			}

			var aAllMeasures = oDataModel.getColumnIDsIn(datamodelshapes.Physical.DATA);
			var nMeasures = aAllMeasures.length;
			var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
			var nRowLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
			var nCols = oDataLayout.getEdgeExtent(datamodelshapes.Physical.COLUMN);
			var nColLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.COLUMN);

			// Measure labels layer
			var isMeasureLabelsLayer = function (eEdgeType, nLayer) {
				return oDataLayout.getLayerMetadata(eEdgeType, nLayer, data.LayerMetadata.LAYER_ISMEASURE_LABELS);
			};

			// Last layer: we get the data values and colors from this layer
			var getLastNonMeasureLayer = function (eEdge) {
				var nLayerCount = oDataLayout.getLayerCount(eEdge);
				for (var i = nLayerCount - 1; i >= 0; i--) {
					if (!isMeasureLabelsLayer(eEdge, i))
						return i;
				}
				return -1;
			};

			//--------------------------------------------------------
			var aOutput = [];

			if(nRows > 0 || nCols > 0){
				var nRow, nCol;
				var desc = true;
				var tooltip = true;
				var row_count = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
				if(row_count == 1){
					desc = false;
					tooltip = false;
				}else{
					if(oDataLayoutHelper.getLogicalEdgeName(datamodelshapes.Physical.ROW,1) == "size"){
						desc = false;
						tooltip = true;
					}else if(oDataLayoutHelper.getLogicalEdgeName(datamodelshapes.Physical.ROW,1) == "color"){
						desc = true;
						if(row_count == 2){
							tooltip = false;
						}else{
							tooltip = true;
						}
					}
				}

				for(nRow=0; nRow < Math.max(nRows, 1); nRow++){
					var oNode = {description:"", imgSrc:"",tooltip:""};
					if(oDataLayout.getLayerMetadata(datamodelshapes.Physical.ROW,0, data.LayerMetadata.LAYER_DISPLAY_NAME)){
						oNode.imgSrc = oDataLayout.getValue(datamodelshapes.Physical.ROW, 0, nRow, false);
					}
					if(desc){
						oNode.description = oDataLayout.getValue(datamodelshapes.Physical.ROW, 1, nRow, false);
						if(tooltip){
							oNode.tooltip = oDataLayout.getValue(datamodelshapes.Physical.ROW, 2, nRow, false);
						}else{
							oNode.tooltip = "";
						}
					}else{
						oNode.description = "";
						if(tooltip){
							oNode.tooltip = oDataLayout.getValue(datamodelshapes.Physical.ROW, 1, nRow, false);
						}else{
							oNode.tooltip = "";
						}
					}
					aOutput.push(oNode);
				}
			}
			//--------------------------------------------------------
			if (aOutput.length>0)
				return aOutput; /*sortByKey(aOutput, 'value', true);*/
			else
				return null;
		}





		ImageGalleryViz.prototype.render = function(oTransientRenderingContext) {
			try {
				// Note: all events will be received after initialize and start complete.  We may get other events
				// such as 'resize' before the render, i.e. this might not be the first event.

				// Retrieve the data object for this visualization
				/*if(this.getFilterFlag()){
                    this.setFilterFlag(false);
                    return;
                }*/
				var isNew = true;
				var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
				var oMarkingService = this.getMarkingService();
				if(oDataLayout == null)
				{
					return;
				}
				// Determine the number of records available for rendering on ROW
				// Because we specified that Category should be placed on ROW in the data model handler,
				// this returns the number of rows for the data in Category.
				var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
				var oDataLayoutHelper = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT_HELPER);
				var imgSeries = this._generateData(oDataLayout,oDataLayoutHelper);

				this.loadConfig();
				// Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
				// but may be used to render.
				var elContainer = this.getContainerElem();
				var meta = "<meta http-equiv=\"Content-Security-Policy\" \n" +
					"    content=\"\n" +
					"      worker-src blob:; \n" +
					"      child-src blob: gap:;\n" +
					"		img-src * 'self' elocation.oracle.com *.googleapis.com maps.google.com maps.gstatic.com data: blob:;\n" +
					"      default-src * 'self' 'unsafe-inline' 'unsafe-eval' data: gap: content:\">";
				$('head').append(meta);
				//$(elContainer).html(meta);
				if(!elContainer){
					return;
				}
				var identifier = this.getID();
				$(elContainer)[0].classList.add("elContainer" + identifier);
				var viz = this;
				var next_button_handler = function(e) {
					var nId = (e["target"].id).replace('nextBtn','');
					console.log(e["target"].id);
					var elContainer_id = $(elContainer)[0].id;
					var elContainer_num = elContainer_id.substring(elContainer_id.indexOf("view"),elContainer_id.indexOf("pane"));
					if(elContainer_num == nId){
						viz.setStrt(Number(this.dataset.index) + (viz.getX()*viz.getY()));
						buildHTML(elContainer,viz.getX(),viz.getY(),imgSeries.length,Number(this.dataset.index) + (viz.getX()*viz.getY()),nId,true);
					}
					//buildHTML(elContainer,viz.getX(),viz.getY(),imgSeries.length,Number(this.dataset.index) + (viz.getX()*viz.getY()),nId,true);
					viz.setFilterFlag(false);
					setBtnHanlders();
				}

				var prev_button_handler = function(e) {
					console.log(e["target"].id);
					var pId = (e["target"].id).replace('prevBtn','');
					var elContainer_id = $(elContainer)[0].id;
					var elContainer_num = elContainer_id.substring(elContainer_id.indexOf("view"),elContainer_id.indexOf("pane"));
					if(elContainer_num == pId){
						viz.setStrt(Number(this.dataset.index) - (viz.getX()*viz.getY()));
						buildHTML(elContainer,viz.getX(),viz.getY(),imgSeries.length,Number(this.dataset.index) - (viz.getX()*viz.getY()),pId,true);
					}
					viz.setFilterFlag(false);
					setBtnHanlders();
				}

				var image_click = function(e){
					var id = Number(e["target"]["id"]);
					$('td').removeClass("selected");
					e["target"].parentElement.classList.add("selected");
					oMarkingService.clearMarksForDataLayout(oDataLayout);
					//oMarkingService.setMark(oDataLayout, datamodelshapes.Physical.DATA, id, 0);
					oMarkingService.setMark(oDataLayout, datamodelshapes.Physical.ROW, 0, id);
					viz._publishMarkEvent(oDataLayout);

				}

				var expand_click = function(e){
					var btnid = e["target"].id;
					var id = Number(e["target"].getAttribute("data-index"));
					console.log(id);
					var caption = (e["target"].getAttribute("data-caption"));
					var source = (e["target"].getAttribute("data-imgsrc"));
					//set caption
					var idn = btnid.replace('myBtn','');
					var para = document.getElementById("text"+idn);
					para.innerHTML = caption;
					//set image
					var img = document.getElementById("modalImg" + idn);
					img.src = source;
					var modalId = "myModal" + btnid.replace('myBtn','');
					var modal = document.getElementById(modalId);
					modal.style.height = $(elContainer).height() + "px";
					modal.style.width = $(elContainer).width() + "px";
					modal.style.maxHeight = $(elContainer).height() + "px";
					modal.style.maxWidth = $(elContainer).width() + "px";
					modal.style.display = "block";
					var offTop = document.getElementById("text" + idn).offsetTop;
					console.log(offTop);
					var rem_height = document.getElementById(modalId).offsetHeight - 2*offTop - document.getElementById("text" + idn).offsetHeight -15;
					//console.log(rem_height);
					document.getElementById("modalImg" + idn).style.maxHeight = rem_height + "px";
					//document.getElementById("modalImg" + idn).style.maxWidth = "100%";
				}

				var close_click = function(e){
					//var index = viz.getInstanceNumber();
					var btnid = e["target"].id;
					var idn = btnid.replace('close','');
					var modal = document.getElementById('myModal' + idn);
					modal.style.display = "none";
				}

				function buildHTML(elContainer,x,y,n,start_index,identifier,btnFlag){
					if(isNew){
						start_index = 0;
						isNew = false;
					}
					var modalId = "myModal" + identifier;
					var pId = "text" + identifier;
					var imgId = "modalImg" + identifier;
					var closeId = "close" + identifier;
					var elContainer_id = $(elContainer)[0].id;
					var elContainer_num = elContainer_id.substring(elContainer_id.indexOf("view"),elContainer_id.indexOf("pane"));
					if(btnFlag){
						if(identifier != elContainer_num){
							return;
						}
						var elContainer_ = document.getElementsByClassName("elContainer"+identifier);
						elContainer = elContainer_[0];
					}
					$(elContainer).html("<div id=\""+ modalId + "\" class=\"modal\"><div class=\"modal-content\"><span id=\""+ closeId + "\"class=\"close\">&times;</span><p id=\""+ pId + "\">Some text in the Modal</p><img id=\""+ imgId + "\" src=\"\" crossorigin=\"anonymous\"></div></div>");
					var h = $(elContainer).height();
					var w = $(elContainer).width();
					h = Math.round(h);
					w = Math.round(w);
					var row_height = h/x;
					var row_width = w/y;
					var outerDiv = document.createElement('table');
					outerDiv.id = 'outerDiv' + identifier;
					outerDiv.style.height = (h-75) + "px";
					outerDiv.style.width = w + "px";
					outerDiv.className = "outerDiv";
					var rowDiv  = document.createElement('tr');
					rowDiv.id = 'rowDiv' + identifier;
					rowDiv.style.height = (h-75) + "px";
					rowDiv.style.width = w + "px";
					var leftDiv = document.createElement('td');
					leftDiv.id = 'leftDiv' + identifier;
					leftDiv.className = 'leftDiv';
					leftDiv.style.height = (h-75) + "px";
					var prevId = "prevBtn" + identifier;
					leftDiv.innerHTML = "<button id=\""+ prevId +"\" class=\"prevBtn\" style=\"width:22px;height:22px;top:50%;left:0;cursor:pointer\" data-index=\"" + start_index +"\">";
					var middleDiv = document.createElement('td');
					middleDiv.id = 'middleDiv' + identifier;
					middleDiv.className = 'middleDiv';
					middleDiv.style.width = (w-65) + "px";
					middleDiv.style.height = (h-75) + "px";
					var middleDivTab = document.createElement('table');
					middleDivTab.id = 'middleDivTab' + identifier;
					middleDivTab.className = 'middleDivTab';
					middleDivTab.style.height = (h-75) + "px";
					middleDivTab.style.width = (w-65) + "px";
					//logic for populating
					for(var i=0;i<x; i++){
						var middleDivRow = document.createElement('tr');
						middleDivRow.className = 'middleDivRow';
						middleDivRow.id = 'middleDivRow' + identifier;
						middleDivRow.style.width=(w-65) + "px";
						middleDivRow.style.height = (h-75)/x + "px";
						for(var j=0;j<y;j++){
							var idx = start_index + i*y + j;
							if(idx < n){
								var tile = document.createElement('td');
								tile.className = "tile";
								tile.style.width  = (w-65)/y + "px";
								tile.style.height = (h-20)/x + "px";
								tile.style.maxWidth  = (w-65)/y + "px";
								tile.style.maxHeight = (h/x) + "px";
								//tile.style.verticalAlign = "middle";
								tile.align="center";
								//for image
								var img = document.createElement("img");
								img.className = 'tileImg';
								img.style.height = (h-95)/x + "px";
								img.crossOrigin = "anonymous";
								img.src = imgSeries[idx]["imgSrc"];
								img.id = idx;
								img.title = imgSeries[idx]["tooltip"];
								//for description
								var descriptionDiv = document.createElement('div');
								descriptionDiv.className = "descriptionDiv";
								descriptionDiv.align = "center";
								descriptionDiv.valign = "middle";
								descriptionDiv.innerHTML = imgSeries[idx]["description"];
								descriptionDiv.style.width  = (w-65)/y + "px";
								descriptionDiv.style.maxWidth  = (w-65)/y + "px";
								//for img expansion icon
								var expandDiv = document.createElement('div');
								expandDiv.className = "expandDiv";
								var myBtnId = "myBtn" + identifier;
								expandDiv.innerHTML = "<button id=\""+ myBtnId + "\" class=\"myBtn\" style=\"height:15px;cursor:pointer;\" data-caption=\""+ imgSeries[idx]["description"] + "\" data-imgsrc=\""+ imgSeries[idx]["imgSrc"]+"\">";
								tile.appendChild(img);
								tile.appendChild(descriptionDiv);
								tile.appendChild(expandDiv);
								middleDivRow.appendChild(tile);
							}else{
								var tile1 = document.createElement('td');
								tile1.className = "tile1";
								tile1.style.width  = (w-65)/y + "px";
								tile1.style.height = row_height + "px";
								tile1.style.maxWidth  = (w-65)/y + "px";
								tile1.style.maxHeight = row_height + "px";
								tile1.style.border ="none";
								tile1.align="center";
								middleDivRow.appendChild(tile1);
							}
						}
						middleDivTab.appendChild(middleDivRow);
					}
					middleDiv.appendChild(middleDivTab);
					var rightDiv = document.createElement('td');
					rightDiv.id = 'rightDiv' + identifier;
					rightDiv.className = 'rightDiv';
					rightDiv.className = 'rightDiv';
					rightDiv.style.height = h + "px";
					var nextId = "nextBtn" + identifier;
					rightDiv.innerHTML = "<button id=\""+ nextId + "\" class=\"nextBtn\" style=\"width:22px;height:22px;top:50%;left:0;cursor:pointer;\" data-index=\"" + start_index +"\">";
					rowDiv.appendChild(leftDiv);
					rowDiv.appendChild(middleDiv);
					rowDiv.appendChild(rightDiv);
					outerDiv.appendChild(rowDiv);
					elContainer.appendChild(outerDiv);
					if( n > (start_index + (x*y))){
						//show the next button
						document.getElementById(nextId).style.display = 'block';
					}else{
						document.getElementById(nextId).style.display = 'none';
					}
					if(start_index != 0){
						//show the previous button everytime except for the first time
						document.getElementById(prevId).style.display = 'block';
					}else{
						document.getElementById(prevId).style.display = 'none';
					}
				}
				var elContainer_id = $(elContainer)[0].id;
				if(identifier ==  elContainer_id.substring(elContainer_id.indexOf("view"),elContainer_id.indexOf("pane"))){
					if(this.getSettings1()){
						buildHTML(elContainer,Number(this.getX()),Number(this.getY()),imgSeries.length,0,identifier,false);
						this.setSettings1(false);
					}else{
						if(typeof this.getStrt() === "undefined"){
							buildHTML(elContainer,Number(this.getX()),Number(this.getY()),imgSeries.length,0,identifier,false);
							this.setStrt(0);
						}else{
							buildHTML(elContainer,Number(this.getX()),Number(this.getY()),imgSeries.length,this.getStrt(),identifier,false);
						}
					}
				}else{
					buildHTML(elContainer,Number(this.getX()),Number(this.getY()),imgSeries.length,0,identifier,false);
				}
				function setBtnHanlders(){
					$( ".nextBtn" ).click(next_button_handler);
					$('.prevBtn').click(prev_button_handler);
					//$("button").click(button_click);
					$(".tileImg").click(image_click);
					$(".myBtn").click(expand_click);
					$(".close").click(close_click);
				}

				setBtnHanlders();
				//$(elContainer).html(messages.TEXT_MESSAGE.format("ImageGalleryViz Plugin", "" + nRows));
			}
			finally {
				this._setIsRendered(true);
			}
		};

		ImageGalleryViz.prototype._addVizSpecificPropsDialog = function(oTabbedPanelsGadgetInfo){
			this.doAddVizSpecificPropsDialog(this, oTabbedPanelsGadgetInfo);
			ImageGalleryViz.superClass._addVizSpecificPropsDialog.call(this, oTabbedPanelsGadgetInfo);
		};


		ImageGalleryViz.prototype.doAddVizSpecificPropsDialog = function (oTransientRenderingContext, oTabbedPanelsGadgetInfo) {
			jsx.assertObject(oTransientRenderingContext, "oTransientRenderingContext");
			jsx.assertInstanceOf(oTabbedPanelsGadgetInfo, gadgets.TabbedPanelsGadgetInfo, "oTabbedPanelsGadgetInfo", "obitech-application/gadgets.TabbedPanelsGadgetInfo");

			//var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
			var oDataModel = this.getRootDataModel();
			if(!oDataModel){
				return;
			}

			var options = this.getViewConfig() || {};
			//this._fillDefaultOptions(options, oTransientRenderingContext.get(viz.ContextProperty.ACTION_CONTEXT));
			this._fillDefaultOptions(options, null);

			var generalPanel = gadgetdialog.forcePanelByID(oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_GENERAL);

			var oGadgetFactory = this.getGadgetFactory();
			var oX = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.getX());
			var oXInfo = oGadgetFactory.createGadgetInfo("xKeyGadget", 'X Axis', 'X Axis', oX);
			generalPanel.addChild(oXInfo);

			var oY = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.getY());
			var oYInfo = oGadgetFactory.createGadgetInfo("yKeyGadget", 'Y Axis', 'Y Axis', oY);
			generalPanel.addChild(oYInfo);

			if (ImageGalleryViz.superClass.doAddVizSpecificPropsDialog)
				ImageGalleryViz.superClass.doAddVizSpecificPropsDialog.apply(this, arguments);
		};


		ImageGalleryViz.prototype._handlePropChange = function (sGadgetID, oPropChange, oViewSettings, oActionContext){
			var updateSettings = ImageGalleryViz.superClass._handlePropChange.call(this, sGadgetID, oPropChange, oViewSettings, oActionContext);
			if (updateSettings) {
				return updateSettings; // super handled it
			}

			// Allow the super class an attempt to handle the changes
			var conf = oViewSettings.getViewConfigJSON(dataviz.SettingsNS.CHART) || {};

			if (sGadgetID === "xKeyGadget")
			{
				if (jsx.isNull(conf.styleDefaults))
				{
					conf.styleDefaults = {};
				}

				this.setX(oPropChange.value);
				this.setFilterFlag(false);
				this.setSettings1(true);
				updateSettings = true;
			}

			if (sGadgetID === "yKeyGadget")
			{
				if (jsx.isNull(conf.styleDefaults))
				{
					conf.styleDefaults = {};
				}

				this.setY(oPropChange.value);
				this.setFilterFlag(false);
				this.setSettings1(true);
				updateSettings = true;
			}

			return updateSettings;
		};

		ImageGalleryViz.prototype._publishMarkEvent = function (oDataLayout, eMarkContext) {
			try {
				// Create the marking event
				var markingEvent = new interactions.MarkingEvent(this.getID(), this.getViewName(), oDataLayout, null, eMarkContext);
				var eventRouter = this.getEventRouter();
				if (eventRouter) {
					eventRouter.publish(markingEvent);
				}
			}
			catch (e) {
				console.log("Error during mark", e);
			}
		};


		ImageGalleryViz.prototype.resizeVisualization = function(oVizDimensions, oTransientVizContext){
			var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
			this.setFilterFlag(false);
			this.render(oTransientRenderingContext);
		};

		ImageGalleryViz.prototype._onFiltersSelected = function(){
			console.log("Inside Filters selected");
			//this.setFilterFlag(false);
			return;
		}

		ImageGalleryViz.prototype._doInitializeComponent = function() {
			ImageGalleryViz.superClass._doInitializeComponent.call(this);
			this.subscribeToEvent(events.types.INTERACTION_FILTER, this._onFiltersSelected, "**");
		};

		/**
		 * Factory method declared in the plugin configuration
		 * @param {string} sID Component ID for the visualization
		 * @param {string=} sDisplayName Component display name
		 * @param {string=} sOrigin Component host identifier
		 * @param {string=} sVersion
		 * @returns {module:com-company-imageGalleryViz/imageGalleryViz.ImageGalleryViz}
		 * @memberof module:com-company-imageGalleryViz/imageGalleryViz
		 */
		function createClientComponent(sID, sDisplayName, sOrigin) {
			// Argument validation done by base class
			return new ImageGalleryViz(sID, sDisplayName, sOrigin, ImageGalleryViz.VERSION);
		};

		return {
			createClientComponent : createClientComponent
		};
	});