define([
  'jquery',
  'obitech-framework/jsx',
  'obitech-report/datavisualization',
  'obitech-reportservices/datamodelshapes',
  'obitech-reportservices/data',
  'obitech-reportservices/events',
  'obitech-reportservices/interactionservice',
  'obitech-reportservices/markingservice',
  'obitech-appservices/logger',
  'ojL10n!com-company-elbow/nls/messages',
  'd3js',
  'obitech-framework/messageformat',
  'skin!css!com-company-elbow/elbowstyles'
], function (
  $,
  jsx,
  dataviz,
  datamodelshapes,
  data,
  events,
  interactions,
  marking,
  logger,
  messages,
  d3
) {
    'use strict';
    var MODULE_NAME = 'com-company-elbow/elbow';

    //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
    jsx.assertAllNotNullExceptLastN(arguments, 'elbow.js arguments', 2);

    var _logger = new logger.Logger(MODULE_NAME);
    var myData;
    var resize = false;
    var vizs = [];
    var firstGroup = '';
    var showTooltip = true;
    elbow.VERSION = '1.0.0';

    /**
     * The implementation of the heirarchyViz visualization.
     *
     * @constructor
     * @param {string} sID
     * @param {string} sDisplayName
     * @param {string} sOrigin
     * @param {string} sVersion
     * @extends {module:obitech-report/visualization.Visualization}
     * @memberof module:com-company-heirarchyViz/heirarchyViz#
     */
    function elbow(sID, sDisplayName, sOrigin, sVersion) {
      elbow.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);

      var aSelectedItems = [];

      this.getSelectedItems = function () {
        return aSelectedItems;
      };

      this.clearSelectedItems = function () {
        aSelectedItems = [];
      };
    }

    jsx.extend(elbow, dataviz.DataVisualization);

    elbow.prototype._generateData = function (oDataLayout, oDataModel) {
      var myArray = [];
      //var valueArray = [];
      //using the row expander code
      //	var oDataModel = this.getRootDataModel();
      if (!oDataModel || !oDataLayout) {
        return;
      }

      var aAllMeasures = oDataModel.getColumnIDsIn(datamodelshapes.Physical.DATA);
      var nMeasures = 0;
      if(aAllMeasures.indexOf("__EmbeddedVizDummyMeasureLink__") === -1){
        nMeasures = aAllMeasures.length;
      } else {
        nMeasures = aAllMeasures.length - 1;
      }
      if (oDataModel.getColumnIDsIn(datamodelshapes.Physical.ROW).length > 0) {
        firstGroup = oDataModel.getColumnIDsIn(datamodelshapes.Physical.ROW)[0];
      }
      var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
      var nRowLayerCount = oDataLayout.getLayerCount(
        datamodelshapes.Physical.ROW
      );

      /*var measureName = '';
      measureName = oDataLayout.getValue(
        datamodelshapes.Physical.COLUMN,
        0,
        0
      );*/

      for (var i = 0; i < nRowLayerCount; i++) {
        var array = [];
        myArray.push(array);
      }
      var children_array = [];
      /*var metric_names = [];
      for (var m = 0; m < nMeasures; m++) {
        metric_names.push(
            oDataLayout.getValue(datamodelshapes.Physical.COLUMN, 0, m, false)
        );
      }*/

      function addChildren(parent, obj, level){
        return parent[myArray[level-1].length-1]['children'].push(obj);
      }

      var nRow;
      var nMeasCnt = 0;
      for (nRow = 0; nRow < Math.max(nRows, 1); nRow++) {
        for (var nCol = 0; nCol < nRowLayerCount; nCol++) {
          var column_value = oDataLayout.getValue(
            datamodelshapes.Physical.ROW,
            nCol,
            nRow,
            false
          );
          if (('column_value', column_value))
            if (column_value && column_value != '') {
              var obj = null;
              //logic to build children array
              if (children_array.length == 0) {
                var obj = {
                  name: column_value,
                  children: []
                };
                children_array.push(obj);
                myArray[0].push(column_value);
              } else {
                var obj = {
                  name: column_value,
                  children: []
                };
                if (nCol == nRowLayerCount - 1) {
                  obj['row_number'] = nMeasCnt;
                  obj['col_number'] = 0;
                  nMeasCnt++;
                }

                switch (nCol) {
                  case 0:
                    if (myArray[0].indexOf(column_value) == -1) {
                      children_array.push(obj);
                      myArray[0].push(column_value);
                      for (var i = nCol + 1; i < nRowLayerCount; i++) {
                        myArray[i] = [];
                      }
                    }
                    break;
                  case 1:
                    if (myArray[1].indexOf(column_value) == -1) {
                      children_array[children_array.length - 1][
                        'children'
                      ].push(obj);
                      myArray[1].push(column_value);
                      if (nRowLayerCount > 2) {
                        for (var i = nCol + 1; i < nRowLayerCount; i++) {
                          myArray[i] = [];
                        }
                      }
                    }
                    break;

                  default:
                    if(myArray[nCol].indexOf(column_value) == -1) {
                    var parentArray =  children_array[children_array.length - 1]['children'];
                    var prev, next, temp;
                    prev =  parentArray;
                    for (var i = 1; i < nCol; i++){
                      var temp = prev[myArray[i].length-1]['children'];
                      prev = temp;
                    }
                    prev.push(obj);
                    myArray[nCol].push(column_value);
                    if (nRowLayerCount -1  > nCol) {
                      for (var i = nCol + 1; i < nRowLayerCount; i++) {
                        myArray[i] = [];
                      }
                    }
                  }
                    break;
                }

              }

            }
        }

        if (nMeasures > 0) {
          showTooltip = true;

          var sizeArray = [];
          var x = children_array;

          for (var i = 0; i < nRowLayerCount; i++) {
            sizeArray.push(x.length);
            x = x[sizeArray[sizeArray.length - 1] - 1]['children'];
          }

          var insert_position = children_array;
          for (var i = 0; i < nRowLayerCount - 1; i++) {
            insert_position = insert_position[sizeArray[i] - 1]['children'];
          }

          var nodeMeasure = String(insert_position[sizeArray[sizeArray.length - 1] - 1]['name']);
          var nodeValue = fNum(oDataLayout.getValue(datamodelshapes.Physical.DATA, nRow, 0));
          //var x = nodeMeasure + '\xa0\xa0' + nodeValue;
          var x = nodeMeasure;
          insert_position[sizeArray[sizeArray.length - 1] - 1]['name'] = x;
          insert_position[sizeArray[sizeArray.length - 1] - 1]['value'] = parseFloat(oDataLayout.getValue(datamodelshapes.Physical.DATA, nRow, 0));
        } else {
          showTooltip = false;
        }
      }

      var addCount = nRowLayerCount - 1;
      children_array.forEach(function(element) {
        getChildren(element);
      });

      return children_array;
    };

    function setChildrenValue(element) {
      if (element.children) {
        element.value = 0;
        element.children.forEach(child => {
          element.value += child.value;
        });
      }
    }

    function getChildrenValue(d){
      var count = 0;
      if (d.children && d.children.length > 0 ){
        d.children.forEach(function(child){
          if(child.children && child.children.length === 0){
            var cVal = isNaN(child.value) ? 0 : child.value;
            count += cVal;
          } else {
            count += getChildrenValue(child);
          }
        });
      }
      return count;
    }

    function getChildren(element){
      if (element.children && element.children.length > 0) {
          element.value = 0;
          element.value = getChildrenValue(element);
          element.children.forEach(function(child){
            getChildren(child);
          });
      }
    }

    /**
     * Called whenever new data is ready and this visualization needs to update.
     * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
     */

    elbow.prototype.render = function (oTransientRenderingContext) {
      try {
        // Note: all events will be received after initialize and start complete.  We may get other events
        // such as 'resize' before the render, i.e. this might not be the first event.
        firstGroup = '';
        var oDataLayout = oTransientRenderingContext.get(
          dataviz.DataContextProperty.DATA_LAYOUT
        );
        var oDataModel = this.getRootDataModel();
        if (!oDataModel || !oDataLayout) {
          return;
        }

        var json_data = this._generateData(oDataLayout, oDataModel);
        var str_tb_replaced = ',"children":[]';
        var json_data1 = JSON.stringify(json_data).replace(str_tb_replaced, '');
        var elContainer = this.getContainerElem();
        var elString = JSON.stringify(elContainer);

        if (myData == json_data1) {
          if (!resize) {
            if (vizs.indexOf(elString) == -1) {
              vizs.push(elString);
            } else {
              return;
            }
          } else {
            resize = false;
          }
        } else {
          myData = json_data1;
        }
        var _self = this;
        while (json_data1.indexOf(str_tb_replaced) != -1) {
          json_data1 = json_data1.replace(str_tb_replaced, '');
        }
        var json_obj = JSON.parse(json_data1);
        var name = 'All';
        if (firstGroup && firstGroup !== 'All' && firstGroup !== '') {
          name = firstGroup;
        }
        var flare = {
          name: name,
          children: json_obj
        };

        $(elContainer).html('');
        var margin = { top: 20, right: 30, bottom: 20, left: 30 };
        var width = $(elContainer).width();
        var height = $(elContainer).height();

        var i = 0,
          duration = 750,
          root;

        var tree = d3.layout.tree().size([height, width]);


        var svg = d3
          .select(elContainer)
          .append('svg')
          .attr('width', '100%')
          .attr('height', '100%')
          .call(
            d3.behavior.zoom().on('zoom', function () {
              svg.attr(
                'transform',
                'translate(' +
                d3.event.translate +
                ')' +
                ' scale(' +
                d3.event.scale +
                ')'
              );
            })
          )
          .on('dblclick.zoom', null)
          .append('g')
          .attr('transform', 'translate(100,' + margin.top + ')');

        // Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
        // but may be used to render.

        root = flare;
        root.x0 = height / 2;
        root.y0 = width / 2;
        root.value = 0;
        root.children.forEach(collapse);

        root.children.forEach(element => {
          root.value += element.value;
        });
        update(root);

        d3.select(self.frameElement).style('height', '800px');
        d3.select(self.frameElement).style('width', '1200px');

        function update(source) {
          // Compute the new tree layout.
          var nodes = tree.nodes(root).reverse(),
            links = tree.links(nodes);

          // Normalize for fixed-depth.
          nodes.forEach(function (d) {
            d.y = d.depth * 180;
          });

          // Update the nodes…
          var node = svg.selectAll('g.node').data(nodes, function (d) {
            return d.id || (d.id = ++i);
          });

          var tooltip = d3
            .select('body')
            .append('div')
            .attr('class', 'tooltip')
            .style('opacity', 0);

          // Enter any new nodes at the parent's previous position.
          var nodeEnter = node
            .enter()
            .append('g')
            .attr('class', 'node')
            .attr('transform', function (d) {
              return 'translate(' + source.y0 + ',' + source.x0 + ')';
            })
            .on('click', click)
            .on('mouseover', function (d, i) {
              if (d.value === 0 || !showTooltip) return;
              var name = (d.name + '\xa0\xa0' + fNum(d.value));
              var tempTooltip = '';
              tooltip
                .transition()
                .duration(200)
                .style('opacity', 0.9);
              tooltip
                .html(
                  `<table class="tooltip-table">
             <tr > 
               <th></th>              
               <td>${name} </td>
             </tr>
             ${tempTooltip}
           </table>
            `
                )
                .style('left', d3.event.pageX + 'px')
                .style('top', d3.event.pageY - 28 + 'px');
            })
            .on('mouseout', function (d) {
              tooltip
                .transition()
                .duration(500)
                .style('opacity', 0);
            });

          nodeEnter
            .append('rect')
            .attr('width', 10)
            .attr('height', 10)
            .style('fill', function (d) {
              return d._children ? 'green' : '#fff';
            });

          nodeEnter
            .append('text')
            .attr('x', function (d) {
              return d.children || d._children ? -10 : 10;
            })
            .attr('dy', '.35em')
            .attr('text-anchor', function (d) {
              return d.children || d._children ? 'end' : 'start';
            })
            .text(function (d) {
              return d.name;
            })
            .style('fill-opacity', 10);

          // Transition nodes to their new position.
          var nodeUpdate = node
            .transition()
            .duration(duration)
            .attr('transform', function (d) {
              return 'translate(' + d.y + ',' + d.x + ')';
            });

          nodeUpdate
            .select('rect')
            .attr('width', 10)
            .attr('height', 10)
            .style('fill', function (d) {
              return d._children ? 'limegreen' : '#fff';
            });

          nodeUpdate.select('text').style('fill-opacity', 1);

          // Transition exiting nodes to the parent's new position.
          var nodeExit = node
            .exit()
            .transition()
            .duration(duration)
            .attr('transform', function (d) {
              return 'translate(' + source.y + ',' + source.x + ')';
            })
            .remove();

          nodeExit.select('rect').attr('width', 10);
          nodeExit.select('rect').attr('height', 10);

          nodeExit.select('text').style('fill-opacity', 1);

          // Update the links…
          var link = svg.selectAll('path.link').data(links, function (d) {
            return d.target.id;
          });

          // Enter any new links at the parent's previous position.
          link
            .enter()
            .insert('path', 'g')
            .attr('class', 'link')
            .attr('d', function (d) {
              var o = { x: source.x0, y: source.y0 };
              return elbow({ source: o, target: o });
            });

          // Transition links to their new position.
          link
            .transition()
            .duration(duration)
            .attr('d', elbow);

          // Transition exiting nodes to the parent's new position.
          link
            .exit()
            .transition()
            .duration(duration)
            .attr('d', function (d) {
              var o = { x: source.x, y: source.y };
              return elbow({ source: o, target: o });
            })
            .remove();

          // Stash the old positions for transition.
          nodes.forEach(function (d) {
            d.x0 = d.x;
            d.y0 = d.y;
          });
        }

        function collapse(d) {
          if (d.children) {
            d._children = d.children;
            d._children.forEach(collapse);
            d.children = null;
          }
        }

        function elbow(d, i) {
          return (
            'M' +
            d.source.y +
            ',' +
            d.source.x +
            'H' +
            d.target.y +
            'V' +
            d.target.x +
            (d.target.children ? '' : 'h' + margin.right)
          );
        }

        // Toggle children on click.
        //var lastClickD = null;
        function click(d) {
          if (d.children) {
            d._children = d.children;
            d.children = null;
            var oMarkingService = _self.getMarkingService();
            oMarkingService.clearMarksForDataLayout(oDataLayout);
            _self._publishMarkEvent(oDataLayout);
            d3.selectAll('rect')
              .style('stroke', 'green')
              .style('fill', 'limegreen')
              .style('stroke-width', '1.5px')
              .style('stroke-height', '1.5px');
          } else {
            d.children = d._children;
            d._children = null;

            if (typeof d.children == 'undefined' || !d.children) {
              var oMarkingService = _self.getMarkingService();
              oMarkingService.clearMarksForDataLayout(oDataLayout);
              if (
                typeof d['row_number'] != 'undefined' &&
                typeof d['col_number'] != undefined
              ) {
                oMarkingService.setMark(
                  oDataLayout,
                  datamodelshapes.Physical.DATA,
                  d['row_number'],
                  d['col_number']
                );
              }
              _self._publishMarkEvent(oDataLayout);
              d3.selectAll('rect')
                .style('stroke', 'green')
                .style('fill', 'limegreen')
                .style('stroke-width', '1.5px')
                .style('stroke-height', '1.5px');

              d3.select(this)
                .select('rect')
                .style('stroke', 'green')
                .style('fill', 'limegreen')
                .style('stroke-width', '2.5px')
                .style('stroke-height', '2.5px');
            } else {
              //do a BFS for all the child nodes and add it to the array
              d3.selectAll('rect')
                .style('stroke', 'green')
                .style('fill', 'limegreen')
                .style('stroke-width', '1.5px')
                .style('stroke-height', '1.5px');

              d3.select(this)
                .select('rect')
                .style('stroke', 'limegreen')
                .style('fill', 'green')
                .style('stroke-width', '2.5px')
                .style('stroke-height', '2.5px');
              var leafs = [];
              var queue = [];
              if (typeof d.children != 'undefined' && d.children) {
                for (var i = 0; i < d.children.length; i++) {
                  queue.push(d.children[i]);
                }
              }
              while (queue.length != 0) {
                var top = queue[0];
                if (
                  (typeof top._children == 'undefined' ||
                    top._children == null) &&
                  (typeof top.children == 'undefined' || top.children == null)
                ) {
                  //this is a leaf node
                  var obj = {};
                  obj['row'] = top['row_number'];
                  obj['col'] = top['col_number'];
                  if (
                    typeof obj['row'] != 'undefined' &&
                    typeof obj['col'] != 'undefined'
                  ) {
                    leafs.push(obj);
                  }
                } else {
                  //this is not a leaf node
                  if (top._children != null) {
                    for (var i = 0; i < top._children.length; i++) {
                      queue.push(top._children[i]);
                    }
                  }
                  if (top.children != null) {
                    for (var i = 0; i < top.children.length; i++) {
                      queue.push(top.children[i]);
                    }
                  }
                }
                queue.shift();
              }
              //traverse all the leafs array and call publish mark event
              var oMarkingService = _self.getMarkingService();
              oMarkingService.clearMarksForDataLayout(oDataLayout);
              for (var i = 0; i < leafs.length; i++) {
                oMarkingService.setMark(
                  oDataLayout,
                  datamodelshapes.Physical.DATA,
                  leafs[i]['row'],
                  leafs[i]['col']
                );
              }
              _self._publishMarkEvent(oDataLayout);
            }
          }
          update(d);

          d3.event.stopPropagation();
        }
      } finally {
        this._setIsRendered(true);
      }
    };

    elbow.prototype.resizeVisualization = function (
      oVizDimensions,
      oTransientVizContext
    ) {
      resize = false;
      var oTransientRenderingContext = this.createRenderingContext(
        oTransientVizContext
      );
      this.render(oTransientRenderingContext);
    };

    elbow.prototype._publishMarkEvent = function (oDataLayout, eMarkContext) {
      try {
        // Create the marking event
        var markingEvent = new interactions.MarkingEvent(
          this.getID(),
          this.getViewName(),
          oDataLayout,
          null,
          eMarkContext
        );
        var eventRouter = this.getEventRouter();
        if (eventRouter) {
          // Publish the event to listeners
          eventRouter.publish(markingEvent);
        }
      } catch (e) {
        console.log('Error during mark', e);
      }
    };

    elbow.prototype._buildSelectedItems = function (oTransientRenderingContext) {
      var oViz = this;
      var oDataLayout = oTransientRenderingContext.get(
        dataviz.DataContextProperty.DATA_LAYOUT
      );
      var oMarkingService = this.getMarkingService();

      function fMarksReadyCallback() {
        oViz.clearSelectedItems();
        var aSelectedItems = oViz.getSelectedItems();

        if (!oViz.isStarted()) {
          return;
        }
        oMarkingService.traverseDataEdgeMarks(oDataLayout, function (nRow, nCol) {
          aSelectedItems.push(nRow + ':' + nCol);
        });

        oViz.render(oTransientRenderingContext);
      }

      oMarkingService.getUpdatedMarkingSet(
        oDataLayout,
        marking.EMarkOperation.MARK_RELATED,
        fMarksReadyCallback
      );
    };

    elbow.prototype.onHighlight = function () {
      var oTransientVizContext = this.assertOrCreateVizContext();
      var oTransientRenderingContext = this.createRenderingContext(
        oTransientVizContext
      );
      this._buildSelectedItems(oTransientRenderingContext);
    };

    function fNum(num) {
      num = Number(num);
      if (num % 1 != 0) {
        if (Math.abs(num) < 1) num = Math.round(num * 1000) / 1000;
        else num = Math.round(num * 100) / 100;
      }
      return num.toLocaleString();
    }

    /**
     * Factory method declared in the plugin configuration
     * @param {string} sID Component ID for the visualization
     * @param {string=} sDisplayName Component display name
     * @param {string=} sOrigin Component host identifier
     * @param {string=} sVersion
     * @returns {module:com-company-heirarchyViz/heirarchyViz.HeirarchyViz}
     * @memberof module:com-company-heirarchyViz/heirarchyViz
     */
    function createClientComponent(sID, sDisplayName, sOrigin) {
      // Argument validation done by base class
      return new elbow(sID, sDisplayName, sOrigin, elbow.VERSION);
    }

    return {
      createClientComponent: createClientComponent
    };
  });
