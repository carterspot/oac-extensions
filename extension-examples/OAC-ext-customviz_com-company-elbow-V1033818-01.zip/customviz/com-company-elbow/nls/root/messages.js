define({
  ELBOW_DISPLAY_NAME: 'Elbow Dendrogram',
  ELBOW_SHORT_DISPLAY_NAME: 'Elbow Dendrogram',
  ELBOW_CATEGORY: 'Elbow Dendrogram Plugin',
  ELBOW_ROW_LABEL: 'Elbow Dendrogram Plugin Row',
  ELBOW_ITEM_SIZE: 'Measure'
});
