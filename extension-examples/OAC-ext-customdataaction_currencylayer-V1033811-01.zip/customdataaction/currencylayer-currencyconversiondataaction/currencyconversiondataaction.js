define(
   [
      "jquery",
      "knockout",
      "obitech-framework/jsx",
      "obitech-application/extendable-ui-definitions",
      "obitech-application/gadgets",
	    "obitech-report/dataactiongadgets",
      "obitech-appservices/logger",
      "obitech-report/dataaction",
      "ojL10n!currencylayer-currencyconversiondataaction/nls/messages",
      "obitech-framework/messageformat",
      "skin!css!currencylayer-currencyconversiondataaction/currencyconversiondataactionstyles"
   ],
   function(
      $,
      ko,
      jsx,
      euidef,
      gadgets,
	    dataactiongadgets,
      logger,
      dataaction,
      messages
   )
   {
      "use strict";

      var MODULE_NAME = 'currencylayer-currencyconversiondataaction/currencyconversiondataaction';

      //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
      jsx.assertAllNotNullExceptLastN(arguments, "currencyconversiondataaction.js arguments", 2);

      var _logger = new logger.Logger(MODULE_NAME);

      /** This package provides the implementation for CurrencyConversionDataAction Plugin.
       * @exports currencylayer-currencyconversiondataaction/currencyconversiondataaction
       */
      var currencyconversiondataaction = {};

      var s_id;
	  var myGadgetInfo;
      // The version of this module
      currencyconversiondataaction.VERSION = "1.0.0";

      /**
       * @class This is the Knockout model used by CurrencyConversionDataAction.
       * @param {string} sClass The Data Action's classname.
       * @param {string} sID The Data Action's ID.
       * @param {string} sName The Data Action's name.
       * @param {string} [sVersion="1.0.0"] The version of the Data Action class used to create this Data Action instance.
       * @param {string} [sScopeID="project"] Identifies the DataAction scope. Either "project" for project-scope or a viz ID for viz-scope DataActions.
       * @param {string} [aAnchorToColumns=[]] The column the Data Action is anchored to (or null if the Data Action is not anchored to a column)
       * @param {string} [eValuePassingMode="all"] The "Value Passing" mode used when invoking this Data Action.
       * @param {string} [sAPIKey=""] The currencylayer API Access Key you received when you signed up for their service.
       * @param {string} [eFromCurrency="USD"] The currency code of the currency you want to convert from.
       * @param {string} [eToCurrency="EUR"] The currency code of the currency you want to convert to.
       * @extends module:obitech-report/dataaction.HTTPAPIDataActionKOModel
       */
      currencyconversiondataaction.CurrencyConversionDataActionKOModel = function (sClass, sID, sName, sVersion, sScopeID,myURL, myType, myAccessToken, myHeaders, myPostParams)
      {
         currencyconversiondataaction.CurrencyConversionDataActionKOModel.baseConstructor.call(this, sClass, sID, sName, sVersion, sScopeID);
         // Set defaults
    		 myURL = myURL || "Enter URL";
    		 myType = myType || "GET";
    		 myAccessToken = myAccessToken || "Enter your access Token Here";
    		 myHeaders = myHeaders || "";
    		 myPostParams = myPostParams || "";

         // Assertions
    		jsx.assertNonEmptyString(myURL,"myURL");
    		jsx.assertNonEmptyString(myType,"myType");

         this[currencyconversiondataaction.CurrencyConversionDataAction.CLASS_NAME] = {
    			myURL : ko.observable(myURL),
    			myType : ko.observable(myType),
    			myAccessToken: ko.observable(myAccessToken),
    			myHeaders : ko.observable(myHeaders),
    			myPostParams : ko.observable(myPostParams)
         };
      };
      jsx.extend(currencyconversiondataaction.CurrencyConversionDataActionKOModel, dataaction.HTTPAPIDataActionKOModel);

      /**
       * @class The CurrencyConversionDataAction Plugin class.
       * @param {module:currencylayer-currencyconversiondataaction/currencyconversiondataaction.CurrencyConversionDataActionKOModel} oDataActionKOModel The Data Action's Knockout model.
       * @extends module:obitech-report/dataaction.HTTPAPIDataAction

       */
      currencyconversiondataaction.CurrencyConversionDataAction = function (oDataActionKOModel)
      {
         currencyconversiondataaction.CurrencyConversionDataAction.baseConstructor.call(this, oDataActionKOModel);
      };
      jsx.extend(currencyconversiondataaction.CurrencyConversionDataAction, dataaction.HTTPAPIDataAction);

      /**
       * Defines class name of CurrencyConversionDataAction.
       * @type {String}
       * @static
       */
      currencyconversiondataaction.CurrencyConversionDataAction.CLASS_NAME = "currencylayer-currencyconversiondataaction/currencyconversiondataaction.CurrencyConversionDataAction";

      /** The CurrencyConversionDataAction Plugin class's current version. @type string */
      currencyconversiondataaction.CurrencyConversionDataAction.VERSION = "1.0.0";

      /**
       * Retrieves the versions that applies to the upgrade handler.
       * @static
       * @returns {Array.<String>} an array of versions that applies to the upgrade handler.
       */
      currencyconversiondataaction.CurrencyConversionDataAction.getUpgradeVersions = function ()
      {
         return [];
      };

      /**
       * This static method creates a new CurrencyConversionDataAction with the specified ID and Name.
       * @static
       * @param {string} sID The Data Action's ID.
       * @param {string} sName The Data Action's name.
       * @returns {module:currencylayer-currencyconversiondataaction/currencyconversiondataaction.CurrencyConversionDataAction} A new CurrencyConversionDataAction with the specified ID and Name.
       */
      currencyconversiondataaction.CurrencyConversionDataAction.create = function (sID, sName)
      {
         jsx.assertString(sID, "sID");
         jsx.assertString(sName, "sName");
         var oKOModel = new currencyconversiondataaction.CurrencyConversionDataActionKOModel("currencylayer-currencyconversiondataaction/currencyconversiondataaction.CurrencyConversionDataAction", sID, sName, currencyconversiondataaction.CurrencyConversionDataAction.VERSION);
         return new currencyconversiondataaction.CurrencyConversionDataAction(oKOModel);
      };

      /**
       * This method returns an object containing the AJAX settings used when the Data Action is invoked.
       * Subclasses may wish to override this method to provide their own behavior.
       * @param {module:obitech-reportservices/dataactionmanager.DataActionContext} oDataActionContext The context metadata describing where the Data Action was invoked from.
       * @returns {?object} A JQuery AJAX settings object (see http://api.jquery.com/jQuery.ajax/ for details) - returns null if there was a problem.
       */
      currencyconversiondataaction.CurrencyConversionDataAction.prototype.getAJAXOptions = function (oDataActionContext)
      {
         jsx.assertInstanceOfModule(oDataActionContext, "oDataActionContext", "obitech-reportservices/dataactionmanager", "DataActionContext");

         //var oAJAXOptions = currencyconversiondataaction.CurrencyConversionDataAction.superClass.getAJAXOptions.call(this, oDataActionContext);
		     var oAJAXOptions = {};
         var oKOViewModel = this.getKOViewModelByClass(currencyconversiondataaction.CurrencyConversionDataAction.CLASS_NAME);
         var oAbstractKOVM = this.getKOViewModelByClass();

         //oAJAXOptions.url = "http://apilayer.net/api/live?access_key=" + oKOViewModel.sAPIKey();
         oAJAXOptions.url = oKOViewModel.myURL();
		     oAJAXOptions.method = oKOViewModel.myType();
  		   //headers
    		 if(oKOViewModel.myHeaders() != ""){
    			 oAJAXOptions.headers = JSON.parse(oKOViewModel.myHeaders());
    		 }

    		 //data payload for non-GET requests
    		 if(oKOViewModel.myType() != "GET"){
    			if(oKOViewModel.myPostParams() != ""){
    				oAJAXOptions.data = JSON.parse(oKOViewModel.myPostParams());
    			}
    		 }
         // Get the ID for the column the Data Action has been anchored to.
         var aAnchorToColumns = oAbstractKOVM.aAnchorToColumns();
         var aAnchorToColumnIDs = [];
         for (var i = 0; i < aAnchorToColumns.length; i++)
         {
            aAnchorToColumnIDs.push(aAnchorToColumns[i].oColumn.sColumnID());
         }

         // Get the selected data-point value from the oDataActionContext.
         var selectedDataPoint = null;
         var oLogicalFilterTrees = oDataActionContext.getLogicalFilterTrees();
         oLogicalFilterTrees.forEachNode(function (oNode)
         {
            if (jsx.isNull(selectedDataPoint) && oNode.isLeaf() && jsx.Array.contains(aAnchorToColumnIDs, oNode.content.columnID))
            {
               selectedDataPoint = oNode.content.valueKey;
            }
         });

         // This function is called when the  API returns an HTTP 200 result code.
         oAJAXOptions.success = function (oData, sTextStatus, oJQXHR)
         {
           //add your code here to parse the data and implement meaningful solutions
            if (sTextStatus == "success")
            {
              //currency convertor response parsing
              if(oAbstractKOVM.sName()=="myDA1"){
                //logic to display currency convertor equivalent
                var conversionRate = oData.quotes.USDINR;
                var currenyEquivalent = selectedDataPoint*conversionRate;
                oDataActionContext.getReport().displaySuccessMessage( selectedDataPoint + " USD = " + currenyEquivalent.toFixed(2) + "INR");
              }else{
                oDataActionContext.getReport().displaySuccessMessage( oAbstractKOVM.sName() + " request invoked. Status Code:" + oJQXHR.status);
              }
            }
         };
         oAJAXOptions.error = function (jqXHR, ajaxOptions,throwError)
         {
           console.log(jqXHR.responseText);
           oDataActionContext.getReport().displayErrorMessage("Error invoking " + oAbstractKOVM.sName() + ". Status = " + jqXHR.state());
         };


         return oAJAXOptions;
      };

      /**
       * This method returns the Display Name for this type of Data Action.
       * @static
       * @returns {string} The Display Name for this type of Data Action.
       */
      currencyconversiondataaction.CurrencyConversionDataAction.getDisplayName = function ()
      {
         return messages.CURRENCYCONVERSIONDATAACTION_DISPLAY_NAME;
      };

      /**
       * This method returns an array of the GadgetInfos used to render the DataAction's configuration UI.
       * @memberof module:currencylayer-currencyconversiondataaction/currencyconversiondataaction.CurrencyConversionDataAction
       * @function getGadgetInfos
       * @param {module:obitech-report/report.Report} oReport The Report that the DataAction belongs to.
       * @returns {Array.<module:obitech-application/gadgets.AbstractGadgetInfo>} An array of the GadgetInfos used to render this DataAction's configuration UI.
       */
      currencyconversiondataaction.CurrencyConversionDataAction.prototype.getGadgetInfos = function (oReport)
      {
         jsx.assertInstanceOfModule(oReport, "oReport", "obitech-report/report", "Report");

		     var oDataActionKOVM = this.getKOViewModelByClass(currencyconversiondataaction.CurrencyConversionDataAction.CLASS_NAME);
         var aGadgetInfos = [];
         aGadgetInfos.push(this.createNameGadgetInfo(oReport));
         aGadgetInfos.push(this.createAnchorToGadgetInfo(oReport));

         // Although we need the PassValues Gadget for the code to work, we can hide it from the user.
         var oPassValuesGadgetInfo = this.createPassValuesGadgetInfo(oReport);
         oPassValuesGadgetInfo.setVisible(false);
         aGadgetInfos.push(oPassValuesGadgetInfo);
    		 aGadgetInfos.push(this.createHTTPMethodGadgetInfo(oReport));
    		 aGadgetInfos.push(this.createURLGadgetInfo(oReport));
    		 aGadgetInfos.push(this.createHeaderGadgetInfo(oReport));
    		 aGadgetInfos.push(this.createPostParamsGadgetInfo(oReport));
         return aGadgetInfos;
      };

      /**
       * This method creates the GadgetInfo used to render the Data Action's "API Key" field.
       * @memberof module:currencylayer.currencyconversiondataaction/currencyconversiondataaction.CurrencyConversionDataAction#
       * @function createAPIKeyGadgetInfo
       * @protected
       * @param {module:obitech-report/report.Report} oReport The Report that the DataAction belongs to.
       * @returns {module:obitech-application/gadgets.SingleSelectGadgetInfo} The GadgetInfo used to render the "API Key" field.
       */
      currencyconversiondataaction.CurrencyConversionDataAction.prototype.createURLGadgetInfo = function(/*oReport*/)
      {
         var oDataActionKOVM = this.getKOViewModelByClass(currencyconversiondataaction.CurrencyConversionDataAction.CLASS_NAME);
         var oAbstractKOVM = this.getKOViewModelByClass();
         var oGadgetProperties = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, oDataActionKOVM.myURL());
         //var oGadgetInfo = new gadgets.TextGadgetInfo("sMyURL" + oAbstractKOVM.sID(), "URL", "URL", oGadgetProperties,null,false,[],{sPlaceholderText: 'Enter the URL here'});
         var oGadgetInfo = new gadgets.TextGadgetInfo("sMyAccessToken" + oAbstractKOVM.sID(), messages.URL_KEY, messages.URL_KEY, oGadgetProperties, null, false,[],{sPlaceholderText:'Enter URL here'});
         // Update the DataAction's Knockout Model when the Gadget's Knockout Model changes.
         oGadgetInfo.getKOViewModel().value.subscribe(function (sNewValue) { oDataActionKOVM.myURL(sNewValue); });

         return oGadgetInfo;
      };

      /**
       * This static array contains the OptionInfos used to populate a SingleSelectGadgetInfo with the currency codes supported by this Data Action.
       * @static
       * @type Array.<module:obitech-application/gadgets.OptionInfo>
       */
      currencyconversiondataaction.CurrencyConversionDataAction.HTTP_CODE_OPTION_INFOS = [
         new gadgets.OptionInfo("GET", "GET"),
         new gadgets.OptionInfo("POST", "POST"),
         new gadgets.OptionInfo("PUT", "PUT"),
		     new gadgets.OptionInfo("DELETE", "DELETE"),
		     new gadgets.OptionInfo("TRACE", "TRACE")
      ];

      /**
       * This method creates the GadgetInfo used to render the Data Action's "From Currency" field.
       * @memberof module:currencylayer.currencyconversiondataaction/currencyconversiondataaction.CurrencyConversionDataAction#
       * @function createFromCurrencyCodeGadgetInfo
       * @protected
       * @param {module:obitech-report/report.Report} oReport The Report that the DataAction belongs to.
       * @returns {module:obitech-application/gadgets.SingleSelectGadgetInfo} The GadgetInfo used to render the "From Currency" field.
       */
      currencyconversiondataaction.CurrencyConversionDataAction.prototype.createHTTPMethodGadgetInfo = function(oReport)
      {
         var oDataActionKOVM = this.getKOViewModelByClass(currencyconversiondataaction.CurrencyConversionDataAction.CLASS_NAME);
         var oAbstractKOVM = this.getKOViewModelByClass();
         var oGadgetProperties = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.SINGLE_SELECT, oDataActionKOVM.myType());
         var oGadgetInfo = new gadgets.SingleSelectGadgetInfo("smyHttpType" + oAbstractKOVM.sID(), messages.HTTP_TYPE, messages.HTTP_TYPE, oGadgetProperties, null, false, currencyconversiondataaction.CurrencyConversionDataAction.HTTP_CODE_OPTION_INFOS);
		     var viz = this;
         // Update the DataAction's Knockout Model when the Gadget's Knockout Model changes.
         oGadgetInfo.getKOViewModel().value.subscribe(function (aNewValues) {
		   	 oDataActionKOVM.myType(aNewValues[0]);
		 });

         return oGadgetInfo;
      };


      currencyconversiondataaction.CurrencyConversionDataAction.prototype.createAccessTokenGadgetInfo = function(/*oReport*/)
      {
         var oDataActionKOVM = this.getKOViewModelByClass(currencyconversiondataaction.CurrencyConversionDataAction.CLASS_NAME);
         var oAbstractKOVM = this.getKOViewModelByClass();
         var oGadgetProperties = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, oDataActionKOVM.myAccessToken());
         var oGadgetInfo = new gadgets.TextGadgetInfo("sMyAccessToken" + oAbstractKOVM.sID(), messages.API_KEY, messages.API_KEY, oGadgetProperties, null, false);

         // Update the DataAction's Knockout Model when the Gadget's Knockout Model changes.
         oGadgetInfo.getKOViewModel().value.subscribe(function (sNewValue) { oDataActionKOVM.myAccessToken(sNewValue); });

         return oGadgetInfo;
      };


      currencyconversiondataaction.CurrencyConversionDataAction.prototype.createHeaderGadgetInfo = function(/*oReport*/)
      {
         var oDataActionKOVM = this.getKOViewModelByClass(currencyconversiondataaction.CurrencyConversionDataAction.CLASS_NAME);
         var oAbstractKOVM = this.getKOViewModelByClass();
         var oGadgetProperties = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_AREA, oDataActionKOVM.myHeaders());
		     var oGadgetInfo = new gadgets.TextAreaGadgetInfo("sMyHeaderField" + oAbstractKOVM.sID(), "Headers", messages.HEADER_FIELD, oGadgetProperties, null, false);
         // Update the DataAction's Knockout Model when the Gadget's Knockout Model changes.
         oGadgetInfo.getKOViewModel().value.subscribe(function (sNewValue) { oDataActionKOVM.myHeaders(sNewValue); });

         return oGadgetInfo;
      };
      /**
       * This method creates the GadgetInfo used to render the Data Action's "To Currency" field.
       * @memberof module:currencylayer.currencyconversiondataaction/currencyconversiondataaction.CurrencyConversionDataAction#
       * @function createToCurrencyCodeGadgetInfo
       * @protected
       * @param {module:obitech-report/report.Report} oReport The Report that the DataAction belongs to.
       * @returns {module:obitech-application/gadgets.SingleSelectGadgetInfo} The GadgetInfo used to render the "To Currency" field.
       */

      currencyconversiondataaction.CurrencyConversionDataAction.prototype.createPostParamsGadgetInfo = function(/*oReport*/)
      {
         var oDataActionKOVM = this.getKOViewModelByClass(currencyconversiondataaction.CurrencyConversionDataAction.CLASS_NAME);
         var oAbstractKOVM = this.getKOViewModelByClass();
         var oGadgetProperties = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_AREA, oDataActionKOVM.myPostParams());
		     var oGadgetInfo = new gadgets.TextAreaGadgetInfo("postParams" + oAbstractKOVM.sID(), "POST PARAMETERS", messages.PARAMS_FIELD, oGadgetProperties, null, false);
         // Update the DataAction's Knockout Model when the Gadget's Knockout Model changes.
         oGadgetInfo.getKOViewModel().value.subscribe(function (sNewValue) { oDataActionKOVM.myPostParams(sNewValue); });
         return oGadgetInfo;
      };

      /**
       * This method is called when the Data Action is invoked.
       * @memberof module:currencylayer-currencyconversiondataaction/currencyconversiondataaction.CurrencyConversionDataAction#
       * @function invoke
       * @param {module:obitech-framework/actioncontext.ActionContext} [oActionContext] The ActionContext for the user interaction that is reponsible for invoking this DataAction (some types of DataAction require this object, others do not).
       * @param {module:obitech-reportservices/dataactionmanager.DataActionContext} oDataActionContext The context metadata describing where the Data Action was invoked from (will be null if the Data Action's ValuePassingMode is set to NONE).
       */
      currencyconversiondataaction.CurrencyConversionDataAction.prototype.invoke = function (oActionContext, oDataActionContext)
      {
         // If you want to use the superclass's implementation for invoke(), keep the following line. Otherwise, replace it with your own implementation.
         currencyconversiondataaction.CurrencyConversionDataAction.superClass.invoke.call(this, oActionContext, oDataActionContext);
		 //this.invoke.call(this,oActionContext,oDataActionContext);
      };

      /**
       * This method returns a boolean that indicates whether the DataAction can be executed in the specified environment.
       * For example, some types of data action may not be allowed to run in Desktop or Embedded modes.
       * @memberof module:currencylayer-currencyconversiondataaction/currencyconversiondataaction.CurrencyConversionDataAction#
       * @function isAllowedHere
       * @param {module:obitech-report/report.Report} oReport The current Report.
       * @returns {boolean} A boolean indicating whether the DataAction can be run in the specified environment (true) or not (false).
       */
      currencyconversiondataaction.CurrencyConversionDataAction.prototype.isAllowedHere = function (oReport)
      {
         return currencyconversiondataaction.CurrencyConversionDataAction.superClass.isAllowedHere.call(this, oReport);
      };

      /**
       * This method returns a DataActionError describing the reason why the DataAction is invalid (or null if it is valid).
       * @memberof module:currencylayer-currencyconversiondataaction/currencyconversiondataaction.CurrencyConversionDataAction
       * @function validate
       * @returns {?module:obitech-report/dataaction.DataActionError} A DataActionError describing the reason why the DataAction is invalid (or null if it is valid).
       */
      currencyconversiondataaction.CurrencyConversionDataAction.prototype.validate = function ()
      {
         // Start by asking the super class to validate the Data Action.
         //var oError = currencyconversiondataaction.CurrencyConversionDataAction.superClass.validate.call(this);
         // If the super class didn't find an error then look for errors specific to this subclass.
         //if (!oError)
         //{
			      var oError;
            var oKOVM = this.getKOViewModelByClass(currencyconversiondataaction.CurrencyConversionDataAction.CLASS_NAME);
            var oAbstractKOVM = this.getKOViewModelByClass();
            if (!oKOVM.myURL())
            {
               oError = new dataaction.DataActionError(oAbstractKOVM.sID(), "URL is neccessary for HTTP request");
			         return oError;
            }
    			if(oKOVM.myType() == "POST"){
    				if(!oKOVM.myPostParams()){
    					oError = new dataaction.DataActionError(oAbstractKOVM.sID(), "Post Req needs data to be sent");
    				}
    			}
         //}
         return oError;
      };

   return currencyconversiondataaction;
});
