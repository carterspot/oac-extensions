define({
   "API_KEY": "API KEY",
   "URL_KEY": "URL",
   "HTTP_TYPE": "HTTP Method",
   "HEADER_FIELD": "Header Parameters in JSON format. Leave it empty if you do not have any header information",
   "PARAMS_FIELD": "Enter Post parameters in JSON format. Leave this empty for GET request and when not required",
   "FROM_CURRENCY": "From Currency",
   "TO_CURRENCY": "To Currency",
   "CURRENCYCONVERSIONDATAACTION_DISPLAY_NAME": "Generic HTTP API DATA ACTION",
   "CURRENCYCONVERSIONDATAACTION_SHORT_DISPLAY_NAME": "Generic HTTP API DATA ACTION",
   "URLEDITOR_PLACEHOLDER": "Enter the header parameters here",
   errors: {
      "MISSING_URL": "The URL cannnot be empty for http API: {0}"
   }
});