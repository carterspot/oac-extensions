/********************************* Text Highlight Language Plugin **************************************** */

/**********step 1: Define Libraries *******/

define(['jquery',
        'obitech-framework/jsx',
        'obitech-report/datavisualization',
        'obitech-legend/legendandvizcontainer',
        'obitech-reportservices/datamodelshapes',
        'obitech-reportservices/events',
        'obitech-reportservices/interactionservice',
        'obitech-reportservices/markingservice',
        'obitech-application/gadgets',
        'obitech-report/visualization',
        'obitech-report/gadgetdialog',
        'obitech-application/bi-definitions',
        'obitech-appservices/logger',
        'ojL10n!com-company-texthighlight/nls/messages',
        'obitech-application/extendable-ui-definitions',
        'obitech-reportservices/data',
        'd3v6js',
        'knockout',
        'ojs/ojattributegrouphandler',
        'obitech-framework/messageformat',
        'skin!css!com-company-texthighlight/textHighlightstyles'],
        function($,
                 jsx,
                 dataviz,
                 legendandvizcontainer,
                 datamodelshapes,
                 events,
                 interactions,
                 marking,
                gadgets,
                viz,
                gadgetdialog,
                definitions,
                logger,
                messages,
                euidef,
                data,
                d3,
                ko,
                attributeGroupHandler) {
   "use strict";

   var MODULE_NAME = 'com-company-texthighlight/textHighlight';

   //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   jsx.assertAllNotNullExceptLastN(arguments, "textHighlight.js arguments", 2);

   var _logger = new logger.Logger(MODULE_NAME);

   // The version of our Plugin
   TextHighlight.VERSION = "1.0.0";

   /**
    * The implementation of the textHighlight visualization.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @extends {module:obitech-report/visualization.Visualization}
    * @memberof module:com-company-texthighlight/textHighlight#
    */
   function TextHighlight(sID, sDisplayName, sOrigin, sVersion) {
      // Argument validation done by base class
      TextHighlight.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);
      var displayLabel = 'On';
      var xDisplayName ='';
      var rowDisplayNames=[];
      var cID = '';
      var tabInfo = '';

      this.Config = {
        displayLabel: 'On',
        xDisplayName: '',
        cID: '',
        rowDisplayNames: new Map()       
    }

    this._saveSettings = function() {
        this.getSettings().setViewConfigJSON(dataviz.SettingsNS.CHART, this.Config);
    };
        
    
    this.loadConfig = function (){
        var conf = this.getSettings().getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
        if (conf.displayLabel) this.Config.displayLabel = conf.displayLabel;
        if (conf.rowDisplayNames) this.Config.rowDisplayNames = conf.rowDisplayNames;
        if (conf.xDisplayName) this.Config.xDisplayName = conf.xDisplayName;
        if (conf.cID) this.Config.cID = conf.cID;
    }

    
    this.getXDisplayName = function(){
        return(this.Config.xDisplayName);
    };

    this.setXDisplayName = function (o){
        this.Config.xDisplayName = o;
    };

    this.getRowDisplayNames = function(){
        return(this.Config.rowDisplayNames);
    };

    this.setRowDisplayNames = function (o){
        this.Config.rowDisplayNames = o;
    };

    this.getCID = function(){
      return(this.Config.cID);
  };

  this.setCID = function (o){
      this.Config.cID = o;
  };

  this.getTabInfo = function(){
    return(tabInfo);
};

this.setTabInfo = function (o){
    tabInfo = o;
};
   /**
             * @type {Array.<String>} - The array of selected items
             */
   var aSelectedItems = new Map();

   /**
    * @return  {Array.<String>} - The array of selected items
    */
   this.getSelectedItems = function(){
       return aSelectedItems;
   };

   /**
    * Clears the current list of selected items
    */
   this.clearSelectedItems = function(){
       aSelectedItems = new Map();
   };



   };
   jsx.extend(TextHighlight, dataviz.DataVisualization);
   /**
    * Called whenever new data is ready and this visualization needs to update.
    * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
    */
   
  /****************************** Generate Data Function ***************************/

    TextHighlight.prototype._generateData = function(oDataLayout, oTransientRenderingContext){
              
             var oDataModel = this.getRootDataModel();
             if(!oDataModel || !oDataLayout){
                 return;
             }
          //   this.setRowDisplayNames(new Map());
          
             var aAllMeasures = oDataModel.getColumnIDsIn(datamodelshapes.Physical.DATA);
             var nMeasures = aAllMeasures.length;
             var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
             var nRowLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
             var nCols = oDataLayout.getEdgeExtent(datamodelshapes.Physical.COLUMN);
             var nColLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.COLUMN);
             var oDataLayoutHelper = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT_HELPER);
             var oColorContext = this.getColorContext(oTransientRenderingContext);
             var oColorInterpolator = this.getCachedColorInterpolator(oTransientRenderingContext, datamodelshapes.Logical.COLOR);
             var detail_displayName;
             var sColor = true;
                        
             
             
             //Get the display names of the rows
             for(var nRow = 0; nRow < nRowLayerCount; nRow++){
                 var rowKey = oDataLayoutHelper.getLogicalEdgeName(datamodelshapes.Physical.ROW, nRow);
                var displayName = oDataLayout.getLayerMetadata(datamodelshapes.Physical.ROW, nRow, data.LayerMetadata.LAYER_DISPLAY_NAME);
                this.getRowDisplayNames().set(rowKey, {order: nRow, name: displayName});
                 if(rowKey == "row"){
                     this.setXDisplayName(displayName);
                    // columnNames.push(displayName);
                 }
             }
             var xSet = new Set();
             var dataArray =[];  
             var isPushed;
             for(var nRow = 0; nRow < Math.max(nRows, 1); nRow++) {
                isPushed = false;
                 var row = "", colorObj, color = "", parameters = "", tooltip;
                 var point = "";
                 var displayName="";
                 var previousRow="";
                 var previousValue="";
                 var rowLayerValue;
                 var off_set = "";
                 var glyph_rowValue;
                 var length_ = "";
                 var sourceColor, sourceColorVal;
                 var value = parseFloat(oDataLayout.getValue(datamodelshapes.Physical.DATA, nRow, 0));                 
                 for (var nRowLayer = 0; nRowLayer < Math.max(nRowLayerCount, 1); nRowLayer++) {
                     var rowType = oDataLayoutHelper.getLogicalEdgeName(datamodelshapes.Physical.ROW, nRowLayer);
                      displayName = oDataLayout.getLayerMetadata(datamodelshapes.Physical.ROW, nRowLayer, data.LayerMetadata.LAYER_DISPLAY_NAME);           
                      switch (rowType) {    
                         case "row":                          
                             row = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                             if(dataArray.length == 0 || isPushed == false)
                             {
                                if(dataArray.length == 0)
                                {
                                dataArray.push([displayName]);                           
                                rowLayerValue = nRowLayer;
                                }
                                if(!isNaN(row))
                                      {
                                        row = parseFloat(row).toFixed(2);  //round off measures to 2 decimal places
                                      }
                                dataArray.push([row]);
                                previousRow = row;
                             }  
                             else
                             {
                                for(var item in dataArray)
                                {
                                    if(nRowLayer != rowLayerValue && nRow == 0)
                                    {
                                      dataArray[0].push(displayName);
                                      rowLayerValue = nRowLayer;
                                    }
                                    else
                                    {
                                      if(!dataArray[0].includes(displayName)  && dataArray[0][item]!= undefined)
                                      {
                                      dataArray[0].push(displayName);
                                      }
                                    }
                                }
                                var length = dataArray.length.toString();
                                if(dataArray[length - 1][0] == previousRow)
                                { 
                                    if(!isNaN(row))
                                      {
                                        row = parseFloat(row).toFixed(2);   //round off measures to 2 decimal places
                                      }
                                    dataArray[length -1].push(row);
                                }
                             }  
                             isPushed = true;                        
                             break;

                             case "glyph":
                             parameters = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                             if(off_set == "" && glyph_rowValue != nRow)
                             {
                              off_set = parameters;
                              glyph_rowValue = nRow;
                             }
                             else length_ = parameters;                      
                             break;

                             
                         case "detail":
                             value = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);  
                             detail_displayName = displayName;
                             if(dataArray.length == 0 || isPushed == false)
                             {
                                if(dataArray.length == 0)
                                {
                                dataArray.push([displayName]);
                              
                                rowLayerValue = nRowLayer;
                                }
                                dataArray.push([value]);
                                previousRow = value;
                             }  
                             else
                             {
                             for(var item in dataArray)
                             {
                              if(nRowLayer != rowLayerValue && nRow == 0)
                              {
                                dataArray[0].push(displayName);
                                rowLayerValue = nRowLayer;
                              }
                              else
                              {
                                 if(!dataArray[0].includes(displayName)  && dataArray[0][item]!= undefined)
                                 {
                                 dataArray[0].push(displayName);
                                
                                 }
                                }
                             }
                             displayName.toLowerCase();
          
                             var length = dataArray.length.toString();
                             if(dataArray[length - 1][0] == previousRow)
                             {   
                                var offset0 =parseInt(off_set);
                                var length0 =parseInt(length_) + offset0;
                                var substr = value.substring((offset0-1),length0);
                                if(substr.includes('<br'))
                                {
                                  substr= substr.replace('<br',' ');
                                }

                          if (isNaN(offset0))
                          {
                            value = value;
                        }
                          else 
                          {
                            previousValue = value;
                        //  value = value.replace(/>/g, "&gt;");
                            value = value.substring(0,(offset0 - 1)) + '<b style = "color : blue !important">' + substr + '</b>' + value.substring(length0, value.length);
                          }                                                         
                             dataArray[length -1].push(value);
                        }
                        }
                          isPushed = true;           
                                break;

                         case "color":
                             colorObj = this.getDataItemColorInfo(oDataLayoutHelper, oColorContext, oColorInterpolator, nRow, 0);
                             color = colorObj.sSeriesColorLabel;
                             if(color == "Positive")
                                       {
                                        sourceColorVal = "green";
                                       } 
                            else if (color == "Negative")
                                      {
                             sourceColorVal = "red";
                                      } 
                           else if (color == "Neutral")
                                      {
                             sourceColorVal = "blue";
                                      } 
                           else if (color == "Mixed")
                                      {
                             sourceColorVal = "orange";
                                    } 
                              else sourceColorVal = colorObj.sColor ? colorObj.sColor : colorObj.sSeriesColor;
                            
                             if(dataArray.length == 0 || isPushed == false)
                             {
                                if(dataArray.length == 0)
                                {
                                  rowLayerValue = nRowLayer;
                                  dataArray.push([displayName]);                                
                                }                             
                                dataArray.push([color]);
                                previousRow = color;
                             }  
                             else
                             {
                                for(var item in dataArray)
                                {
                                  if(nRowLayer != rowLayerValue)
                                  {
                                    dataArray[0].push(displayName);                               
                                    rowLayerValue = nRowLayer;
                                  }
                                  else
                                  {          
                                    if(!dataArray[0].includes(displayName)  && dataArray[0][item]!= undefined)
                                    {
                                      dataArray[0].push(displayName);
                                    }
                                  }
                                }                               
                                var length = dataArray.length.toString();
                                if(dataArray[length - 1][0] == previousRow)
                                {
                                  var offset0 =parseInt(off_set);
                                  var length0 =parseInt(length_) + offset0;
                                  if(isNaN(offset0) || isNaN(length))
                                  {
                                  } 
                                  else
                                  {
                                  var substr = previousValue.substring((offset0-1),length0);
                                  if(substr.includes('<br'))
                                {
                                  substr= substr.replace('<br',' ');
                                 }

                                  if (detail_displayName != "" || detail_displayName != null)
                                  {
                                    var detailIndex = dataArray[0].indexOf(detail_displayName);
                                    var detailsVal = dataArray[length-1][detailIndex];
                                    /******************* for generic use *****************/
                                   dataArray[length-1][detailIndex] =previousValue.substring(0,(offset0 - 1)) + '<b style = "color :'+sourceColorVal+'!important">' + substr + '</b>' + previousValue.substring(length0, previousValue.length);
                                   color = '<b style = "color :'+sourceColorVal+'!important">'+color+'</b>'

                                  }
                                }
                                    dataArray[length -1].push(color);
                                }
                             }  
                             isPushed = true;  
                             break;
                     }
                    
                 }
                }
                
             return dataArray;
     
         } 
  
        /****************************** Render Function ***********************************/ 

   TextHighlight.prototype._render = function(oTransientRenderingContext) {
      try {
        this.loadConfig();
         // Note: all events will be received after initialize and start complete.  We may get other events
         // such as 'resize' before the render, i.e. this might not be the first event.

         // Retrieve the data object for this visualization
         var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
         if (!oDataLayout)
                    return;
         var oData = this._generateData(oDataLayout, oTransientRenderingContext);
                    if(!oData) {
                       return;
                       }           

         // Determine the number of records available for rendering on ROW
         // Because we specified that Category should be placed on ROW in the data model handler,
         // this returns the number of rows for the data in Category.
         var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
        
         // Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
         // but may be used to render.
         
        // $(elContainer).html(messages.TEXT_MESSAGE.format("TextHighlight Plugin", "" + nRows));
        /********************************* Duplicate Viz ********************************************/
                var elContainer = this.getContainerElem();
                var sVizContainerId = this.getSubElementIdFromParent(this.getContainerElem(), "hvc");
                var pane = sVizContainerId.substring(sVizContainerId.indexOf("view")+5,sVizContainerId.indexOf("pane"));
                var conetentPane = sVizContainerId.substring(sVizContainerId.indexOf("contentpane_")+12,sVizContainerId.indexOf("vizCont")-1);
                var cId = pane+"_"+conetentPane;  //For duplicating viz
                var oViz = this;
                this.setCID(cId);
                var htmlContent = "<div id=tableViz"+cId+"></div>";  //setting Div ID
         

          $(elContainer).html(htmlContent);
          elContainer.style.overflow = "auto"; //Scrolling - auto
        
          var width = $(elContainer).width();     // set dynamic width of table
          var height = $(elContainer).height();   // set dynamic height of table
            var margin = {top: 40, right: 40 , bottom: 40, left: 100},
          width = width - margin.left - margin.right,
          height = height - margin.top - margin.bottom;
           

          
          var obj = this; 
          var rowIndex = -1;

          /************ Tabular Function *************/

          var tabulate = function (oData,obj) {
            
           
              var table = d3.select("#tableViz"+cId).append('table').attr("class", "text_highlight")
                  .attr("viewBox", `10 10 ${(width-20)} ${(height)}`)
                  .style("border-collapse", "collapse")
                  .attr("width", width-20)
                  .attr("height", "111px")
                 .style("max-width", "800px");

              table.append("thead").append("tr");

              /******************** Table Headers ************************/
              var headers = table.select("tr")
                  .selectAll("th")
                  .data(oData[0])
                  .enter().append("th")
                  .text(function(d) { return d; })                  
                  .style("border", "0.5px gray solid")
                  .style("padding", "5px")
                  .style("background-color", "whitesmoke")
                  .style("font-weight", "normal")
                  .style("text-transform", "capitalize")
                  .style("font-size", "11px")
                  .style("max-width", "800px")
                  .style("word-wrap","break-word")
                  .on("click", function(event, d)
                  {         
                    $("tr").addClass("removemark");
                    $("tr").removeClass("testmark");
                 });
                  
                     
          // data
          table.append("tbody");

          /**************** Table Rows ***********************/

          var rows = table.select("tbody")
          .selectAll("tr").data(oData.slice(1))       
          .enter().append("tr").attr("class", "textTr")
          .on("click", function(event, d)
          {         
        rowIndex = event.currentTarget.rowIndex ;
        rowIndex = rowIndex - 1;
        var oMarkingService = obj.getMarkingService();
        if(!event.ctrlKey) {
            oMarkingService.clearMarksForDataLayout(oDataLayout);
            /* Clear existing background color on tr*/
          //   $.getElementById('tableViz'+cId).select("tbody").find('tr').each(function(){
          //     this.style.backgroundColor = "white";
          // })
            }
        var selectedItems = obj.getSelectedItems();
      //  $(this).parent().children().css("background-color","white"); 
       // this.style.backgroundColor = '#E5F4DC';
       //d3.select("this").style("background-color", "#E5F4DC");
        
       
      $("tr").removeClass("testmark");
      $("tr").addClass("removemark");
      $(this).addClass("testmark");

      $("tr").focusout(
        function (){
          $(this).style.backgroundColor = "white";
        }
      );
    
        oMarkingService.setMark(oDataLayout, datamodelshapes.Physical.DATA, parseInt(rowIndex), 0); //check manually
     $("tr[data-row='"+rowIndex+"']").addClass("testmark");
       selectedItems.set( parseInt(rowIndex), 0);      
       obj._publishMarkEvent(oDataLayout); 
      
            
          })
          .selectAll("td")
          .data(function(d)
          {                
            return d;
          })
          .enter().append("td").attr("class", "textTd")
          .style("border", "0.5px gray solid")
          .style("padding", "5px")
          .html(function(d){
            return d;})
          .style("font-size", "11px")
          .style("max-width", "800px")
          .style("word-wrap","break-word");

          
          
              return table;
          }
          tabulate(oData,obj);
      
         /************************ To get index values in Data Row **************************/
          var x = document.getElementsByClassName("textTr"); 
          var i;
          for (i = 0; i < x.length;i++) {
          const att = document.createAttribute("data-row");
          att.value = x[i].rowIndex - 1;
          x[i].setAttributeNode(att);
          }
        }
      finally {
         this._setIsRendered(true);
      }
    }
    /**
         * Called whenever new data is ready and this visualization needs to update.
         * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
         */
     TextHighlight.prototype.render = function(oTransientRenderingContext) {
      // Note: all events will be received after initialize and start complete.  We may get other events
      // such as 'resize' before the render, i.e. this might not be the first event.

      this._render(oTransientRenderingContext);
      //this.renderLegend(oTransientRenderingContext);
      //this._buildSelectedItems(oTransientRenderingContext);
  };
    
   /**
     * Resize the visualization
     * @param {Object} oVizDimensions - contains two properties, width and height
     * @param {module:obitech-report/vizcontext#VizContext} oTransientVizContext the viz context
     */
    TextHighlight.prototype.resizeVisualization = function(oVizDimensions, oTransientVizContext){
      var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
      this._render(oTransientRenderingContext);
  };

  /**
         * Re-render the visualization when settings changes
         */
   TextHighlight.prototype._onDefaultSettingsChanged = function(){
    var oTransientVizContext = this.assertOrCreateVizContext();
    var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
    this.render(oTransientRenderingContext);
    this._setIsRendered(true);
};

TextHighlight.prototype._publishMarkEvent = function (oDataLayout, eMarkContext) {

  try {
      // Create the marking event
      var markingEvent = new interactions.MarkingEvent(this.getID(), this.getViewName(), oDataLayout, null, eMarkContext);
      var eventRouter = this.getEventRouter();
      if (eventRouter) {
          // Publish the event to listeners
          eventRouter.publish(markingEvent);
      }
  }
  catch (e) {
      console.log("Error during mark", e);
  }
};

/**
         * Override to add in options to the context menu
         *
         * @param {module:obitech-report/vizcontext#VizContext} oTransientVizContext the viz context
         * @param {string} sMenuType The menu type associated with the context menu being populated
         * @param {Array} The array of resulting menu options
         * @param {module:obitech-appservices/contextmenu} contextmenu The contextmenu namespace object (used to reduce dependencies)
         * @param {object} evtParams The entire 'params' object that is extracted from client evt
         * @param {object} oTransientRenderingContext the current transient rendering context
         */

 TextHighlight.prototype._addVizSpecificMenuOptions = function(oTransientVizContext, sMenuType, aResults, contextmenu, evtParams, oTransientRenderingContext){
  aResults.shift();
  TextHighlight.superClass._addVizSpecificMenuOptions.call(this, oTransientVizContext, sMenuType, aResults, contextmenu, evtParams, oTransientRenderingContext);
  if (sMenuType === euidef.CM_TYPE_VIZ_PROPS) {
      // Set up the column context for the last column in the ROWS bucket
      var oColumnContext = this.getDrillPathColumnContext(oTransientVizContext, datamodelshapes.Logical.ROW);

      // Set up events
          if(!this.isViewOnlyLimit()){
               this._addFilterMenuOption(oTransientVizContext, aResults, null, null, oTransientRenderingContext);
              this._addRemoveSelectedMenuOption(oTransientVizContext, aResults, null, null, oTransientRenderingContext);
              //this._addDrillMenuOption(oTransientVizContext, aResults, null, null, oColumnContext, oTransientRenderingContext);
              //this._addLateralDrillMenuOption(oTransientVizContext, aResults);
          }

  }
};

TextHighlight.prototype._addVizSpecificPropsDialog = function (oTabbedPanelsGadgetInfo) {

  // var options = this.getViewConfig() || {};
  //  this._fillDefaultOptions(options, null);
  // this._addLegendToVizSpecificPropsDialog(options, oTabbedPanelsGadgetInfo);

 this.doAddVizSpecificPropsDialog(this, oTabbedPanelsGadgetInfo);
 TextHighlight.superClass._addVizSpecificPropsDialog.call(this, oTabbedPanelsGadgetInfo);

};

     /**
         * TODO: Legend should take care of this
         * Given an options / config object, configure it with default options for the visualization.
         *
         * @param {object} oOptions the options
         * @param {module:obitech-framework/actioncontext#ActionContext} oActionContext The ActionContext instance associated with this action
         * @protected
         */

      TextHighlight.prototype._fillDefaultOptions = function (oOptions/*, oActionContext*/) {
        if (!jsx.isNull(oOptions) && !jsx.isNull(oOptions.legend))
            return;

        // Legend
        oOptions.legend = jsx.defaultParam(oOptions.legend, {});
        oOptions.legend.rendered = jsx.defaultParam(oOptions.legend.rendered, "on");
        oOptions.legend.position = jsx.defaultParam(oOptions.legend.position, "auto");

        this.getSettings().setViewConfigJSON(dataviz.SettingsNS.CHART, oOptions);
    };
     
    TextHighlight.prototype.doAddVizSpecificPropsDialog = function (oTransientRenderingContext, oTabbedPanelsGadgetInfo) {
      jsx.assertObject(oTransientRenderingContext, "oTransientRenderingContext");
      jsx.assertInstanceOf(oTabbedPanelsGadgetInfo, gadgets.TabbedPanelsGadgetInfo, "oTabbedPanelsGadgetInfo", "obitech-application/gadgets.TabbedPanelsGadgetInfo");

      var oDataModel = this.getRootDataModel();

      this.setTabInfo(oTabbedPanelsGadgetInfo);
      var viewConfig = this.getViewConfig() || {};
      var options = this.getViewConfig() || {};
      //this._fillDefaultOptions(options, oTransientRenderingContext.get(viz.ContextProperty.ACTION_CONTEXT));
      this._fillDefaultOptions(options, null);
      /*var valuePanel = gadgetdialog.forcePanelByID(oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_VALUE);
      this.setValuePanel(valuePanel);*/
      var generalPanel = gadgetdialog.forcePanelByID(oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_GENERAL);

      var oGadgetFactory = this.getGadgetFactory();

      if (TextHighlight.superClass.doAddVizSpecificPropsDialog)
      TextHighlight.superClass.doAddVizSpecificPropsDialog.apply(this, arguments);
  };

  TextHighlight.prototype._handlePropChange = function (sGadgetID, oPropChange, oViewSettings, oActionContext){
    var updateSettings = TextHighlight.superClass._handlePropChange.call(this, sGadgetID, oPropChange, oViewSettings, oActionContext);
    if (updateSettings) {
        return updateSettings; // super handled it
    }

    // Allow the super class an attempt to handle the changes
    var conf = oViewSettings.getViewConfigJSON(dataviz.SettingsNS.CHART) || {};

    return updateSettings;
};

/**
         * Builds the list of selected items
         * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext - The rendering context
         */

 TextHighlight.prototype._buildSelectedItems = function(oTransientRenderingContext){
  var oViz = this;
  var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
  var oMarkingService = this.getMarkingService();

  function fMarksReadyCallback() {
    
      oViz.clearSelectedItems();
      var aSelectedItems = oViz.getSelectedItems();
      //var selectedMap = new Map();

      if(!oViz.isStarted()) {
          return;
      }
      oMarkingService.traverseDataEdgeMarks(oDataLayout, function (nRow, nCol) {
          console.log("traverseDataEdgeMarks: "+ nRow + ':' + nCol);
          aSelectedItems.set(nRow, nCol);
    
      });
      for(let row of aSelectedItems.keys())
     
   $("tr").parent().children().removeClass("testmark");
   $("tr").parent().children().addClass("removemark");
      for(let row of aSelectedItems.keys()){
          $("tr[data-row='"+row+"']").addClass("testmark");
      }
     // oViz._render(oTransientRenderingContext);
  }
  oMarkingService.getUpdatedMarkingSet(oDataLayout, marking.EMarkOperation.MARK_RELATED, fMarksReadyCallback);
};

 /**
     * React to marking service highlight events
     */
 TextHighlight.prototype.onHighlight = function(){
  var oTransientVizContext = this.assertOrCreateVizContext();
  var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
  this._buildSelectedItems(oTransientRenderingContext);
}; 


 /**
     * Override _doInitializeComponent in order to subscribe to events
     */
 TextHighlight.prototype._doInitializeComponent = function() {
  TextHighlight.superClass._doInitializeComponent.call(this);

  //this.subscribeToEvent(events.types.DEFAULT_SETTINGS_CHANGED, this._onDefaultSettingsChanged, "**");
  this.subscribeToEvent(events.types.INTERACTION_HIGHLIGHT, this.onHighlight, this.getViewName() + "." + events.types.INTERACTION_HIGHLIGHT);

  //this.initializeLegendAndVizContainer();
};
   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the visualization
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {string=} sVersion 
    * @returns {module:com-company-texthighlight/textHighlight.TextHighlight}
    * @memberof module:com-company-texthighlight/textHighlight
    */
   function createClientComponent(sID, sDisplayName, sOrigin) {
     // Argument validation done by base class
      return new TextHighlight(sID, sDisplayName, sOrigin, TextHighlight.VERSION);
   };

   return {
      createClientComponent : createClientComponent
   };
});