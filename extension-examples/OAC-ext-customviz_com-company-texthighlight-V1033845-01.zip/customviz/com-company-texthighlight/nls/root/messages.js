define({
    "TEXTHIGHLIGHT_DISPLAY_NAME": "TextHighlight Plugin",
    "TEXTHIGHLIGHT_SHORT_DISPLAY_NAME": "TextHighlight Plugin",
    "TEXTHIGHLIGHT_CATEGORY":"Text to Highlight",
    "TEXTHIGHLIGHT_ROW_LABEL":"Rows",
    "TEXTHIGHLIGHT_SHAPE":"Offset & Length (attr)",
    "TEXT_MESSAGE": "Hello!  This is the {0} visualization and I have {1} rows of data."

});