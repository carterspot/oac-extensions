define(['jquery',
        'obitech-framework/jsx',
        'obitech-application/extendable-ui-definitions',
        'obitech-report/gadgetdialog',
        'obitech-application/gadgets',
        "obitech-report/visualization",
        'obitech-framework/actioncontext',
        'obitech-report/datavisualization',
        'obitech-application/bi-definitions',
        'obitech-reportservices/events',
        'obitech-appservices/logger',
        'knockout',
        'ojs/ojcore',
        'obitech-framework/jetfactory2',
        'ojL10n!com-oracle-themenubar/nls/messages',
        'obitech-framework/messageformat',
        'skin!css!com-oracle-themenubar/themenubarstyles'],
        function($,
                 jsx,
                 euidef,
                 gadgetdialog,
                 gadgets,
                 visualization,
                 actioncontext,
                 dataviz,
                 definitions,
                 events,
                 logger,
                 ko,
                 oj,
                 jetfactory2,
                 messages) {
   "use strict";

   var MODULE_NAME = 'com-oracle-themenubar/themenubar';

   //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   jsx.assertAllNotNullExceptLastN(arguments, "themenubar.js arguments", 2);

   var _logger = new logger.Logger(MODULE_NAME);

   // The version of our Plugin
   Themenubar.VERSION = "1.0.0";

   /**
    * The implementation of the themenubar visualization.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @extends {module:obitech-report/visualization.Visualization}
    * @memberof module:com-oracle-themenubar/themenubar#
    */
   function Themenubar(sID, sDisplayName, sOrigin, sVersion) {
      // Argument validation done by base class
      Themenubar.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);
   };
   jsx.extend(Themenubar, visualization.Visualization);
   /**
    * Called whenever this visualization needs to update.
    */
   Themenubar.prototype.render = function() {
      // Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
      // but may be used to render.
      try {
         var elContainer = this.getContainerElem();
         
         //clear the container
         $(elContainer).empty();
         
         var sInputJSON = this.getViewConfig().buttonTypeValue;
         var aInputJSON;
         var bIsValidInput = false;
         try {
            aInputJSON = JSON.parse(sInputJSON);
            bIsValidInput = true;
         } catch (e) {
            aInputJSON = undefined;
            bIsValidInput = false;
         }

         if (!bIsValidInput) {
            var sMsg = messages.MISSING_JSON_MESSAGE
            // This is the invalid case
            $(elContainer).html("<div class=\"custom-Menu-Bar-Error\"><span class=\"bi-va-icon-info_16\"></span><p>" + sMsg + "</p></div>");
            return;
         }
         
         for (let i = 0; i < aInputJSON.buttons.length; i++) {
            const button = aInputJSON.buttons[i];
            let menuID = "themenubar-" + Math.floor(Math.random() * 1000000);
            let elMenuButton;

            if(button.items != null){
               //create the button with a menu
               var oJetFactoryMenuButtonOptions = {
                  menuId: menuID,
                  class:"custom-menu-bar",
                  tooltip: button.tooltip,
                  showText: true,
                  'label': button.name,
                  ariaLabel: button.name
                  };
               elMenuButton = jetfactory2.createMenuButton(oJetFactoryMenuButtonOptions, false);
               elMenuButton.style["background-color"] = button.backgroundColor;
               elMenuButton.style["width"] = button.width;
               let aMenuOptions = [];
               for (let j = 0; j < button.items.length; j++) {
                  const menuitem = button.items[j];
                  aMenuOptions.push({
                     value: 'options-menu-' + menuitem.name,
                     label: menuitem.name,
                     disabled: false,
                     checkable: false,
                     callback: function() {
                        var target = '_blank';
                        if (menuitem.sameWindow){
                           target = '_self';
                        }
                        
                        window.open(menuitem.url, target);
                     }
                  });
               }
             
               let elMenu = jetfactory2.createMenu({options: aMenuOptions, parent: elMenuButton}, false);
               elMenu.setAttribute("slot","menu");
               elMenuButton.appendChild(elMenu);
               ko.applyBindings({}, $(elMenuButton).get(0));
            

               oj.Context.getContext(elMenu).getBusyContext().whenReady().then(this.createCallback(function () {
                  elMenu.open("");
                  elMenuButton.getElementsByTagName("button")[0].style["color"] = button.textColor;
               }));
            }
            else{
                //create a standalone button
               var oButtonOptions = {
                  id: menuID,
                  class:"custom-menu-bar",
                  tooltip: button.tooltip,
                  showText: true,
                  'label': button.name,
                  ariaLabel: button.name,
                  clickListener: function() {
                     var target = '_blank';
                     if (button.sameWindow){
                        target = '_self';
                     }
                     
                     window.open(button.url, target);
                  }
               };
               elMenuButton = jetfactory2.createButton(oButtonOptions, false);
               elMenuButton.style["background-color"] = button.backgroundColor;
               elMenuButton.style["width"] = button.width;
               ko.applyBindings({}, $(elMenuButton).get(0));
            }
            
            elContainer.appendChild(elMenuButton);
            oj.Context.getContext(elMenuButton).getBusyContext().whenReady().then(this.createCallback(function () {
               elMenuButton.getElementsByTagName("button")[0].style["color"] = button.textColor
               elMenuButton.getElementsByTagName("button")[0].style["background"] = "transparent";
               elMenuButton.getElementsByTagName("button")[0].style["border"] = "0px";
            }));
         }
      }
      finally{
         this._setIsRendered(true);
      }
   };

   Themenubar.prototype._addVizSpecificPropsDialog = function (oTabbedPanelsGadgetInfo){
 
      Themenubar.superClass._addVizSpecificPropsDialog.call(this, oTabbedPanelsGadgetInfo);
      var oGadgetFactory = this.getGadgetFactory();
      var oViewConfig = this.getViewConfig();
     
      var oGeneralPanel = gadgetdialog.forcePanelByID(oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_GENERAL);
      oGeneralPanel.setBodyCSSClass("bi_gadgets_no_cell_separator");
      var nOrder = euidef.GD_FIELD_ORDER_GENERAL_VIZ_SPECIFIC;
    
      var oGadgetValueProperties = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_AREA, oViewConfig.buttonTypeValue);
      var sGadgetId = "menu_JSON";
      nOrder+=1;
      var oGadgetInfo = oGadgetFactory.createGadgetInfo(sGadgetId,  "Menu Configuration String", "Paste supported menu configuration string here.", oGadgetValueProperties, nOrder);
      oGeneralPanel.addChild(oGadgetInfo);
   };
    
   Themenubar.prototype._handlePropChange = function (sGadgetID, oPropChange, oViewSettings, oActionContext) {
      jsx.assertString(sGadgetID, 'sGadgetID');
      jsx.assertObject(oPropChange, 'oPropChange');
      jsx.assertObject(oViewSettings, 'oViewSettings');
      jsx.assertInstanceOf(oActionContext, actioncontext.ActionContext, "oActionContext", "actioncontext.ActionContext");
      
      var bUpdateSettings = Themenubar.superClass._handlePropChange.call(this, sGadgetID, oPropChange, oViewSettings, oActionContext);
      var oConf = oViewSettings.getViewConfigJSON(visualization.SettingsNS.CHART) || {};
       
      switch (sGadgetID)
       {
          case "menu_JSON":
             if(!jsx.isNull(oPropChange.value)) {
                oConf.buttonTypeValue = oPropChange.value;
                bUpdateSettings = true;
             }
             break;
       }
        
       if (bUpdateSettings)
       {
          oViewSettings.setViewConfigJSON(visualization.SettingsNS.CHART, oConf);
          this.render();
       }
       return bUpdateSettings;
   };

   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the visualization
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {string=} sVersion 
    * @returns {module:com-oracle-themenubar/themenubar.Themenubar}
    * @memberof module:com-oracle-themenubar/themenubar
    */
   function createClientComponent(sID, sDisplayName, sOrigin) {
     // Argument validation done by base class
      return new Themenubar(sID, sDisplayName, sOrigin, Themenubar.VERSION);
   };

   return {
      createClientComponent : createClientComponent
   };
});