define({
    "THEMENUBAR_DISPLAY_NAME": "The Menu Bar",
    "THEMENUBAR_SHORT_DISPLAY_NAME": "The Menu Bar",
    "THEMENUBAR_CATEGORY":"The Menu Bar",
    "THEMENUBAR_ROW_LABEL":"The Menu Bar",
    "THEMENUBAR_ITEM_SIZE":"Item Size",
    "MISSING_JSON_MESSAGE": "The menu is not configured. If you can edit the workbook, enter a valid menu configuration string in the visualization properties."
});