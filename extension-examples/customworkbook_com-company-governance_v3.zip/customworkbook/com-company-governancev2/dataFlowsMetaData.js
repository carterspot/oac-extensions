function getSAName_(namestr) {
	var dispname;
	if (namestr.indexOf("'.'") != -1 ) {
		dispname= namestr.slice( namestr.indexOf("'.'")+3, namestr.length-1 );
	} else {
		dispname=namestr;
	}
	return dispname;
}

function storeDataflowData(data, dataflowsMeta,i){
	var obj = {};
	for(var j=0;j<data["dataflows"][i]["definition"]["DSSDependencies"]["inputDatasets"].length;j++){
		//arr.push(getSAName_(data["dataflows"][i]["definition"]["DSSDependencies"]["inputDatasets"][j].datasetId));
		obj["dataflowName"] = data["dataflows"][i]["dataflow-name"];
		obj["owner"] = data["dataflows"][i]["owner"];
		//obj["inputdatasets"] = getSAName_(data["dataflows"][i]["definition"]["DSSDependencies"]["inputDatasets"][j].datasetId);
		obj["inputdatasets"] = data["dataflows"][i]["definition"]["DSSDependencies"]["inputDatasets"][j].datasetId;
		let opdataset = data["dataflows"][i]["definition"]["DSSDependencies"]["outputDatasets"][0];
		//obj["outputdatasets"]= opdataset ? getSAName_(opdataset.datasetId) : 'Missing Information';
		obj["outputdatasets"]= opdataset ? opdataset.datasetId : 'Missing Information';
		obj["last-modified"] = data["dataflows"][i]["last-modified"];
		dataflowsMeta.push(obj);
		obj = {};
	}
}

function iterateDataFlows(data, ownerList, dataflowsMeta){
	if(ownerList === ''){
		for(var i=0;i<data["dataflows"].length;i++){
			storeDataflowData(data, dataflowsMeta,i);
		}
	} else {
		for(var i=0;i<data["dataflows"].length;i++) {
			var ownerID = data["dataflows"][i]["owner"] ? data["dataflows"][i]["owner"] : '';
			ownerList.forEach(function(item, index){
				if(item.toUpperCase().trim() === ownerID.toUpperCase().trim()){
					storeDataflowData(data, dataflowsMeta,i);
				}
			});
		}
	}
}

function invokeDataflowsMetaData(csrftoken,elContainer, dataflowsMeta,ownerList){
	$.ajaxSetup({async:false});
	var theDiv = document.getElementById("statusBox");
	$.get("/ui/dv/ui/api/v1/dataflows/all")
		.done(function(data, status){
			iterateDataFlows(data, ownerList, dataflowsMeta);
			//console.log(dataflowsMeta);
		})
		.fail(function(){
			$.get("/dv/ui/api/v1/dataflows/all", function(data, status){
				iterateDataFlows(data, ownerList, dataflowsMeta);
				//console.log(dataflowsMeta);
			});
		});
}

function getDataflowsMetaData(csrftoken,elContainer, owners){
	var searchByOwner = '';
	var ownerList = (owners && owners.trim().length>0) ? owners.split(",") : owners;
	/*ownerList.forEach(function(item, index){
		if(item && item.trim()!==''){
			//gatherWorkBooksMetaData(self, item);
		}
	});*/
	/*if(owner && owner.trim()!==''){
		searchByOwner = "&search=owner%3a"+encodeURIComponent(owner)+"&limit=2000";
	} else {
		searchByOwner = "&search=owner%3a*&limit=2000";
	}*/
	var dataflowsMeta = [];
	var theDiv = document.getElementById("statusBox");
	appendMessage(theDiv,"Gathering Dataflow details - Started");
	invokeDataflowsMetaData(csrftoken,elContainer, dataflowsMeta,ownerList);

	appendMessage(theDiv,"Gathering Dataflow details - Completed");	
	
	var data_ = [["DataFlowName","Input Datasource ID","Output Datasource ID","Owner","Last Modified"]];
	for(var i=0;i<dataflowsMeta.length;i++){
		//for(var j=0;j<dataflowsMeta[i]["datasets"].length;j++){
		var arr_ = [];
		arr_.push(dataflowsMeta[i]["dataflowName"]);
		arr_.push(dataflowsMeta[i]["inputdatasets"]);
		arr_.push(dataflowsMeta[i]["outputdatasets"]);
		arr_.push(dataflowsMeta[i]["owner"]);

		var last_modified = dataflowsMeta[i]["last-modified"] ? dataflowsMeta[i]["last-modified"] : 'Missing Information';
		if(last_modified.indexOf('+') !== -1){
			last_modified = last_modified.substring(0,last_modified.indexOf('+'));
		}
		arr_.push(last_modified);
		data_.push(arr_);
		//}
	}
	
	var csvContent_ = "";
	//var dataString_;
	data_.forEach(function(infoArray, index){
		//dataString_ = infoArray.join(",");
		/*dataString_ = '"' + infoArray[0] + '"' + "," + '"' + infoArray[1] + '"'+ "," + '"' + infoArray[2] + '"' + '"' + infoArray[3] + '"';
		csvContent_ += index < data_.length ? dataString_+ "\n" : dataString_;*/

		var dataString_ = "";
		for(var k=0;k < infoArray.length; k++){
			dataString_ += '"' + infoArray[k] + '"' + ",";
		}
		dataString_ = dataString_.substring(0, dataString_.length - 1);
		//dataString_ = infoArray.join(",");
		csvContent_ += index < data_.length ? dataString_+ "\n" : dataString_;

	}); 				
	var file_name_ = "SYS_DATAFLOWS";
	var argName_ = file_name_ + ".csv";
	var blob = new Blob([csvContent_],{type: "text/csv;charset=utf-8;"});
	var pom = document.createElement('a');
	document.body.appendChild(pom);
	var url = URL.createObjectURL(blob);
	pom.href = url;
	pom.setAttribute('download', argName_);
	pom.click();
	/*var elem = document.getElementById("loading");
	elem.className="_hidden";*/
	return;
	/*var fileName_ =  new File([csvContent_], argName_, {type:"text/csv"});
	var fdata_ = new FormData();
	fdata_.append("file",fileName_);
	sendUploadFileRequest(fdata_,csrftoken,file_name_,elContainer);*/
}