function getSAName(namestr) {
		var dispname;
		if (namestr.indexOf('XSA(') != -1 ) {
			if((namestr.match(new RegExp('XSA', "g")) || []).length > 1){
				 namestr = namestr.replace(/XSA/g,'');
				 namestr = namestr.replace(/'weblogic'./g,'');
				 namestr = namestr.replace(/"subjectArea":./g,'');
				 namestr = namestr.replace(/[{()}]/g, '');
				 namestr = namestr.replace(/['"]+/g, '');
				 dispname = namestr.substring(1, namestr.length-1);
				 dispname = dispname.replace(/,/g," ");
			}else{
			dispname= namestr.substring( namestr.indexOf("'.'")+3, namestr.indexOf("')") );				
			}
		} else {
			dispname=namestr;
		}
		//dispname = dispname = dispname.replace(/["']/g, "");
		return dispname;
}	
function cleanConnectionName(namestr){
	
	if(namestr.indexOf('\\') != -1){
		var last = namestr.lastIndexOf('\\');
		namestr = namestr.slice(last+1,-1);
	}
	return namestr;
	
}
function getAdditionalDatasetDetails(obj, datasetId){
	var connectionName = [];
	var createdDate = '';
	$.ajaxSetup({async:false});
	$.get("/ui/dv/ui/api/v1/dataset/datasets/generic?ds="+encodeURIComponent(datasetId))
		.done(function(data, status){
			if(data["datasets"] && data["datasets"][0]){
				obj["createdDate"] = data["datasets"] && data["datasets"][0] ? data["datasets"][0].createdDate : 'Missing Information';
				let customAttrs;
				if(data["datasets"][0].customAttrs)
					customAttrs = JSON.parse(data["datasets"][0].customAttrs);
				let enabledFor;

				if(customAttrs && customAttrs["bi-search"]){
					enabledFor = customAttrs["bi-search"]["enabled_for"];
				}
				obj["enabledFor"] = enabledFor ? enabledFor : "Missing Information";
				obj["autoInsights"] = customAttrs ? customAttrs["auto-insights"] : "Missing Information";
				obj["referenceKnowledge"] = customAttrs ? customAttrs["reference-knowledge"] : "Missing Information";
			}
			if(data["datasets"] && data["datasets"][0] && data["datasets"][0]["embeddedDatasets"] && data["datasets"][0]["embeddedDatasets"].length>0){
				if(data["datasets"][0]["embeddedDatasets"][0] && data["datasets"][0]["embeddedDatasets"][0]["connection-name"]){
					connectionName.push(data["datasets"][0]["embeddedDatasets"][0]["connection-name"]);
				}
				/*for(var i=0;i<data["datasets"][0]["embeddedDatasets"].length;i++){
					if(data["datasets"][0]["embeddedDatasets"][i] && data["datasets"][0]["embeddedDatasets"][i]["connection-name"]){
						connectionName.push(data["datasets"][0]["embeddedDatasets"][i]["connection-name"]);
					}
				}*/
			} else {
				if(data["datasets"] && data["datasets"][0] && data["datasets"][0]["connectionName"]){
					connectionName.push(data["datasets"][0]["connectionName"]);
				} else {
					connectionName.push("No Connection");
				}
			}
		})
		.fail(function(){
			$.get("/dv/ui/api/v1/dataset/datasets/generic?ds="+datasetId, function(data, status){
				if(data["datasets"] && data["datasets"][0]){
					obj["createdDate"] = data["datasets"][0].createdDate;
					let customAttrs;
					if(data["datasets"][0].customAttrs)
						customAttrs = JSON.parse(data["datasets"][0].customAttrs);
					let enabledFor;

					if(customAttrs && customAttrs["bi-search"]){
						enabledFor = customAttrs["bi-search"]["enabled_for"];
					}
					obj["enabledFor"] = enabledFor ? enabledFor : "Missing Information";
					obj["autoInsights"] = customAttrs ? customAttrs["auto-insights"] : "Missing Information";
					obj["referenceKnowledge"] = customAttrs ? customAttrs["reference-knowledge"] : "Missing Information";
				}
				if(data["datasets"][0]["embeddedDatasets"] && data["datasets"][0]["embeddedDatasets"].length>0){
					if(data["datasets"][0]["embeddedDatasets"][0]["connection-name"]){
						connectionName.push(data["datasets"][0]["embeddedDatasets"][0]["connection-name"]);
					}
					/*for(var i=0;i<data["datasets"][0]["embeddedDatasets"].length;i++){
						if(data["datasets"][0]["embeddedDatasets"][i]["connection-name"]){
							connectionName.push(data["datasets"][0]["embeddedDatasets"][i]["connection-name"]);
						}
					}*/
				} else {
					if(data["datasets"][0] && data["datasets"][0]["connectionName"]){
						connectionName.push(data["datasets"][0]["connectionName"]);
					} else {
						connectionName.push("No Connection");
					}
				}
			});
		});
	connectionName = connectionName ? connectionName : "No Connection";
	obj["connectionName"] = connectionName;
	//return connectionName;
}
function getDatasetsDetails(csrftoken, elContainer, self, searchCriteria, datasetsMeta){
	$.ajaxSetup({async:false});
	//self.setDatasetName(new Map());
	//$.get("/ui/dv/ui/api/v1/dataset/datasets?metadata=none&includeUncommitted=true")
	$.get("/ui/dv/ui/api/v2/items?type=dataset"+searchCriteria)
		.done(function(data, status){
			for(var i=0;i<data["childItems"].length;i++){
				var obj = {};
				obj["id"] = data["childItems"][i].datasetId;
				obj["description"] = data["childItems"][i].description;
				obj["name"] = data["childItems"][i].displayName;
				obj["owner"] = data["childItems"][i].owner;
				obj["subType"] = data["childItems"][i].subType;
				obj["datamodelProvider"] = data["childItems"][i].datamodelProvider;
				obj["subjectArea"] = "XSA";
				obj["connectionType"] = data["childItems"][i].provider;
				getAdditionalDatasetDetails(obj, data["childItems"][i].datasetId);
				obj["connectionName"] = obj["connectionName"] && obj["connectionName"].length>0 ? obj["connectionName"] : "No Connection";
				obj["lastModifiedTime"] = data["childItems"][i].lastModifiedTime;

				datasetsMeta.push(obj);
				self.getDatasetName().set(obj["id"], obj["name"]);
			}
		})
		.fail(function(){
			//$.get("/dv/ui/api/v1/dataset/datasets?metadata=none&includeUncommitted=true", function(data, status){
			$.get("/dv/ui/api/v2/items?type=dataset"+searchCriteria, function(data, status){
				for(var i=0;i<data["childItems"].length;i++){
					var obj = {};

					obj["id"] = data["childItems"][i].datasetId;
					obj["description"] = data["childItems"][i].description;
					obj["name"] = data["childItems"][i].displayName;
					obj["owner"] = data["childItems"][i].owner;
					obj["subjectArea"] = "XSA";
					obj["subType"] = data["childItems"][i].subType;
					obj["datamodelProvider"] = data["childItems"][i].datamodelProvider;
					obj["connectionType"] = data["childItems"][i].provider;
					obj["lastModifiedTime"] = data["childItems"][i].lastModifiedTime;
					//console.log(obj["lastModifiedTime"]);
					getAdditionalDatasetDetails(obj, data["childItems"][i].datasetId);
					obj["connectionName"] = obj["connectionName"] && obj["connectionName"].length>0 ? obj["connectionName"] : "No Connection";

					datasetsMeta.push(obj);
					self.getDatasetName().set(obj["id"], obj["name"]);
				}
			});
		});
	//appendMessage(theDiv,"Completed scanning for Datasets.");
}
function getSubjectAreaDetails(csrftoken, elContainer, self, search, datasetsMeta){
	$.ajaxSetup({async:false});
	var theDiv = document.getElementById("statusBox");
	//call to collect subjectAreas
	appendMessage(theDiv,"Scanning for SubjectAreas.");
	$.get("/ui/dv/ui/api/v1/modelmetadata/subjectareas?includeChildren=false&depth=0")
		.done(function(data, status){
			//console.log("SubjectAreas success" + data);
			for(var i=0;i<data["subjectAreas"].length;i++){
				var obj = {};
				obj["name"] = data["subjectAreas"][i]["displayName"] ? data["subjectAreas"][i]["displayName"] : data["subjectAreas"][i]["name"];
				obj["id"] = data["subjectAreas"][i]["name"].replaceAll("\"","");
				obj["owner"] = data["subjectAreas"][i]["owner"] ? data["subjectAreas"][i]["owner"] : '';
				obj["subjectArea"] = "RPD";
				obj["connectionType"] = "managed";
				obj["connectionName"] = "No Connection";
				if(search === '*'){
					datasetsMeta.push(obj);
					self.getDatasetName().set(data["subjectAreas"][i]["name"].replace(/['"]+/g, ''), obj["name"]);
				} else {
					var searchList = search.split(",");
					for(var j = 0; j<searchList.length; j++){
						//if(obj["name"] === searchList[j]){
						if (obj["name"].toLowerCase().trim().includes(searchList[j].toLowerCase().trim())) {
							datasetsMeta.push(obj);
							self.getDatasetName().set(data["subjectAreas"][i]["name"].replace(/['"]+/g, ''), obj["name"]);
						}
					}
				}
			}
		})
		.fail(function(){
			$.get("/dv/ui/api/v1/modelmetadata/subjectareas?includeChildren=false&depth=0", function(data, status){
				//console.log("SubjectAreas success" + data);
				for(var i=0;i<data["subjectAreas"].length;i++){
					var obj = {};
					obj["name"] = data["subjectAreas"][i]["displayName"] ? data["subjectAreas"][i]["displayName"] : data["subjectAreas"][i]["name"];
					obj["id"] = data["subjectAreas"][i]["name"].replaceAll("\"","");
					obj["owner"] = data["subjectAreas"][i]["owner"] ? data["subjectAreas"][i]["owner"] : 'Missing Information';
					obj["subjectArea"] = "RPD";
					obj["connectionType"] = "managed";
					obj["connectionName"] = "No Connection";
					if(search === '*'){
						datasetsMeta.push(obj);
						self.getDatasetName().set(data["subjectAreas"][i]["name"].replace(/['"]+/g, ''), obj["name"]);
					} else {
						var searchList = search.split(",");
						for(var j = 0; j<searchList.length; j++) {
							if (obj["name"].toLowerCase().trim().includes(searchList[j].toLowerCase().trim())) {
								datasetsMeta.push(obj);
								self.getDatasetName().set(data["subjectAreas"][i]["name"].replace(/['"]+/g, ''), obj["name"]);
							}
						}
					}
				}
			});
		});
}
function getDatasetsMetaData(csrftoken,elContainer, self, datasets, type){
	var theDiv = document.getElementById("statusBox");
	var datasetsMeta = [];
	var datasetNames = new Map();
	var searchCriteria = '';
		//govDatasetQueryType
	var datasetList = [];
	datasetList = datasets.split(",");
	//console.log(datasetList);
	if(!datasetList || datasetList.length === 0){
		return;
	}
	datasetList.forEach(function(item, index){
		if(item && item.trim()!==''){
			searchCriteria = "&search="+type+"%3a"+encodeURIComponent(item)+"&limit=2000";
			getDatasetsDetails(csrftoken, elContainer, self, searchCriteria, datasetsMeta);
		} /*else {
			searchCriteria = "&search=owner%3a*&limit=2000";
		}*/
	});

	appendMessage(theDiv,"Scanning for SubjectArea details.");

	getSubjectAreaDetails(csrftoken, elContainer, self, datasets, datasetsMeta);
	//appendMessage(theDiv,"Completed scanning for subjectAreas.");
	//var theDiv = document.getElementById("statusBox");
	appendMessage(theDiv,"Gathering Datasets & SubjectArea details - Completed");
	var data_ = [["ID","Datasource","Description","SubjectArea","ConnectionName","ConnectionType","Owner","Created Time","Last Modified","SubType","DataModelProvider","Enabled For","Auto Insights","Knowledge Reference"]];
	for(var i=0;i<datasetsMeta.length;i++){ 
			var arr_ = [];
			var datasetName = datasetsMeta[i]["name"];
			let id = datasetsMeta[i]["id"] ? datasetsMeta[i]["id"] : "Missing Information";
			let description = datasetsMeta[i]["description"] ? datasetsMeta[i]["description"] : "Missing Information";
			datasetName = datasetName.replace(/['"]+/g, '');
			arr_.push(id);
			arr_.push(datasetName);
			arr_.push(description);
			arr_.push(getSAName(datasetsMeta[i]["subjectArea"]));
			arr_.push(cleanConnectionName(datasetsMeta[i]["connectionName"]));
			//arr_.push("Connection Name comes here");
			arr_.push(datasetsMeta[i]["connectionType"]);
			let owner = datasetsMeta[i]["owner"] ? datasetsMeta[i]["owner"] : 'Missing Information';
			arr_.push(owner);

			var created_time = datasetsMeta[i]["createdDate"] ? datasetsMeta[i]["createdDate"] : 'Missing Information';
			if(created_time.indexOf('+') !== -1){
				created_time = created_time.substring(0,created_time.indexOf('+'));
			}
			arr_.push(created_time);

			var last_modified = new Date(datasetsMeta[i]["lastModifiedTime"]);
			if(last_modified == "Invalid Date"){
				//console.log("Invalid Date");
				arr_.push('Missing Information');
				//continue;
			}else{
				var lastmod_dt_formatted = returnDateFormat(last_modified);
				arr_.push(lastmod_dt_formatted);
			}

			let subtype = datasetsMeta[i]["subType"] ? datasetsMeta[i]["subType"] : 'Missing Information';
			arr_.push(subtype);
			let datamodelprovider = datasetsMeta[i]["datamodelProvider"];
			arr_.push(extractProviderType(datamodelprovider));
			let enabledFor = datasetsMeta[i]["enabledFor"] ? datasetsMeta[i]["enabledFor"] : "Missing Information";
			let autoInsights = datasetsMeta[i]["autoInsights"] ? datasetsMeta[i]["autoInsights"] : "Missing Information";
			let referenceKnowledge = datasetsMeta[i]["referenceKnowledge"] ? datasetsMeta[i]["referenceKnowledge"] : "Missing Information";
			arr_.push(enabledFor);
			arr_.push(autoInsights);
			arr_.push(referenceKnowledge);
			data_.push(arr_);
	}
				
	var csvContent_ = "";
	data_.forEach(function(infoArray, index){
		var dataString_ = "";
		for(var k=0;k < infoArray.length; k++){
			dataString_ += '"' + infoArray[k] + '"' + ",";
		}
		dataString_ = dataString_.substring(0, dataString_.length - 1);		
		//dataString_ = infoArray.join(",");
		csvContent_ += index < data_.length ? dataString_+ "\n" : dataString_;
	}); 				
	var file_name_ = "SYS_DATASOURCES";
	var argName_ = file_name_ + ".csv";
	var blob = new Blob([csvContent_],{type: "text/csv;charset=utf-8;"});
	var pom = document.createElement('a');
	document.body.appendChild(pom);
	var url = URL.createObjectURL(blob);
	pom.href = url;
	pom.setAttribute('download', argName_);
	pom.click();
	return;
	/*var fileName_ =  new File([csvContent_], argName_, {type:"text/csv"});
	var fdata_ = new FormData();
	fdata_.append("file",fileName_);
	sendUploadFileRequest(fdata_,csrftoken,file_name_,elContainer)*/;
}

function returnDateFormat(myDate){
	var hours = myDate.getHours();
	var mins = myDate.getMinutes();
	var seconds = myDate.getSeconds();
	var ms = myDate.getMilliseconds();
	var dt = myDate.getDate();
	var mon = myDate.getMonth() < 12 ? myDate.getMonth() + 1 : 1;
	//mon = pad(mon, 4);
	var year = myDate.getFullYear().toString();
	var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	//var dt_str =  pad(dt,2) + "-" + monthNames[mon] + "-" +  year.slice(year.length-2);
	var dt_str1 = year + "-" + pad(mon,2) + "-" + pad(dt,2) + "T" + pad(hours,2) + ":" + pad(mins,2) + ":" + pad(seconds,2) + "." + pad(ms,3);
	return dt_str1;
}

function extractProviderType(jsonStr){
	if(!jsonStr){
		return 'Missing Information';
	}
	let json = JSON.parse(jsonStr);
	let type = json["type"] ? json["type"] : '';
	let providerType = json["provider-type"] ? json["provider-type"] : '';
	let providerName = json["provider-name"] ? json["provider-name"] : '';
	let provider =  providerType + "-" +providerName;
	if(provider !== '-'){
		return provider;
	} else if (type !== ''){
		return type;
	} else {
		return 'Missing Information';
	}

}