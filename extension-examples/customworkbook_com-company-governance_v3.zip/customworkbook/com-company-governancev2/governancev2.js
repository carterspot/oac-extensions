define(['jquery',
       'knockout',
       'ojs/ojcore',
       'obitech-framework/jetfactory2',
        'obitech-framework/browserdom',
        'obitech-framework/jsx',
        "obitech-application/extendable-ui-definitions",
        "obitech-appservices/contextmenumanager",
        'obitech-appservices/logger',
        'obitech-report/reportnode',
        'obitech-appservices/events',
        'ojL10n!com-company-governancev2/nls/messages',
        'obitech-framework/messageformat',
        'skin!css!com-company-governancev2/governancev2styles',
        'com-company-governancev2/workBooksMetaData',
        'com-company-governancev2/dataSetsMetaData',
        'com-company-governancev2/dataFlowsMetaData'],
        function($,
                 ko,
                 oj,
                 jetfactory2,
                 browserdom,
                 jsx,
                 euidef,
                 contextmenu,
                 logger,
                 reportnode,
                 events,
                 messages) {
   "use strict";

   var MODULE_NAME = 'com-company-governancev2/governancev2';

   // Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   //jsx.assertAllNotNullExceptLastN(arguments, "governancev2.js arguments", 2);

   var _logger = new logger.Logger(MODULE_NAME);
   _logger.info("Initializing the custom workbook plugin: governancev2");

   /** 
    * This package provides the implementation for Governancev2 Plugin.
    * @exports com-company-governancev2/governancev2
    */
   var governancev2 = {};

   // The version of this module
   governancev2.VERSION = "1.0.0";

   /**
    * The implementation of the governancev2 plugin.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @param {Object=} oPropertyBag The custom property bag
    * @extends {module:obitech-report/reportnode.ReportNode}
    * @memberof module:com-company-governancev2/governancev2#
    */
   function Governancev2(sID, sDisplayName, sOrigin, sVersion, oPropertyBag) {
      // Argument validation done by base class
      Governancev2.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);

      var _oPropertyBag = oPropertyBag;

      /**
       * Returns the custom property bag
       * 
       * @returns {Object} The custom Properties
       * @private
       * @deprecated
       */     
      this._getCustomPropertyBag = function () {
         return _oPropertyBag;       
      };

      /**
       * Returns the custom properties
       * 
       * @returns {Object} The custom properties
       * @protected
       */
      this.getCustomSettingsBag = function () {
         return _oPropertyBag;
      };

       var result_keys = [];
       var result_values = [];
       var owner = [];
       var id = [];
       var updated_by = [];
       var last_updated = [];
       var paths = [];
       var created_time = [];
       var datasetName = new Map();
       var datasetIdMap = new Map();
       this.getResultKeys = function(){
           return(result_keys);
       };

       this.getResultValues = function (){
           return(result_values);
       };

       this.getUpdatedByValues = function (){
           return(updated_by);
       };

       this.getLastUpdatedValues = function (){
           return(last_updated);
       };

       this.getCreatedTimeValues = function (){
           return(created_time);
       };

       this.getPaths = function (){
           return(paths);
       };

       this.getOwner = function (){
           return(owner);
       };
       this.getId = function (){
           return(id);
       };

       this.getDatasetName = function(){

           if(!this.datasetName){
               this.setDatasetName(new Map())
           }
           return(this.datasetName);
       };

       this.setDatasetName = function (o){
           this.datasetName = o;
       };

       this.getDatasetIdMap = function(){
           if(!this.datasetIdMap){
               this.setDatasetIdMap(new Map())
           }
           return(this.datasetIdMap);
       };

       this.setDatasetIdMap = function (o){
           this.datasetIdMap = o;
       };

       this.setResultKeys = function(o){
           if(o instanceof Array){
               if(o.length == 0){
                   result_keys = [];
               }
           }
           else{
               result_keys.push(o);
           }
       }

       this.setResultValues = function(o){
           if(o instanceof Array){
               if(o.length == 0){
                   result_values = [];
               }
               else{
                   result_values.push(o);
               }
           }

       }

       this.setUpdatedBy = function(o){
           if(o instanceof Array){
               if(o.length == 0){
                   updated_by = [];
               }
           }
           else{
               updated_by.push(o);
           }
       }

       this.setLastUpdated = function(o){
           if(o instanceof Array){
               if(o.length == 0){
                   last_updated = [];
               }
           }
           else{
               last_updated.push(o);
           }
       }

       this.setPaths = function(o){
           if(o instanceof Array){
               if(o.length == 0){
                   paths = [];
               }
           }
           else{
               paths.push(o);
           }
       }

       this.setOwner = function(o){
           if(o instanceof Array){
               if(o.length == 0){
                   owner = [];
               }
           }
           else{
               owner.push(o);
           }
       }

       this.setId = function(o){
           if(o instanceof Array){
               if(o.length == 0){
                   id = [];
               }
           }
           else{
               id.push(o);
           }
       }

       this.setCreatedTime = function(o){
           if(o instanceof Array){
               if(o.length == 0){
                   created_time = [];
               }
           }
           else{
               created_time.push(o);
           }
       }
       this.isLocal = function(){
           if(location.hostname !== 'localhost' || location.hostname !== '127.0.0.1'){
               return true;
           } else {
               return false;
           }
       };
   };
   jsx.extend(Governancev2, reportnode.ReportNode);

   Governancev2.prototype.createCustomPopup = function (iHeight, iWidth, sMode, sId) {
     // var sId = "bitech_customPlugins_wrapper";
     // Remove any existing popup with the same ID
     $("#" + sId).remove();
     var oPosition = {
        "my": {
           "horizontal": 'center',
           "vertical": 'center'
        },
        "at": {
           "vertical": 'center',
           "horizontal": 'center'
        },
        "of": window
     };
     const oPopupOptions = {
        "id": "governancePlugin_popup",
        "modality": sMode,
        "height": iHeight + "px",
        "width": iWidth + "px",
        "position": oPosition,
        "draggable": true,
        "minHeight": "20px",
        "maxHeight": Window.height * .9 + "px",
        "minWidth": "20px",
        "maxWidth": Window.width * .9 + "px",
     };
     var elDialogWrapper = jetfactory2.createDialogOrPopupWrapper(sId);
     const elCustomDialogPopup = jetfactory2.createPopup(oPopupOptions);
     elDialogWrapper.appendChild(elCustomDialogPopup);
     ko.applyBindings({}, elDialogWrapper);
     oj.Context.getContext(elCustomDialogPopup).getBusyContext().whenReady().then(this.createCallback(function() {
        elCustomDialogPopup.open();
     }));

     return elCustomDialogPopup;
   };

   /**
    * Called whenever this plugin is invoked
    */
   Governancev2.prototype.performMainAction = function () {
      // This is the function called when the menu is selected.

      //This id will be used to track the dialog and is required to remove/close it.
      var sId = "inspectID_8675310";
      //Call to create and show the custom dialog.
      var elCustomDialogPopup = this.createCustomPopup(620,600,"modal", sId);

       var csrftoken = this.getSessionInfoService().getCSRFToken();
       var self = this;

      //add the content to the dialog.
      $(elCustomDialogPopup).css("border-radius","5px");
      $(elCustomDialogPopup).css("padding-left","25px");
      $(elCustomDialogPopup).css("padding-right","25px");
      $(elCustomDialogPopup).html(
          "<div class=\"inspect_section_header\">Governance Plugin</div>\n" +
          "<div class='gov2_tabs'>" +
          "  <button class='gov2_tablinks inspect_tabs' id='full_report'>Workbooks and Dataflows</button>\n" +
          "  <button class='gov2_tablinks inspect_tabs' id='lineage'>Datasets</button>" +
          "</div>" +
          "<div id='full_report_div' class='gov2_tabcontent'>" +
          "<div class='inspect_output'>Report Type</div>"+
          "<div class='inspect_output'><input type=\"checkbox\" id=\"workbooks\" name=\"workbooks\" value=\"Workbooks\"><pre> </pre>Workbooks  <pre> </pre><input type=\"checkbox\" id=\"dataflows\" name=\"dataflows\" value=\"Dataflows\"><pre> </pre>Dataflows</div>" +
          "<div class='inspect_output'>Filter by Owner(s)</div>" +
          /*"<div class='inspect_output'>Owner</div>" +*/
          /*"<input id='owner_email' type=\"text\" style=\"border: 1px solid #8a8580;border-radius: 3px;\"><br>" +*/
          "<textarea type='text' id='owner_email' type=\"text\" style=\"resize: none;overflow-y: scroll;border: 1px solid #8a8580;border-radius: 5px;height:70px;width:97%;text-align:left;padding-left:10px;font-size:12px;color:grey;\"placeholder='Enter Owner names separated by comma'></textarea><br>" +
          "<div class='inspect_warning'>Once the process is complete, the output files will automatically download. If the output is large, it may take a few minutes to finish.</div>" +
          "</div>" +
          "<div id='lineage_div' class='gov2_tabcontent'>" +
          "<div class='inspect_output'>Search by<pre> </pre>" +
          "<input type=\"radio\" id=\"datasetName\" name=\"govDatasetQueryType\" value=\"datasetName\">" +
          "<pre> </pre><label for=\"datasetName\">Dataset Name</label>  <pre> </pre>" +
          "<input type=\"radio\" id=\"datasetOwner\" name=\"govDatasetQueryType\" value=\"datasetOwner\">" +
          "<pre> </pre><label for=\"datasetOwner\">Owner</label>" +
          "</div>" +
          "<textarea type='text' id=\"datasets\" style=\"resize: none;overflow-y: scroll;border: 1px solid #8a8580;border-radius: 5px;height:120px;width:97%;text-align:left;padding-left:10px;font-size:12px;color:grey;\"placeholder='Please input the entries separated by comma'></textarea><br>\n" +
          "<div class='inspect_warning'>Once the process is complete, the output files will automatically download. If the output is large, it may take a few minutes to finish.</div>" +
          "</div>" +
          "<div>" +
          "<div class='inspect_output' id=\"status_message\" style=\"width:80%;text-align:left;margin:15;\">Status Messages :</div>"+
          "<div id=\"statusBox\" class=\"govStatusBox\"></div>"+
          "<br>"+
          "</div>" +
          "<div class=\"inspect_footer\"><a href=\"#\" id=\"buttonClose\" class=\"inspect_button_close\">Close</a>" +
          "<a href=\"#\" id=\"buttonSubmit\" class=\"inspect_button_save\">Submit</a>" +
          "</div>"
      );
       //$(elCustomDialogPopup).css("left","200px !important");

       document.getElementById("full_report_div").style.display = "block";
       document.getElementById("full_report").className += " active";

       function init(){
           var e_arr = [];
           self.setResultValues(e_arr);
           self.setResultKeys(e_arr);
           self.setOwner(e_arr);
           self.setUpdatedBy(e_arr);
           self.setLastUpdated(e_arr);
           self.setPaths(e_arr);
           self.setCreatedTime(e_arr);
           self.setId(e_arr);

           var theDiv = document.getElementById("statusBox");
           clearMessages(theDiv);
           appendMessage(theDiv,"Stats gathering - Started");
       }

       function openTab(evt, tabName) {
           // Declare all variables
           var i, tabcontent, tablinks;

           // Get all elements with class="tabcontent" and hide them
           tabcontent = document.getElementsByClassName("gov2_tabcontent");
           for (i = 0; i < tabcontent.length; i++) {
               tabcontent[i].style.display = "none";
           }

           // Get all elements with class="tablinks" and remove the class "active"
           tablinks = document.getElementsByClassName("gov2_tablinks");
           for (i = 0; i < tablinks.length; i++) {
               tablinks[i].className = tablinks[i].className.replace(" active", "");
           }

           // Show the current tab, and add an "active" class to the button that opened the tab
           document.getElementById(tabName).style.display = "block";
           evt.currentTarget.className += " active";
       }

       $('.gov2_tablinks').click(function(e){
           //console.log(e.target.id);
           var tabName = e.target.id+"_div";
           openTab(e,tabName);
           document.getElementById("workbooks").checked = false;
           document.getElementById("dataflows").checked = false;
           document.getElementById("owner_email").value = '';
           document.getElementById("datasets").value = '';
       });
       //event to close the dialog based on ID when close button is clicked.
       $('#buttonSubmit').click(sId, function(e){
           //$("#" + sId).remove();
           console.log("Workbooks: "+document.getElementById("workbooks").checked);
           console.log("Dataflows: "+document.getElementById("dataflows").checked);
           console.log("Email: "+document.getElementById("owner_email").value);
           console.log("Datasets: "+document.getElementById("datasets").value);

           var workbooks = document.getElementById("workbooks").checked;
           var dataflows = document.getElementById("dataflows").checked;
           var ownerID = document.getElementById("owner_email").value;
           var datasets = document.getElementById("datasets").value;
           var dsQueryType = "";
           var theDiv = document.getElementById("statusBox");
           if(document.getElementsByName("govDatasetQueryType")[0].checked === true) {dsQueryType = "name";}
           if(document.getElementsByName("govDatasetQueryType")[1].checked === true) {dsQueryType = "owner";}

           if(workbooks === false && dataflows === false && (dsQueryType === '' || datasets === '')){
               clearMessages(theDiv);
               appendMessage(theDiv,"Select at least one report type to proceed further.");
               return false;
           }

           init();

           if(workbooks === true){
               appendMessage(theDiv,"Gathering Workbook & Workbook Data Sources details - Started");
               appendMessage(theDiv,"Scanning for Workbooks.");
               setTimeout(function() {
                   var owners = ownerID.split(",");
                   owners.forEach(function(item, index){
                           gatherWorkBooksMetaData(self, item);
                   });
               }, 100);
               setTimeout(function() {
                   processWorkBooksMetaData(self);
               }, 400);
               //setTimeout(processWorkBooksMetaData, 400);
           }

           if(dataflows === true){
               setTimeout(function() {
                   getDataflowsMetaData(csrftoken,elCustomDialogPopup,ownerID);
               }, 300);
           }

           if(datasets && datasets.trim()!==''){
               appendMessage(theDiv,"Gathering Datasets & SubjectArea details - Started");
               appendMessage(theDiv,"Scanning for Datasets.");
               setTimeout(function() {
                   getDatasetsMetaData(csrftoken,elCustomDialogPopup,self,datasets,dsQueryType);
               }, 200);
           }

           return false;
       });

      //event to close the dialog based on ID when close button is clicked.
      $('#buttonClose').click(sId, function(e){
         $("#" + sId).remove();
         return false;
      });

      //event to fire when the canvas name is clicked. TODO: Update the dialog with these canvas details.
      var oWorkbook = this;
      $('.buttonCanvas').click(oWorkbook, function(e){
         $('#canvas_details').html(oWorkbook.getCanvasDetailsHTML(e.target.innerText));
         return false;
      });
   };

    function clearMessages(div){
        while(div.firstChild){
            div.removeChild(div.firstChild);
        }
    }

    function appendMessage(div,message){
        var myDiv = document.createElement('div');
        var br = document.createElement("br");
        myDiv.appendChild(br);
        var content = document.createTextNode("-" + message);
        myDiv.appendChild(content);
        div.appendChild(myDiv);
    }

   /**
    * This method returns the description of this plugin
    * @static
    * @returns {string} The description of this plugin
    */
   Governancev2.prototype.getDescription = function () {
      return messages.GOVERNANCEV2_DESCRIPTION;
   };

   /**
    * This method returns the Display Name for this plugin
    * @static
    * @returns {string} The Display Name for this plugin
    */
   Governancev2.prototype.getDisplayName = function () {
      return messages.GOVERNANCEV2_DISPLAY_NAME;
   };

   /**
    * Handles the POPULATE_CONTEXT_MENU event
    */
   Governancev2.prototype._onPopulateContextMenu = function (oClientEvent) {
      var oParams = oClientEvent.getParams();
      var aResults = oParams.results;
      var oContext = oParams.contributionContext;
      var eMenuType = oContext[contextmenu.contrmgr.TYPE];
      if (eMenuType === euidef.CM_TYPE_CUSTOM_WORKBOOK_PLUGINS_MENU_OPTIONS) {
         var oOptionInfo = {
            "name": this.getDisplayName(),
            "description": this.getDescription(),
            "callback": browserdom.createCallback(this, this.performMainAction)
         };
         contextmenu.addOptionToResults(aResults, oOptionInfo, this.getID(), euidef.CM_ID_GROUP_CUSTOM_WORKBOOK_PLUGINS);
      }
   };

   /**
    * This method is used to initialize the component
    */
   Governancev2.prototype._doInitializeComponent = function () {
     Governancev2.superClass._doInitializeComponent.apply(this, arguments);
      // Populate context menu
      this.subscribeToEvent(events.types.POPULATE_CONTEXT_MENU, this._onPopulateContextMenu);
   };

   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the plugin
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {Object=} oPropertyBag The custom property bag
    * @returns {module:com-company-governancev2/governancev2.Governancev2}
    * @memberof module:com-company-governancev2/governancev2
    */
   governancev2.createInstance = function (sID, sDisplayName, sOrigin, oPropertyBag) {
     // Argument validation done by base class
      return new Governancev2(sID, sDisplayName, sOrigin, governancev2.VERSION, oPropertyBag);
   };

   governancev2.Governancev2 = Governancev2;

  return governancev2;
});