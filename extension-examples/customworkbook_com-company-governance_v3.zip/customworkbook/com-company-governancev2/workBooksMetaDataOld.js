function appendMessage(div,message){
    var myDiv = document.createElement('div');
    var br = document.createElement("br");
    myDiv.appendChild(br);
    var content = document.createTextNode("-" + message);
    myDiv.appendChild(content);
    div.appendChild(myDiv);
}
function gatherWorkBooksMetaData(self, ownerID){
    //console.log("Gather Data..")
    $.ajaxSetup({async:false});
    var theDiv = document.getElementById("statusBox");
    appendMessage(theDiv,"Gathering Project & Project Data Sources  details - Started");
    //console.log(theDiv,"Gathering Project & Project Data Sources  details - Started");
    appendMessage(theDiv,"Scanning /Users folder.");
    //console.log(theDiv,"Scanning /Users folder.");
    var userUrl = "/ui/dv/ui/api/v2/items/%40Catalog/users?&type=folder&type=project&sort=LAST_MODIFIED_DESCENDING&full=true&{}";
    var sharedUrl = "/ui/dv/ui/api/v2/items/%40Catalog/shared?&type=folder&type=project&sort=LAST_MODIFIED_DESCENDING&full=true&{}";
    //$.get("api/v1/items/users?full=true&system=true&favorites=true&sort=LAST_MODIFIED_TIME_DESCENDING&{}", function(data, status){
    var req = $.get(userUrl);
    req.done(function(data, status){
        //console.log("Data: " + data + "\nStatus: " + status);
        if(typeof data["childItems"] != "undefined" && status =="success"){
            for(var i=0;i<data["childItems"].length;i++){
                sendIndividualRequest(data["childItems"][i],self,ownerID);
            }
        }
    });
    req.fail(function(textStatus) {
        $.get("/dv/ui/api/v2/items/%40Catalog/users?&type=folder&type=project&sort=LAST_MODIFIED_DESCENDING&full=true&{}", function(data1, status1){
            if(typeof data1["childItems"] != "undefined" && status1 =="success") {
                for (var i = 0; i < data1["childItems"].length; i++) {
                    sendIndividualRequest(data1["childItems"][i], self,ownerID);
                }
            }
        });
    });
    appendMessage(theDiv,"Completed scanning Users folder.");
    //console.log(theDiv,"Completed scanning Users folder.");
    appendMessage(theDiv,"Scanning /Shared folder.");
    //console.log(theDiv,"Scanning /Shared folder.");

    $.ajaxSetup({async:false});
    //$.get("api/v1/items/shared?full=true&system=true&favorites=true&sort=LAST_MODIFIED_TIME_DESCENDING&{}", function(data, status){
    var request = $.get(sharedUrl);
    request.done(function(data, status){
        //console.log("Data: " + data + "\nStatus: " + status);
        if(typeof data["childItems"] != "undefined" && status == "success"){
            for(var i=0;i<data["childItems"].length;i++){
                sendIndividualRequest(data["childItems"][i],self,ownerID);
            }
        }
    });
    request.fail(function(jqXHR, textStatus, errorThrown) {
        $.get("/dv/ui/api/v2/items/%40Catalog/shared?&type=folder&type=project&sort=LAST_MODIFIED_DESCENDING&full=true&{}", function(data1, status1){
            if(typeof data1["childItems"] != "undefined" && status1 == "success"){
                for(var i=0;i<data1["childItems"].length;i++){
                    sendIndividualRequest(data1["childItems"][i],self,ownerID);
                }
            }
        });
    });
    appendMessage(theDiv,"Completed scanning the Shared folder.");
    //console.log(theDiv,"Completed scanning the Shared folder.");
}

function processWorkBooksMetaData(self){
    var fdata = new FormData();
    var data = [["Workbook Name", "Workbook Datasource", "Path","Updated By","Owner","Created Time","Last Modified"]];
    //build the csvdata from the data gathered
    for(var i=0;i<self.getResultKeys().length;i++){
        var arr = [];

        var datasources = self.getResultValues()[i];
        if(datasources && datasources.length >0){
            datasources.forEach(function(item, index){
                arr.push(self.getResultKeys()[i]); //project name
                arr.push(item); //project name
                arr.push(self.getPaths()[i]); //path
                arr.push(self.getUpdatedByValues()[i]);//updatedby
                arr.push(self.getOwner()[i]);//owner
                var created_time = new Date(self.getCreatedTimeValues()[i]);
                if(created_time == "Invalid Date"){
                    //console.log("Invalid Date");
                    arr.push(returnDateFormat(new Date()));
                    //continue;
                }else{
                    var created_dt_formatted = returnDateFormat(created_time);
                    arr.push(created_dt_formatted);
                }
                var myDate = new Date(self.getLastUpdatedValues()[i]);
                if(myDate == "Invalid Date"){
                    //console.log("Invalid Date");
                    arr.push(returnDateFormat(new Date()));
                    data.push(arr);
                }else{
                    var dt_formatted = returnDateFormat(myDate);
                    arr.push(dt_formatted);
                    data.push(arr);
                }
                arr = [];
            });
        }
    }

    var csvContent = "";

    data.forEach(function(infoArray, index){
        //dataString = '"' + infoArray[0] + '"' + "," + '"' + infoArray[1] + '"' ;
        var dataString = "";
        for(var k=0;k < infoArray.length; k++){
            dataString += '"' + infoArray[k] + '"' + ",";
        }
        dataString = dataString.substring(0, dataString.length - 1);
        //dataString = infoArray.join(",");
        csvContent += index < data.length ? dataString+ "\n" : dataString;

    });
    var file_name = "SYS_WORKBOOKS";
    var argName = file_name + ".csv";
    var blob = new Blob([csvContent],{type: "text/csv;charset=utf-8;"});
    var pom = document.createElement('a');
    document.body.appendChild(pom);
    var url = URL.createObjectURL(blob);
    pom.href = url;
    pom.setAttribute('download', argName);
    pom.click();
}

function sendIndividualRequest(data,experimentViz,ownerID){
    //console.log("individual request for: "+data["type"]);
    //console.log("path: "+data["path"]);
    if(data["type"] == "folder" && typeof data["childItems"] == "undefined"){
        var path= data["path"];
        $.ajaxSetup({async:false});
        $.get("/ui/dv/ui/api/v2/items" + path + "?&type=folder&type=project&sort=LAST_MODIFIED_DESCENDING&full=true&{}")
            .done(function(data, status){
                //console.log("Data: " + data + "\nStatus: " + status);
                if(status=="success" && (typeof data["childItems"] != "undefined")){
                    sendIndividualRequest(data,experimentViz,ownerID);
                }
            })
            .fail(function(jqXHR, textStatus, errorThrown) {
                $.get("/dv/ui/api/v2/items" + path + "?&type=folder&type=project&sort=LAST_MODIFIED_DESCENDING&full=true&{}", function(data1, status1){
                    if(status1=="success" && (typeof data1["childItems"] != "undefined")){
                        sendIndividualRequest(data1,experimentViz,ownerID);
                    }
                });
            });
    }else{
        if(data["childItems"] && data["childItems"].length > 0)
            for(var i=0;i<data["childItems"].length;i++){
                var item = data["childItems"][i];
                if(item["type"] == "folder"){
                    var path= (data["path"]);
                    path = path.concat("/" + encodeURIComponent(item["name"]));
                    //path = encodeURIComponent(path);
                    $.ajaxSetup({async:false});
                    $.get("/ui/dv/ui/api/v2/items" + path + "?&type=folder&type=project&sort=LAST_MODIFIED_DESCENDING&full=true&{}")
                        .done(function(data, status){
                            //console.log("Data: " + data + "\nStatus: " + status);
                            if(status=="success"){
                                sendIndividualRequest(data,experimentViz,ownerID);
                            }
                        })
                        .fail(function(jqXHR, textStatus, errorThrown) {
                            $.get("/dv/ui/api/v2/items" + path + "?&type=folder&type=project&sort=LAST_MODIFIED_DESCENDING&full=true&{}", function(data1, status1){
                                if(status1=="success"){
                                    sendIndividualRequest(data1,experimentViz,ownerID);
                                }
                            });
                        });


                }else if(item["type"] == "project"){
                    var name_ = item["name"];
                    var path= data["path"];
                    var createdTime;
                    createdTime = item["createdTime"];
                    path = path.concat("/" + encodeURIComponent(name_));
                    //console.log("project path: "+path);
                    var owner = '';
                    if(data["childItems"]){
                        if(data["childItems"][i].owner){
                            owner = data.childItems[i].owner;
                        }else if(data["childItems"][i].creator){
                            owner = data.childItems[i].creator;
                        }else{
                            owner = '';
                            //owner = data.childItems["0"].lastModifier;
                        }
                    }

                    if(ownerID && ownerID.trim()!==''){
                        if (owner.toUpperCase() !== ownerID.toUpperCase()) {
                            continue;
                        }
                    }

                    var func500 = function() {
                        experimentViz.setResultKeys(name_);
                        var arr = [];arr.push('');
                        experimentViz.setResultValues(arr);
                        experimentViz.setOwner(owner);
                        experimentViz.setUpdatedBy('');
                        experimentViz.setCreatedTime('');
                        experimentViz.setLastUpdated('');
                        experimentViz.setPaths(path);
                    };
                    var func200 = function(_data,status, header){
                        if(_data["representation"]["type"] == "JSON"){
                            if(typeof _data["representation"]["json"] != "undefined" && status=="success"){
                                var _json = JSON.parse(_data["representation"]["json"]);
                                var arr = [];
                                if(_json["datasources"]["children"].length == 0){
                                    arr.push('');
                                }else{
                                    for(var j=0;j<_json["datasources"]["children"].length;j++){
                                        var fullSAName = _json["datasources"]["children"][j]["subjectArea"];
                                        var datasetId = fullSAName ? fullSAName.substring(fullSAName.indexOf("(")+1, fullSAName.lastIndexOf(")")) : '';
                                        var saName = getSAName1(fullSAName);
                                        arr.push(saName);
                                        experimentViz.getDatasetIdMap().set(saName, datasetId);
                                    }
                                }
                                experimentViz.setResultKeys(_data["name"]);
                                experimentViz.setResultValues(arr);
                                experimentViz.setOwner(owner);
                                experimentViz.setUpdatedBy(_data["updatedBy"]);
                                experimentViz.setCreatedTime(createdTime);
                                experimentViz.setLastUpdated(_data["lastUpdatedTime"]);
                                experimentViz.setPaths(_data["id"]);
                            }
                        }else if(_data["representation"]["type"]=="XML"){
                            var result = xmlToJSON.parseString(_data["representation"]["representation"]);
                            var arr = [];
                            for(var j=0;j<result["report"]["0"].datasources.length;j++){
                                var fullSAName = result["report"]["0"].datasources[j].datasource["0"]._attr.subjectArea._value;
                                var datasetId = fullSAName ? fullSAName.substring(fullSAName.indexOf("(")+1, fullSAName.lastIndexOf(")")) : '';
                                var saName = getSAName1(fullSAName);
                                arr.push(saName);
                                experimentViz.getDatasetIdMap().set(saName, datasetId);

                                //arr.push(getSAName1(result["report"]["0"].datasources[j].datasource["0"]._attr.subjectArea._value));
                            }
                            experimentViz.setResultKeys(_data["name"]);
                            experimentViz.setResultValues(arr);
                            experimentViz.setOwner(owner);
                            experimentViz.setCreatedTime(createdTime);
                            experimentViz.setUpdatedBy(_data["updatedBy"]);
                            experimentViz.setLastUpdated(_data["lastUpdatedTime"]);
                            experimentViz.setPaths(_data["id"]);
                        }
                    };
                    $.ajaxSetup({async:false});
                    //$.get("api/v1/projects/detail?path=" + path,
                    $.ajax({
                        url: "/ui/dv/ui/api/v2/items/" + path + "?&projectType=auto&{}",
                        success: function(_data,status, header){
                            //console.log("1.. \n"+_data +"\n"+status+"\n"+header);
                            switch(header.status){
                                case 500:
                                    func500();
                                    break;
                                case 200:
                                    func200(_data,status,header);
                                    break;
                            }
                        },
                        error: function(){
                            //console.log("Error in AJAX");
                            $.ajax({
                                url: "/dv/ui/api/v2/items/" + path + "?&projectType=auto&{}",
                                success: function(_data,status, header){
                                    //console.log("2.. \n"+_data +"\n"+status+"\n"+header);
                                    switch(header.status){
                                        case 500:
                                            func500();
                                            break;
                                        case 200:
                                            func200(_data,status,header);
                                            break;
                                    }
                                }
                            });
                        }
                    });
                }
            }
    }
}


//function to pad number
function pad(n, width, z) {   z = z || '0';   n = n + '';   return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n; }

function returnDateFormat(myDate){
    var hours = myDate.getHours();
    var mins = myDate.getMinutes();
    var seconds = myDate.getSeconds();
    var ms = myDate.getMilliseconds();
    var dt = myDate.getDate();
    var mon = myDate.getMonth() < 12 ? myDate.getMonth() + 1 : 1;
    //mon = pad(mon, 4);
    var year = myDate.getFullYear().toString();
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    //var dt_str =  pad(dt,2) + "-" + monthNames[mon] + "-" +  year.slice(year.length-2);
    var dt_str1 = year + "-" + pad(mon,2) + "-" + pad(dt,2) + "T" + pad(hours,2) + ":" + pad(mins,2) + ":" + pad(seconds,2) + "." + pad(ms,3);
    return dt_str1;
}

function getSAName1(namestr) {
    var dispname;
    //console.log(namestr);

    if (namestr.indexOf('XSA(') != -1 ) {
        if((namestr.match(new RegExp('XSA', "g")) || []).length > 1){
            namestr = namestr.replace(/XSA/g,'');
            namestr = namestr.replace(/'weblogic'./g,'');
            namestr = namestr.replace(/"subjectArea":./g,'');
            namestr = namestr.replace(/[{()}]/g, '');
            namestr = namestr.replace(/['"]+/g, '');
            dispname = namestr.substring(1, namestr.length-1);
            dispname = dispname.replace(/,/g," ");
        }else{
            dispname= namestr.substring( namestr.indexOf("'.'")+3, namestr.indexOf("')") );
        }
    } else {
        dispname=namestr;
        //dispname = dispname.replace(/["']/g, "");
    }
    //dispname = dispname.replace(/"/g,'');
    return dispname;
}

function escapeHTML(str)
{
    var div = document.createElement('div');
    var text = document.createTextNode(str);
    div.appendChild(text);
    return div.innerHTML;
}