define({
   "GOVERNANCEV2_DISPLAY_NAME": "Governance Plugin",
   "GOVERNANCEV2_DESCRIPTION": "Gathers stats on Workbooks, Datasets and Dataflows"
});