function appendMessage(div,message){
    var myDiv = document.createElement('div');
    var br = document.createElement("br");
    myDiv.appendChild(br);
    var content = document.createTextNode("-" + message);
    myDiv.appendChild(content);
    div.appendChild(myDiv);
}

function processWorkBooksMetaData(self){
    var fdata = new FormData();
    var data = [["ID","Workbook Name", "Workbook Datasource ID", "Path","Updated By","Owner","Created Time","Last Modified"]];
    //build the csvdata from the data gathered
    for(var i=0;i<self.getResultKeys().length;i++){
        var arr = [];

        var datasources = self.getResultValues()[i];
        if(datasources && datasources.length >0){
            datasources.forEach(function(item, index){
                arr.push(self.getId()[i]);
                arr.push(self.getResultKeys()[i]); //project name
                arr.push(item); //project name
                arr.push(self.getPaths()[i]); //path
                arr.push(self.getUpdatedByValues()[i]);//updatedby
                arr.push(self.getOwner()[i]);//owner
                var created_time = new Date(self.getCreatedTimeValues()[i]);
                if(created_time == "Invalid Date"){
                    //console.log("Invalid Date");
                    arr.push(returnDateFormat(new Date()));
                    //continue;
                }else{
                    var created_dt_formatted = returnDateFormat(created_time);
                    arr.push(created_dt_formatted);
                }
                var myDate = new Date(self.getLastUpdatedValues()[i]);
                if(myDate == "Invalid Date"){
                    //console.log("Invalid Date");
                    arr.push(returnDateFormat(new Date()));
                    //data.push(arr);
                }else{
                    var dt_formatted = returnDateFormat(myDate);
                    arr.push(dt_formatted);
                    //data.push(arr);
                }
                data.push(arr);
                arr = [];
            });
        }
    }

    var csvContent = "";

    data.forEach(function(infoArray, index){
        //dataString = '"' + infoArray[0] + '"' + "," + '"' + infoArray[1] + '"' ;
        var dataString = "";
        for(var k=0;k < infoArray.length; k++){
            dataString += '"' + infoArray[k] + '"' + ",";
        }
        dataString = dataString.substring(0, dataString.length - 1);
        //dataString = infoArray.join(",");
        csvContent += index < data.length ? dataString+ "\n" : dataString;

    });
    var file_name = "SYS_WORKBOOKS";
    var argName = file_name + ".csv";
    var blob = new Blob([csvContent],{type: "text/csv;charset=utf-8;"});
    var pom = document.createElement('a');
    document.body.appendChild(pom);
    var url = URL.createObjectURL(blob);
    pom.href = url;
    pom.setAttribute('download', argName);
    pom.click();
}

function fetchWorkbookMetadata(self, item){
    var name_ = item["name"];
    var path = item["path"];
    var encodedPath = encodeURI(path);
    var createdTime;
    fetchWorkbookProperties(self, item, encodedPath);
    createdTime = item["createdTime"];
    //path = path.concat("/" + encodeURIComponent(name_));
    //console.log("project path: "+path);
    var owner = item.owner ? item.owner : item.creator;

    var func500 = function() {
        self.setResultKeys(name_);
        var arr = [];arr.push('');
        self.setResultValues(arr);
        self.setOwner(owner);
        self.setUpdatedBy('');
        self.setCreatedTime('');
        self.setLastUpdated('');
        self.setPaths(path);
        self.setId(path);
    };
    var func200 = function(_data,status, header){
        //console.log(_data["name"]+" - "+JSON.stringify(_data));
        if(_data["representation"]["type"] == "JSON"){
            if(typeof _data["representation"]["json"] != "undefined" && status=="success"){
                var _json = JSON.parse(_data["representation"]["json"]);
                var arr = [];
                if(!_json["datasources"] || !_json["datasources"]["children"] || _json["datasources"]["children"].length == 0){
                    arr.push('Missing Information');
                }else{
                    for(var j=0;j<_json["datasources"]["children"].length;j++){
                        var fullSAName = _json["datasources"]["children"][j]["subjectArea"];
                        var datasetId = fullSAName ? fullSAName.substring(fullSAName.indexOf("(")+1, fullSAName.lastIndexOf(")")) : '';
                        var saName = getSAName1(fullSAName);
                        if(datasetId && datasetId !== ''){
                            arr.push(datasetId);
                        } else {
                            arr.push(fullSAName.replaceAll("\"",""));
                        }
                        self.getDatasetIdMap().set(saName, datasetId);
                    }
                }

                self.setResultKeys(_data["name"]);
                self.setResultValues(arr);
                self.setOwner(owner);
                self.setUpdatedBy(_data["updatedBy"]);
                self.setCreatedTime(createdTime);
                self.setLastUpdated(_data["lastUpdatedTime"]);
                self.setPaths(_data["id"]);
                self.setId(path);
            }
        }else if(_data["representation"]["type"]=="XML"){
            var result = xmlToJSON.parseString(_data["representation"]["representation"]);
            var arr = [];
            for(var j=0;j<result["report"]["0"].datasources.length;j++){
                var fullSAName = result["report"]["0"].datasources[j].datasource["0"]._attr.subjectArea._value;
                var datasetId = fullSAName ? fullSAName.substring(fullSAName.indexOf("(")+1, fullSAName.lastIndexOf(")")) : '';
                var saName = getSAName1(fullSAName);
                if(datasetId && datasetId !== ''){
                    arr.push(datasetId);
                } else {
                    arr.push(fullSAName.replaceAll("\"",""));
                }
                self.getDatasetIdMap().set(saName, datasetId);

                //arr.push(getSAName1(result["report"]["0"].datasources[j].datasource["0"]._attr.subjectArea._value));
            }
            self.setResultKeys(_data["name"]);
            self.setResultValues(arr);
            self.setOwner(owner);
            self.setCreatedTime(createdTime);
            self.setUpdatedBy(_data["updatedBy"]);
            self.setLastUpdated(_data["lastUpdatedTime"]);
            self.setPaths(_data["id"]);
            self.setId(path);
        }
    };

    $.ajaxSetup({async:false});
    //$.get("api/v1/projects/detail?path=" + path,
    $.ajax({
        url: "/ui/dv/ui/api/v2/items/" + encodedPath + "?&projectType=auto&{}",
        success: function(_data,status, header){
            //console.log("1.. \n"+_data +"\n"+status+"\n"+header);
            switch(header.status){
                case 500:
                    func500();
                    break;
                case 200:
                    func200(_data,status,header);
                    break;
            }
        },
        error: function(){
            //console.log("Error in AJAX");
            $.ajax({
                url: "/dv/ui/api/v2/items/" + encodedPath + "?&projectType=auto&{}",
                success: function(_data,status, header){
                    //console.log("2.. \n"+_data +"\n"+status+"\n"+header);
                    switch(header.status){
                        case 500:
                            func500();
                            break;
                        case 200:
                            func200(_data,status,header);
                            break;
                    }
                }
            });
        }
    });
}

function fetchWorkbookProperties(self, item, path){
    $.ajaxSetup({async:false});
    $.get("/ui/dv/ui/api/v2/items/"+path+"?properties=all&{}")
        .done(function(data, status) {
            item["createdTime"] = data["createdTime"];
        })
        .fail(function() {
            //$.get("/dv/ui/api/v1/dataset/datasets?metadata=none&includeUncommitted=true", function(data, status){
            $.get("/dv/ui/api/v2/items/"+path+"?properties=all&{}", function (data, status) {
                item["createdTime"] = data["createdTime"];
            });
        });
}

function gatherWorkBooksMetaData(self, ownerID){
    $.ajaxSetup({async:false});
    var theDiv = document.getElementById("statusBox");
    /*appendMessage(theDiv,"Gathering Workbook & Workbook Data Sources details - Started");
    appendMessage(theDiv,"Scanning for Workbooks.");*/
    var searchCriteria;
    ownerID = ownerID.trim();
    if(ownerID && ownerID!=='') {
        searchCriteria = "&search=owner%3a"+encodeURIComponent(ownerID)+"&limit=2000";
    } else {
        searchCriteria = "&search=owner%3a*&limit=2000";
    }
    appendMessage(theDiv,"Scanning for Workbook Data Source.");
    $.get("/ui/dv/ui/api/v2/items?type=project"+searchCriteria)
        .done(function(data, status) {
            for (var i = 0; i < data["childItems"].length; i++) {
                fetchWorkbookMetadata(self, data["childItems"][i]);
            }
        })
        .fail(function() {
            //$.get("/dv/ui/api/v1/dataset/datasets?metadata=none&includeUncommitted=true", function(data, status){
            $.get("/dv/ui/api/v2/items?type=project" + searchCriteria, function (data, status) {
                for (var i = 0; i < data["childItems"].length; i++) {
                    fetchWorkbookMetadata(self, data["childItems"][i]);
                }
            });
        });
    appendMessage(theDiv,"Completed scanning Workbook Data Source.");
    appendMessage(theDiv,"Completed scanning Workbooks.\n");
}


//function to pad number
function pad(n, width, z) {   z = z || '0';   n = n + '';   return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n; }

function returnDateFormat(myDate){
    var hours = myDate.getHours();
    var mins = myDate.getMinutes();
    var seconds = myDate.getSeconds();
    var ms = myDate.getMilliseconds();
    var dt = myDate.getDate();
    var mon = myDate.getMonth() < 12 ? myDate.getMonth() + 1 : 1;
    //mon = pad(mon, 4);
    var year = myDate.getFullYear().toString();
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    //var dt_str =  pad(dt,2) + "-" + monthNames[mon] + "-" +  year.slice(year.length-2);
    var dt_str1 = year + "-" + pad(mon,2) + "-" + pad(dt,2) + "T" + pad(hours,2) + ":" + pad(mins,2) + ":" + pad(seconds,2) + "." + pad(ms,3);
    return dt_str1;
}

function getSAName1(namestr) {
    var dispname;
    //console.log(namestr);

    if (namestr.indexOf('XSA(') != -1 ) {
        if((namestr.match(new RegExp('XSA', "g")) || []).length > 1){
            namestr = namestr.replace(/XSA/g,'');
            namestr = namestr.replace(/'weblogic'./g,'');
            namestr = namestr.replace(/"subjectArea":./g,'');
            namestr = namestr.replace(/[{()}]/g, '');
            namestr = namestr.replace(/['"]+/g, '');
            dispname = namestr.substring(1, namestr.length-1);
            dispname = dispname.replace(/,/g," ");
        }else{
            dispname= namestr.substring( namestr.indexOf("'.'")+3, namestr.indexOf("')") );
        }
    } else {
        dispname=namestr;
        //dispname = dispname.replace(/["']/g, "");
    }
    //dispname = dispname.replace(/"/g,'');
    return dispname;
}

function escapeHTML(str)
{
    var div = document.createElement('div');
    var text = document.createTextNode(str);
    div.appendChild(text);
    return div.innerHTML;
}