define(['jquery',
        'obitech-framework/jsx',
        'obitech-report/datavisualization',
        'obitech-reportservices/datamodelshapes',
        'obitech-reportservices/data',
        'obitech-reportservices/events',
        'obitech-reportservices/interactionservice',
        'obitech-reportservices/markingservice',
        'obitech-application/gadgets',
        'obitech-report/visualization',
        'obitech-report/gadgetdialog',
        'obitech-application/bi-definitions',
        'obitech-application/extendable-ui-definitions',
        'obitech-appservices/logger',
		'obitech-framework/actioncontext',
        'ojL10n!com-company-phoneGridBars/nls/messages',
        'ojs/ojcore', 'knockout', 'jquery', 'ojs/ojknockout', 'ojs/ojbutton', 'ojs/ojchart', 'ojs/ojtoolbar','ojs/ojslider','ojs/ojselectcombobox',
        'obitech-framework/messageformat',
        'skin!css!com-company-phoneGridBars/phoneGridBarsstyles'],
        function($,
                 jsx,
                 dataviz,
                 datamodelshapes,
                 data,
                 events,
                 interactions,
                 marking,
                 gadgets,
                 viz,
                 gadgetdialog,
                 definitions,
                 euidef,
                 logger,
				 actioncontext,
                 messages,
				 oj, ko
				 ) {
   "use strict";

   var MODULE_NAME = 'com-company-phoneGridBars/phoneGridBars';

   //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   //jsx.assertAllNotNullExceptLastN(arguments, "embedBarViz.js arguments", 2);
   jsx.assertNotNull(actioncontext, 'actioncontext');

   var _logger = new logger.Logger(MODULE_NAME);
   var sNameSpace = "phoneGridBars";
   // The version of our Plugin
   PhoneGridBars.VERSION = "1.0.0";

   /**
    * The implementation of the embedBarViz visualization.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @extends {module:obitech-report/visualization.Visualization}
    * @memberof module:com-company-embedBarViz/embedBarViz#
    */
   function PhoneGridBars(sID, sDisplayName, sOrigin, sVersion) {
      // Argument validation done by base class
      PhoneGridBars.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);

	  this.Config ={
	   columns: '1', //'OpenStreetMap', 
	   width:200,
	   height:200,
	   showAxis:'On',
	   ratio:1.5
      };

	  this._saveSettings = function() {
         this.getSettings().setViewConfigJSON(dataviz.SettingsNS.CHART, this.Config);
      };

	  this.loadConfig = function (){
		 var conf = this.getSettings().getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
		 if (conf.columns) this.Config.columns=conf.columns;
		 if (conf.width) this.Config.width=conf.width;
		 if (conf.height) this.Config.height=conf.height;
		 if (conf.showAxis) this.Config.showAxis=conf.showAxis;
		 if (conf.ratio) this.Config.ratio=conf.ratio;		 
         /*mapkey will conatin either the Google key or the mapbox access token   
		 if (conf.mapkey) this.Config.mapkey=conf.mapkey;
		 if (conf.zoomtotheme) this.Config.zoomtotheme=conf.zoomtotheme;
		 if (conf.repeatbackground) this.Config.repeatbackground=conf.repeatbackground;*/
	  }
	  
	  /*var y_axis = '3';
	  var width = 200;
	  var height = 200;
	  var show_axis = "On";
	  */
	  
	  this.getShowAxis = function(){
		return(show_axis);
	  };	  
	  
	  this.setShowAxis = function(o){
		//show_axis = o;
		this.Config.showAxis = o;
		this._saveSettings();				
	  };	  
	  
	  this.getY = function(){
		return(y_axis);
	  };	  

	  this.getWidth = function(){
		return(width);
	  };	 

	  this.getHeight = function(){
		return(height);
	  };	 


	  this.setY = function(o){
		this.Config.columns = o;
		this._saveSettings();		
	  };	
	  
	  this.setWidth = function(o){
		this.Config.width = o;
		this._saveSettings();		
	  };	

	  this.setHeight = function(o){
		this.Config.height = o;
		this._saveSettings();		
	  };

	  this.getRatio = function(){
		return(ratio);
	  };	  
	  
	  this.setRatio = function(o){
		//show_axis = o;
		this.Config.ratio = o;
		this._saveSettings();				
	  };	  
	  
   };
   jsx.extend(PhoneGridBars, dataviz.DataVisualization);
   /**
    * Called whenever new data is ready and this visualization needs to update.
    * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
    */
	
	function buildChart(containerDiv,max,showAxis,w,h){
		h=h-20;
		if(containerDiv.id == "containerDivT"){
				containerDiv.innerHTML =  "<oj-chart id=\"barChart1\" type=\"bar\" series=\"[[barSeriesValue]]\" groups=\"[[barGroupsValue]]\" animation-on-display=\"auto\" animation-on-data-change=\"auto\" legend.position=\"top\" plot-area.rendered=\"off\" x-axis.axis-line.line-width=0 x-axis.max-size=\"0px\" y-axis.rendered=\"off\" hover-behavior=\"dim\" style=\"max-width:100%;width:100%;height:150px;\"></oj-chart>";
		}else{
			if(showAxis == "On"){
				containerDiv.innerHTML =  "<oj-chart id=\"barChart\" type=\"bar\" series=\"[[barSeriesValue]]\" groups=\"[[barGroupsValue]]\" animation-on-display=\"auto\" animation-on-data-change=\"auto\" hover-behavior=\"dim\" legend.rendered=\"off\" y-axis.data-max ="+ max+ " style=\"width:"+100+"%;height:"+h+"px;\"></oj-chart>";
			}else{
				containerDiv.innerHTML =  "<oj-chart id=\"barChart\" type=\"bar\" series=\"[[barSeriesValue]]\" groups=\"[[barGroupsValue]]\" animation-on-display=\"auto\" animation-on-data-change=\"auto\" hover-behavior=\"dim\" legend.rendered=\"off\" legend.max-size=\"0px\" y-axis.size=\"0px\" y-axis.data-max ="+ max+ " style=\"width:"+100+"%;height:"+h+"px;\"></oj-chart>";
			}			
		}
		
		/*containerDiv.innerHTML = "<div id=\"" + id + "\" data-bind=\"ojComponent: {\
				component: 'ojChart', \
				type: 'bar', groups: barGroupsValue, \
				series: barSeriesValue, \
				animationOnDisplay: 'auto',\
				animationOnDataChange: 'auto',\
				hoverBehavior: 'dim',\
				yAxisdataMax: "+ max + "\
			}\"\
			style='width:" + 500 + "px;height:" + 500  + "px;'> \
			";
		*/	
	}

PhoneGridBars.prototype._generateData = function(oDataLayout,maxi){
   
   var oDataModel = this.getRootDataModel();
   if(!oDataModel || !oDataLayout){
      return;
   }
   
   var aAllMeasures = oDataModel.getColumnIDsIn(datamodelshapes.Physical.DATA);
   var nMeasures = aAllMeasures.length;    
   var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
   var nRowLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
   var nCols = oDataLayout.getEdgeExtent(datamodelshapes.Physical.COLUMN);
   var nColLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.COLUMN);
   var rowName = oDataLayout.getLayerMetadata(datamodelshapes.Physical.ROW,0, data.LayerMetadata.LAYER_DISPLAY_NAME);
   //var measureName = oDataLayout.getValue(datamodelshapes.Physical.COLUMN, 0, 0);
   var aOutput = [];
   if(nRows > 0 || nCols > 0){
	  var nRow, nCol;
	  for(nRow=0; nRow < Math.max(nRows, 1); nRow++){
		 var obj={};
		 var repeat_val = oDataLayout.getValue(datamodelshapes.Physical.ROW, 1, nRow, false);
		 var row_attr = oDataLayout.getValue(datamodelshapes.Physical.ROW, 0, nRow, false);
		 var measure_val = oDataLayout.getValue(datamodelshapes.Physical.DATA, nRow, 0, false);
		 if(Number(measure_val) > maxi.value){
			 maxi.value = Number(measure_val);
		 }
		 var arr = [];
		 var obj1 = {}
		 obj1[row_attr] = measure_val;
		 var flag = false;
		 for(var k=0;k<aOutput.length;k++){
			 if(typeof(aOutput[k][repeat_val]) != "undefined"){
					flag = true;
					break;
			 }
		 }
		 if(flag){
			 var temp = aOutput[k][repeat_val];
			 temp.push(obj1);
			 aOutput[k][repeat_val] = temp;
		 }else{
			arr.push(obj1);
			obj[repeat_val] = arr;
			aOutput.push(obj);						
		 }
	  }
	}   	
	
	if (aOutput.length>0)
		return aOutput; 
	else
		return null;
}


	
   PhoneGridBars.prototype.render = function(oTransientRenderingContext) {
      try {
         var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
         var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
         var nRowLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
		 var oDataModel = this.getRootDataModel();
		   if(!oDataModel || !oDataLayout){
			  return;
		   }
         var elContainer = this.getContainerElem();
		 this.loadConfig();
		 var set = new Set();
		 var j=0;
		  for(var nRow = 0; nRow < Math.max(nRows, 1); nRow++) {
			  set.add(oDataLayout.getValue(datamodelshapes.Physical.ROW, 0,nRow,false));
		  }
		 /*while(oDataLayout.getValue(datamodelshapes.Physical.ROW, 0,j,false)){
			 set.add(oDataLayout.getValue(datamodelshapes.Physical.ROW, 0,j,false));
			 j++;
		 }*/
		 var legends = Array.from(set);
		 var max = {value:0};
         var aOutput = this._generateData(oDataLayout,max);
		 var identifier = this.getID();		 
		 $(elContainer).html('');
		 var containerDiv = document.createElement("div");
		 containerDiv.id = 'containerDivT';
		 elContainer.appendChild(containerDiv);
		 $(elContainer).css('overflowY', 'auto');
		 $(elContainer).css('overflowX', 'auto');
		 //code for constructing the tabular format
		 var h = $(elContainer).height();
		 var w = $(elContainer).width();
		 h = Math.round(h);
		 w = Math.round(w);
		 var temp = Math.round(aOutput.length/(Number(this.Config.columns)));
		 var x = aOutput.length/(Number(this.Config.columns));
		 //x = Math.floor(x) + 1;
		 if(temp != x){
			 x = Math.floor(x) + 1;
		 }
		 var y = Number(this.Config.columns);
		 //var y = 1;
		 var row_height = h/x;
		 var row_width = w/y;
		 var larger;
		 var outerDiv = document.createElement('table');
		 outerDiv.id = 'outerDiv' + identifier;
		 outerDiv.style.height = h + "px";
		 outerDiv.style.maxHeight = h + "px";
		 outerDiv.style.width = 100 + "%";
		 outerDiv.style.maxWidth = 100 + "%";
		 outerDiv.className = "outerDiv";
		 if(this.Config.height > (row_height)){
			 larger = this.Config.height;
		 }else{
			 larger = row_height;
		 }
		 //larger = 1.5*(row_width);
		 larger = (this.Config.ratio)*(row_width);
		 var count = 0;
		 while(count < aOutput.length){
			 for(var i=0;(i<x && count < aOutput.length);i++){
				 var rowDiv  = document.createElement('tr');
				 rowDiv.id = 'rowDiv' + identifier;
				 var r_height = larger + (0.15*row_width);
				 rowDiv.style.height = larger + "px";
				 rowDiv.style.width = row_width + "px";			 
				 for(var j=0;(j<y && count < aOutput.length);j++){
					 var tile = document.createElement('td');
					 tile.className = "tile2";
					 tile.style.width  = row_width + "px"; 
					 tile.style.height =  larger + "px";							 
					 tile.style.maxWidth  = row_width + "px"; 
					 tile.style.maxHeight =  larger + "px";
					 tile.align="center";
					 var containerDiv = document.createElement("div");
					 containerDiv.id = 'containerDiv'+count;
					 containerDiv.className = "containers";
					 containerDiv.style.backgroundColor = "white";
					 containerDiv.style.maxWidth = row_width + "px";
					 //containerDiv.style.width = row_width + "px";
					 containerDiv.style.maxHeight = larger + "px";
					 containerDiv.style.height =  larger + "px";
					 containerDiv.style.margin =  7 + "px";
					 tile.appendChild(containerDiv);
					 rowDiv.appendChild(tile);
					 count++;
				 }
				 outerDiv.appendChild(rowDiv);
			}
		 }
		outerDiv.style.height = (larger*x) + "px";
		outerDiv.style.maxHeight = (larger*x) + "px";
		elContainer.appendChild(outerDiv);
		 var keys = [];
		 for(var i=0;i<aOutput.length;i++){
				keys.push(Object.keys(aOutput[i]));
		 }
	 
    function ChartModel(arr,key,index,keys) {
		if(index == -1){
        /* chart data */
			var self=this;
			var barSeries = [];
			for(var i=0;i<keys.length;i++){
				var obj = {};
				var name = keys[i];
				var items = [42,34];
				obj["name"] = name;
				obj["items"]= items;
				barSeries.push(obj);
			}
			var barGroups = ["Group A", "Group B"];
			self.barSeriesValue = ko.observableArray(barSeries);
			self.barGroupsValue = ko.observableArray(barGroups);
		}else{
			var self = this;
			var barSeries = [];
			var key_ = key.slice(0,20);
			var barGroups = [key_];
			for(var i=0;i<arr[key].length;i++){
				var obj={};
				var name = Object.keys(arr[key][i]);
				name = name[0];
				obj["name"]= name;
				obj["items"] = [arr[key][i][name]];
				barSeries.push(obj);
			}
        self.barSeriesValue = ko.observableArray(barSeries);
		self.barGroupsValue = ko.observableArray(barGroups);			
		}
    }
		 var r_width = row_width;

		 for(var i=-1;i<aOutput.length;i++){
				 if(i==-1){
					 var containerDiv = document.getElementById('containerDivT');
					 var chartModel = new ChartModel(aOutput[0],keys[0][0],-1,legends); 
					 buildChart(containerDiv,max.value,this.Config.showAxis,r_width,larger);
					 ko.applyBindings(chartModel, containerDiv);										
				 }else{
					 var id = 'containerDiv' + (i);
					 var containerDiv = document.getElementById(id);
					 var chartModel = new ChartModel(aOutput[i],keys[i][0],i,legends); 
					 buildChart(containerDiv,max.value,this.Config.showAxis,r_width,larger);
					 ko.applyBindings(chartModel, containerDiv);				
				 }
			}
      }
      finally {
         this._setIsRendered(true);
      }
    };

	PhoneGridBars.prototype._addVizSpecificPropsDialog = function(oTabbedPanelsGadgetInfo){
	   this.doAddVizSpecificPropsDialog(this, oTabbedPanelsGadgetInfo);
	   PhoneGridBars.superClass._addVizSpecificPropsDialog.call(this, oTabbedPanelsGadgetInfo);
	};	
	
	
	PhoneGridBars.prototype.doAddVizSpecificPropsDialog = function (oTransientRenderingContext, oTabbedPanelsGadgetInfo) {
		  jsx.assertObject(oTransientRenderingContext, "oTransientRenderingContext");
		  jsx.assertInstanceOf(oTabbedPanelsGadgetInfo, gadgets.TabbedPanelsGadgetInfo, "oTabbedPanelsGadgetInfo", "obitech-application/gadgets.TabbedPanelsGadgetInfo");

		  //var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
		  var oDataModel = this.getRootDataModel();
		   if(!oDataModel){
			  return;
		   }		  
		  
		  var options = this.getViewConfig() || {};
		  //this._fillDefaultOptions(options, oTransientRenderingContext.get(viz.ContextProperty.ACTION_CONTEXT));
		  this._fillDefaultOptions(options, null);

		  var generalPanel = gadgetdialog.forcePanelByID(oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_GENERAL);
		  
		  var oGadgetFactory = this.getGadgetFactory();		  
		  var oY = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.columns);
          var oYInfo = oGadgetFactory.createGadgetInfo("yKeyGadget", 'Columns', 'Columns', oY);
          generalPanel.addChild(oYInfo);		  

		  var oRatio = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.ratio);
          var oRatioInfo = oGadgetFactory.createGadgetInfo("ratioKeyGadget", 'Height/Width Ratio', 'Height/Width Ratio', oRatio);
          generalPanel.addChild(oRatioInfo);	
		  
		  /*var oWidth = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.width);
          var oWidthInfo = oGadgetFactory.createGadgetInfo("widthGadget", 'Width', 'Width', oWidth);
          generalPanel.addChild(oWidthInfo);*/		  

		  /*var oHeight = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.height);
          var oHeightInfo = oGadgetFactory.createGadgetInfo("heightGadget", 'Height', 'Height', oHeight);
          generalPanel.addChild(oHeightInfo);*/		  
		  
		  var options = [];
		  options.push(new gadgets.OptionInfo('On','On'));
		  options.push(new gadgets.OptionInfo('Off','Off'));	

		  var oShowAxis = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.showAxis);
		  var oShowAxisInfo = new gadgets.TextSwitcherGadgetInfo("showAxisGadget", 'Show Axis', 'Show Axis', oShowAxis, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE, false, options);
		  generalPanel.addChild(oShowAxisInfo);
		  
		  if (PhoneGridBars.superClass.doAddVizSpecificPropsDialog)
			PhoneGridBars.superClass.doAddVizSpecificPropsDialog.apply(this, arguments);		  
	};


	PhoneGridBars.prototype._handlePropChange = function (sGadgetID, oPropChange, oViewSettings, oActionContext){
	   var updateSettings = PhoneGridBars.superClass._handlePropChange.call(this, sGadgetID, oPropChange, oViewSettings, oActionContext);      
		  if (updateSettings) {
			 return updateSettings; // super handled it
		  }

	   // Allow the super class an attempt to handle the changes
	   var conf = oViewSettings.getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
		if (sGadgetID === "yKeyGadget")
		  {
			 if (jsx.isNull(conf.styleDefaults))
			 {
				conf.styleDefaults = {};
			 }

			 this.setY(oPropChange.value);
			// this.setActiveVar(oPropChange.value);
			 updateSettings = true;
		  }	
		if (sGadgetID === "ratioKeyGadget")
		  {
			 if (jsx.isNull(conf.styleDefaults))
			 {
				conf.styleDefaults = {};
			 }

			 this.setRatio(oPropChange.value);
			 updateSettings = true;
		  }			  
		/*if (sGadgetID === "widthGadget")
		  {
			 if (jsx.isNull(conf.styleDefaults))
			 {
				conf.styleDefaults = {};
			 }

			 this.setWidth(oPropChange.value);
			 updateSettings = true;
		  }		  
		if (sGadgetID === "heightGadget")
		  {
			 if (jsx.isNull(conf.styleDefaults))
			 {
				conf.styleDefaults = {};
			 }

			 this.setHeight(oPropChange.value);
			 updateSettings = true;
		  }
		  */
		if (sGadgetID === "showAxisGadget")
		  {
			 if (jsx.isNull(conf.styleDefaults))
			 {
				conf.styleDefaults = {};
			 }

			 this.setShowAxis(oPropChange.value);
			 updateSettings = true;
		  }			  		  
	   return updateSettings;
	};	
	
   	PhoneGridBars.prototype.resizeVisualization = function(oVizDimensions, oTransientVizContext){
		var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
		this.render(oTransientRenderingContext);
	};	
   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the visualization
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {string=} sVersion 
    * @returns {module:com-company-embedBarViz/embedBarViz.EmbedBarViz}
    * @memberof module:com-company-embedBarViz/embedBarViz
    */
   function createClientComponent(sID, sDisplayName, sOrigin) {
     // Argument validation done by base class
      return new PhoneGridBars(sID, sDisplayName, sOrigin, PhoneGridBars.VERSION);
   };

   return {
      createClientComponent : createClientComponent
   };
});