define({
    "PHONEGRIDBARS_DISPLAY_NAME": "PhoneGridBars Plugin",
    "PHONEGRIDBARS_SHORT_DISPLAY_NAME": "PhoneGridBars Plugin",
    "PHONEGRIDBARS_CATEGORY":"PhoneGridBars Plugin",
    "PHONEGRIDBARS_ROW_LABEL":"Rows",
    "PHONEGRIDBARS_ITEM_SIZE":"Values",
	"PHONEGRIDBARS_COLOR_LABEL":"Repeat On",
    "TEXT_MESSAGE": "Hello!  This is the {0} visualization and I have {1} rows of data."

});