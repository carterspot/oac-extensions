define(['obitech-framework/jsx',
       'obitech-reportservices/datamodelshapes',
       'obitech-viz/genericDataModelHandler',
       'obitech-report/vizdatamodelsmanager'],
    function(jsx,
             datamodelshapes,
             genericDataModelHandler,
             vdm) {
       "use strict";
       var network2VizDataModelHandler = {};

       /**
        * @class The data model handler.
        * @constructor
        * @param {object=} oConfig
        * @param {string=} sId
        * @param {string=} sDisplayName
        * @param {string=} sOrigin
        * @param {string=} sVersion
        * @memberof module:com-company-network2Viz/Network2VizDataModelHandler#
        * @extends module:obitech-viz/vizDataModelHandlerBase#VisualizationHandlerBase
        */
       function Network2VizDataModelHandler(oConfig, sId, sDisplayName, sOrigin, sVersion)
       {
          Network2VizDataModelHandler.baseConstructor.call(this, oConfig, sId, sDisplayName, sOrigin, sVersion);
       }
       jsx.extend(Network2VizDataModelHandler, genericDataModelHandler.GenericDataModelHandler);
       network2VizDataModelHandler.Network2VizDataModelHandler = Network2VizDataModelHandler;

       /**
        * @returns module:obitech-report/vizdatamodelsmanager#Mapper
        */
       Network2VizDataModelHandler.prototype.getLogicalMapper = function () {
          var oData = new datamodelshapes.PhysicalPlacement(datamodelshapes.Physical.DATA);
          var oRow = new datamodelshapes.PhysicalPlacement(datamodelshapes.Physical.ROW);
          var oCol = new datamodelshapes.PhysicalPlacement(datamodelshapes.Physical.COLUMN);

          var oMapper = new vdm.Mapper();

          oMapper.addCategoricalMapping(datamodelshapes.Logical.SIZE,   null); // don't place
          oMapper.addCategoricalMapping(datamodelshapes.Logical.COLOR,  oRow); // color -> row
          oMapper.addCategoricalMapping(datamodelshapes.Logical.ROW, oRow); // row -> row
          oMapper.addCategoricalMapping(datamodelshapes.Logical.CATEGORY, oRow); // det -> row
          oMapper.addCategoricalMapping(datamodelshapes.Logical.GLYPH, null);
          oMapper.addCategoricalMapping(datamodelshapes.Logical.ITEM, oRow); // det -> row

          oMapper.addMeasureMapping(datamodelshapes.Logical.SIZE,   oRow); // Don't place
          oMapper.addMeasureMapping(datamodelshapes.Logical.COLOR,  oRow); // Don't place
           oMapper.addMeasureMapping(datamodelshapes.Logical.MEASURES, oData);
          oMapper.addMeasureMapping(datamodelshapes.Logical.CATEGORY, oRow); // ''
          oMapper.addMeasureMapping(datamodelshapes.Logical.GLYPH,  oRow); // Don't place
          oMapper.addMeasureMapping(datamodelshapes.Logical.ITEM, oRow); // ''

          // where to place physical measure label in case no measure layer is present in logical
          oMapper.setDefaultPhysicalMeasureLabel(datamodelshapes.Physical.COLUMN, this.getMeasureLabelConfig().visibility);
          return oMapper;
       };

       /**
        * Returns the handler
        *@param {String} extensionPointName
        *@param {Object} config
        */
       network2VizDataModelHandler.getHandler = function(extensionPointName, config) {
          return new Network2VizDataModelHandler(config, extensionPointName);
       };

       return network2VizDataModelHandler;
    });
