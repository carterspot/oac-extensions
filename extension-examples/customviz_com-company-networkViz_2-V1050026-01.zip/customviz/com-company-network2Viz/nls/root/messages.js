define({
    "NETWORK2VIZ_DISPLAY_NAME" : "Network 10K Plugin",
    "NETWORK2VIZ_SHORT_DISPLAY_NAME" : "Network 10K Plugin",
    "NETWORK2VIZ_CATEGORY" : "Network 10K Plugin",
    "NETWORK2VIZ_ROW_LABEL" : "SOURCE, DESTINATION",
    "NETWORK2VIZ_NODE_DISTANCE" : "Link Length",
    "NETWORK2VIZ_NODE_COLOR" : "Node Color - Source",
    "NETWORK2VIZ_NODE_SIZE" : "Node Size - Source",
    "NETWORK2VIZ_LINK_COLOR" : "Link Color",
    "NETWORK2VIZ_LINK_SIZE" : "Link Size",
    "NETWORK2VIZ_ITEM_LABEL" : "Link Label",
    "TEXT_MESSAGE": "Hello!  This is the {0} visualization and I have {1} rows of data."
});