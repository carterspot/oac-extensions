﻿define(['jquery',
        'obitech-framework/jsx',
        'obitech-report/datavisualization',
        'obitech-legend/legendandvizcontainer',
        'obitech-reportservices/datamodelshapes',
        'obitech-reportservices/events',
        'obitech-reportservices/interactionservice',
        'obitech-reportservices/markingservice',
        'obitech-application/gadgets',
        'obitech-report/visualization',
        'obitech-report/gadgetdialog',
        'obitech-application/bi-definitions',
        'obitech-appservices/logger',
        'ojL10n!com-company-network2Viz/nls/messages',
        'obitech-application/extendable-ui-definitions',
        'obitech-reportservices/data',
        'd3v6js',
        'knockout',
        'obitech-framework/actioncontext',
        "ojs/ojarraydataprovider", "ojs/ojattributegrouphandler",
        'obitech-framework/messageformat',
        'skin!css!com-company-network2Viz/network2Vizstyles'],
    function ($,
              jsx,
              dataviz,
              legendandvizcontainer,
              datamodelshapes,
              events,
              interactions,
              marking,
              gadgets,
              viz,
              gadgetdialog,
              definitions,
              logger,
              messages,
              euidef,
              data,
              d3,
              ko,
              actioncontext,
              ojdataprovider, ojgrouphandler) {
        "use strict";

        var MODULE_NAME = 'com-company-network2Viz/network2Viz';

        //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
        jsx.assertAllNotNullExceptLastN(arguments, "network2Viz.js arguments", 2);

        var network2 = {};

        var _logger = new logger.Logger(MODULE_NAME);

        // The version of our Plugin
        Network2Viz.VERSION = "1.0.0";

        var sNameSpace = "network2Viz";

        /**
         * The implementation of the network2Viz visualization.
         *
         * @constructor
         * @param {string} sID
         * @param {string} sDisplayName
         * @param {string} sOrigin
         * @param {string} sVersion
         * @extends {module:obitech-report/visualization.Visualization}
         * @memberof module:com-company-network2Viz/network2Viz#
         */

        function Network2Viz(sID, sDisplayName, sOrigin, sVersion) {
            // Argument validation done by base class
            Network2Viz.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);

            var tabInfo = '';

            this.colorHandler = new ojgrouphandler.ColorAttributeGroupHandler();

            this.Config = {
                rowDisplayNames: [],
                legendItems: new Map(),
                cID: '',
                turnDesc : 'Off',
                nodeSizeMag: 10,
                lineSizeMag: 5,
                lineLengthMag: 2,
                clusterSpacingFactor: 30,
                curvedLine: 'Off',
                rowMap: new Map(),
                legendOption : 'Off',
                arrows: 'On',
              //  labels: 'On',
                firstNodeColor : '',
                firstLinkColor : '',
                destOnlyColor : ''
            }

            this.loadConfig = function () {
                var conf = this.getSettings().getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
                if (conf.rowDisplayNames) this.Config.rowDisplayNames = conf.rowDisplayNames;
                if (conf.legendItems) this.Config.legendItems = conf.legendItems;
                if (conf.cID) this.Config.cID = conf.cID;
                if (conf.turnDesc) this.Config.turnDesc=conf.turnDesc;
                if (conf.nodeSizeMag) this.Config.nodeSizeMag=conf.nodeSizeMag;
                if (conf.lineSizeMag) this.Config.lineSizeMag=conf.lineSizeMag;
                if (conf.lineLengthMag) this.Config.lineLengthMag=conf.lineLengthMag;
                if (conf.clusterSpacingFactor) this.Config.clusterSpacingFactor=conf.clusterSpacingFactor;
                if (conf.curvedLine) this.Config.curvedLine=conf.curvedLine;
                if (conf.rowMap) this.Config.rowMap=conf.rowMap;
                if (conf.legendOption) this.Config.legendOption=conf.legendOption;
                if (conf.arrows) this.Config.arrows = conf.arrows;
              //  if (conf.labels) this.Config.labels = conf.labels;
                if (conf.firstNodeColor) this.Config.firstNodeColor=conf.firstNodeColor;
                if (conf.firstLinkColor) this.Config.firstLinkColor=conf.firstLinkColor;
                if (conf.destOnlyColor) this.Config.destOnlyColor=conf.destOnlyColor;
            }

            this._saveSettings = function () {
                this.getSettings().setViewConfigJSON(dataviz.SettingsNS.CHART, this.Config);
            };

            this.getRowDisplayNames = function () {
                return (this.Config.rowDisplayNames);
            };

            this.setRowDisplayNames = function (o) {
                this.Config.rowDisplayNames = o;
            };

            this.getLegendItems = function () {
                return (this.Config.legendItems);
            };

            this.setLegendItems = function (o) {
                this.Config.legendItems = o;
            };

            this.getCID = function () {
                return (this.Config.cID);
            };

            this.setCID = function (o) {
                this.Config.cID = o;
            };
            this.getTurnDesc = function(){
                return(this.Config.turnDesc);
            };

            this.setTurnDesc = function (o){
                this.Config.turnDesc = o;
                this._saveSettings();
            };

            this.getNodeSizeMag = function(){
                return(this.Config.nodeSizeMag);
            };

            this.setNodeSizeMag = function (o){
                this.Config.nodeSizeMag = o;
                this._saveSettings();
            };

            this.getLineSizeMag = function(){
                return(this.Config.lineSizeMag);
            };

            this.setLineSizeMag = function (o){
                this.Config.lineSizeMag = o;
                this._saveSettings();
            };

            this.getLineLengthMag = function(){
                return(this.Config.lineLengthMag);
            };

            this.setLineLengthMag = function (o){
                this.Config.lineLengthMag = o;
                this._saveSettings();
            };
            this.getClusterSpacingFactor = function(){
                return(this.Config.clusterSpacingFactor);
            };

            this.setClusterSpacingFactor = function (o){
                this.Config.clusterSpacingFactor = o;
                this._saveSettings();
            };
            this.getCurvedLine = function(){
                return(this.Config.curvedLine);
            };

            this.setCurvedLine = function (o){
                this.Config.curvedLine = o;
                this._saveSettings();
            };
            this.getLegendOption = function(){
                return(this.Config.legendOption);
            };

            this.setLegendOption = function (o){
                this.Config.legendOption = o;
                this._saveSettings();
            };
            this.getArrows = function(){
                return(this.Config.arrows);
            };

            this.setArrows = function (o){
                this.Config.arrows = o;
                this._saveSettings();
            };

            //this.getLabels = function () {
            //    return (this.Config.labels);
            //};

            //this.setLabels = function (o) {
            //    this.Config.labels = o;
            //    this._saveSettings();
            //};

            this.getFirstNodeColor = function(){
                return(this.Config.firstNodeColor);
            };

            this.setFirstNodeColor = function (o){
                this.Config.firstNodeColor = o;
                this._saveSettings();
            };
            this.getFirstLinkColor = function(){
                return(this.Config.firstLinkColor);
            };

            this.setFirstLinkColor = function (o){
                this.Config.firstLinkColor = o;
                this._saveSettings();
            };
            this.getDestOnlyColor = function(){
                return(this.Config.destOnlyColor);
            };

            this.setDestOnlyColor = function (o){
                this.Config.destOnlyColor = o;
                this._saveSettings();
            };
            this.getRowMap = function(){
                return(this.Config.rowMap);
            };

            this.setRowMap = function (o){
                this.Config.rowMap = o;
            };

            this.getTabInfo = function () {
                return (tabInfo);
            };

            this.setTabInfo = function (o) {
                tabInfo = o;
            };


            /**
             * @type {Array.<String>} - The array of selected items
             */
            var aSelectedItems = new Map();

            /**
             * @return  {Array.<String>} - The array of selected items
             */
            this.getSelectedItems = function () {
                return aSelectedItems;
            };

            /**
             * Clears the current list of selected items
             */
            this.clearSelectedItems = function () {
                aSelectedItems = new Map();
            };
        };


        jsx.extend(Network2Viz, dataviz.DataVisualization);

        Network2Viz.prototype._generateData = function (oDataLayout, oTransientRenderingContext) {

            var oDataModel = this.getRootDataModel();
            if (!oDataModel || !oDataLayout) {
                return;
            }
            this.setRowDisplayNames([]);
            var aAllMeasures = oDataModel.getColumnIDsIn(datamodelshapes.Physical.DATA);
            var nMeasures = aAllMeasures.length;
            var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
            var nRowLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
            var oDataLayoutHelper = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT_HELPER);

            var oColorContext = this.getColorContext(oTransientRenderingContext);
            var oColorInterpolator = this.getCachedColorInterpolator(oTransientRenderingContext, datamodelshapes.Logical.COLOR);

            //Get the display names of the rows
            var rowLabels = [];
            for(var nRow = 0; nRow < nRowLayerCount; nRow++){
                var rowKey = oDataLayoutHelper.getLogicalEdgeName(datamodelshapes.Physical.ROW, nRow);
                var displayName = oDataLayout.getLayerMetadata(datamodelshapes.Physical.ROW, nRow, data.LayerMetadata.LAYER_DISPLAY_NAME);
                rowLabels.push(displayName);
            }
            rowLabels.push("");

            //--------------------------------------------------------
            var nodeLinksMap = new Map();
            function addLinksToNode(node, row){
                if(!nodeLinksMap.get(node)){
                    nodeLinksMap.set(node, [row]);
                } else {
                    nodeLinksMap.get(node).push(row);
                }
            }

            //console.log("network2 rows : "+nRows);
            var links = [], nodeMap = new Map();
            var nodeSizeList = [];
            var nodeColorList = [];
            var linkColorList = [];

            var sColor = true, sSize = true;
            var linkDistanceLabel = oDataLayout.getValue(datamodelshapes.Physical.COLUMN, 0, 0, false);
            for (var nRow = 0; nRow < Math.max(nRows, 1); nRow++) {
                var source = oDataLayout.getValue(datamodelshapes.Physical.ROW, 0, nRow, false);
                var dest = oDataLayout.getValue(datamodelshapes.Physical.ROW, 1, nRow, false);
                var distance = parseFloat(oDataLayout.getValue(datamodelshapes.Physical.DATA, nRow, 0));
                distance = distance && !isNaN(distance) ? distance : 0;
                var linkColor, linkColorName, linkSize, sColorLabel, dColorLabel, sSizeLabel, dSizeLabel, linkColorLabel, linkSizeLabel, item, itemLabel;
                var colorObj, sourceColor, destColor, sourceSize, destSize, sourceColorVal;
                if (nRowLayerCount > 2) {
                    for (var nRowLayer = 2; nRowLayer < Math.max(nRowLayerCount, 1); nRowLayer++) {
                        var row = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                        var rowType = oDataLayoutHelper.getLogicalEdgeName(datamodelshapes.Physical.ROW, nRowLayer);
                        switch (rowType) {
                            case "item":
                                item = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                                itemLabel = rowLabels[nRowLayer];
                                break;
                            case "color":
                                colorObj = this.getDataItemColorInfo(oDataLayoutHelper, oColorContext, oColorInterpolator, nRow, 0);
                                sourceColor = colorObj.sSeriesColorLabel ? colorObj.sSeriesColorLabel : row;
                                sourceColorVal = colorObj.sColor ? colorObj.sColor : colorObj.sSeriesColor;
                                sColorLabel = rowLabels[nRowLayer];
                                /*
                                if (sColor) {
                                    colorObj = this.getDataItemColorInfo(oDataLayoutHelper, oColorContext, oColorInterpolator, nRow, 0);
                                    if(colorObj.sSeriesColorLabel && colorObj.sSeriesColorLabel.indexOf(',') !== -1)
                                        sourceColor = colorObj.sSeriesColorLabel.substring(0, colorObj.sSeriesColorLabel.indexOf(','));
                                    else
                                        sourceColor = colorObj.sSeriesColorLabel ? colorObj.sSeriesColorLabel : row;
                                    sColorLabel = rowLabels[nRowLayer];
                                    sColor = false;
                                } else {
                                    colorObj = this.getDataItemColorInfo(oDataLayoutHelper, oColorContext, oColorInterpolator, nRow, 0);
                                    destColor = colorObj.sSeriesColorLabel ? colorObj.sSeriesColorLabel.substring(colorObj.sSeriesColorLabel.indexOf(',') + 2) :
                                        row;
                                    dColorLabel = rowLabels[nRowLayer];
                                    sColor = true;
                                }*/
                                break;
                            case "size":
                                sourceSize = parseFloat(oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false));
                                sourceSize = sourceSize && !isNaN(sourceSize) ? sourceSize : 0;
                                sSizeLabel = rowLabels[nRowLayer];
                                /*if (sSize) {
                                    sourceSize = parseFloat(oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false));
                                    sSizeLabel = rowLabels[nRowLayer];
                                    sSize = false;
                                } else {
                                    destSize = parseFloat(oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false));
                                    dSizeLabel = rowLabels[nRowLayer];
                                    sSize = true;
                                }*/
                                break;
                            case "detail":
                                linkColor = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                                linkColorLabel = rowLabels[nRowLayer];
                                break;
                            case "glyph":
                                linkSize = parseFloat(oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false));
                                linkSize = linkSize && !isNaN(linkSize) ? linkSize : 0;
                                linkSizeLabel = rowLabels[nRowLayer];
                                break;
                        }
                    }
                }
                /*if(nodeSizeMap.get(source)){
                    var totSize = nodeSizeMap.get(source);
                    nodeSizeMap.set(source, totSize + sourceSize);
                } else {
                    nodeSizeMap.set(source, sourceSize);
                }

                if(sourceColor){
                    if(nodeColorMap.get(source)){
                        nodeColorMap.set(source, nodeColorMap.get(source).push(sourceColor));
                    } else {
                        nodeColorMap.set(source, [sourceColor]);
                    }
                }*/

                nodeSizeList.push({name: source, size: sourceSize, count: 1});
                nodeColorList.push({name: source, color: sourceColor, colorVal: sourceColorVal});
                linkColorList.push({name: source+'-'+dest, color: linkColor});

                nodeMap.set(source, {isSource: true, nodeColor: sourceColor, nodeSize: sourceSize, cLabel: sColorLabel, sLabel: sSizeLabel, nodeColorVal: sourceColorVal});
                if(!nodeMap.get(dest)){
                    nodeMap.set(dest, {isSource: false, nodeColor: '', nodeSize: 0, cLabel: '', sLabel: ''});
                }
                addLinksToNode(source, nRow);
                addLinksToNode(dest, nRow);
                var linksObj = {source: source, target: dest, distance: distance, color: linkColor, weight: linkSize ? linkSize : 0,
                    dLabel: linkDistanceLabel, cLabel: linkColorLabel, sLabel: linkSizeLabel, row: nRow, item: item};
                links.push(linksObj);
                sColor = true;
                sSize = true;
            }
            var nodes = [];
            var i = 0;
            nodeMap.forEach((value, key) => {
                var tempNode = {id: i, name: key, color: value.nodeColor, size: value.nodeSize, cLabel: value.cLabel,
                                sLabel: value.sLabel, row: i, isSource: value.isSource, colorVal: value.nodeColorVal};
                nodes.push(tempNode);
                i++;
            });
            let nodeSizeMap = nodeSizeList.reduce(function (r, a) {
                if(!r[a.name]){
                    //r[a.name] = {...a};
                    r[a.name] = a;
                    return r;
                }
                r[a.name].size += a.size;
                r[a.name].count += a.count;
                return r;
            }, {});

            let nodeColorMap = nodeColorList.reduce(function (r, a) {
                if(!r[a.name]){
                    //r[a.name] = {...a};
                    r[a.name] = a;
                    return r;
                }
                if(a.color){
                    r[a.name].color = a.color;
                }
                return r;
            }, {});
            let linkColorMap = linkColorList.reduce(function (r, a) {
                if(!r[a.name]){
                    //r[a.name] = {...a};
                    r[a.name] = a;
                    return r;
                }
                if(a.color){
                    r[a.name].color = a.color;
                }
                return r;
            }, {});
            var outputMap = {nodes: nodes, links: links, nodeMap: nodeLinksMap, nodeSizeMap: nodeSizeMap, nodeColorMap: nodeColorMap, linkColorMap: linkColorMap};
            if (outputMap)
                return outputMap;
            else
                return null;
        }


        Network2Viz.prototype._render = function (oTransientRenderingContext) {
            // Note: all events will be received after initialize and start complete.  We may get other events
            // such as 'resize' before the render, i.e. this might not be the first event.
            console.log("Network Viz with D3 version 6");
            try {
                this.loadConfig();
                // Retrieve the data object for this visualization
                var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);

                if (!oDataLayout)
                    return;

                var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
                var dataObj = this._generateData(oDataLayout, oTransientRenderingContext);
                var oViz = this;
                var tooltip = d3.select("body")
                    .append("div")
                    .attr('class', 'tooltip')
                    .style('display', 'none')
                    /*.style("visibility", "hidden")*/;

                var elContainer = this.getContainerElem();

                var sVizContainerId = this.getSubElementIdFromParent(this.getContainerElem(), "hvc");
                var pane = sVizContainerId.substring(sVizContainerId.indexOf("view") + 5, sVizContainerId.indexOf("pane"));
                var conetentPane = sVizContainerId.substring(sVizContainerId.indexOf("contentpane_") + 12, sVizContainerId.indexOf("vizCont") - 1);
                var cId = pane + "_" + conetentPane;
                oViz.setCID(cId);

                var nodeList = [];
                var rowMap = new Map();
                var maxNodeSize = 0, maxLinkSize = 0, maxDistance = 0;
                var nodeLegends = new Map(), linkLegends = new Map();

                for (var i in dataObj.nodes) {
                    nodeList.push(dataObj.nodes[i].name);
                    if(dataObj.nodes[i].isSource){
                        if(dataObj.nodeSizeMap[dataObj.nodes[i].name].size && dataObj.nodeSizeMap[dataObj.nodes[i].name].count){
                            dataObj.nodes[i].size = dataObj.nodeSizeMap[dataObj.nodes[i].name].size / dataObj.nodeSizeMap[dataObj.nodes[i].name].count;
                        } else {
                            dataObj.nodes[i].size = 0;
                        }
                        dataObj.nodes[i].color = (dataObj.nodes[i].color && dataObj.nodes[i].color != 0) ? dataObj.nodes[i].color :
                            dataObj.nodeColorMap[dataObj.nodes[i].name].color;
                    }
                    if(dataObj.nodes[i].color){
                        nodeLegends.set(dataObj.nodes[i].color, '');
                    }
                    maxNodeSize = (dataObj.nodes[i].size > maxNodeSize || maxNodeSize === 0) ? dataObj.nodes[i].size : maxNodeSize;
                }
                for (var i in dataObj.links) {
                    var combo1 = dataObj.linkColorMap[dataObj.links[i].source+'-'+dataObj.links[i].target];
                    var combo2 = dataObj.linkColorMap[dataObj.links[i].target+'-'+dataObj.links[i].source];
                    var comboColor;
                    /*if(combo1 && combo1.color){
                        comboColor = combo1.color;
                    } else if(combo2 && combo2.color){
                        comboColor = combo2.color;
                    }*/
                    if(oViz.getCurvedLine() === 'Off'){
                        if(combo1 && combo1.color){
                            comboColor = combo1.color;
                        } else if(combo2 && combo2.color){
                            comboColor = combo2.color;
                        }
                    } else {
                        if(combo1 && combo1.color){
                            comboColor = combo1.color;
                        }
                    }
                    dataObj.links[i].color = (dataObj.links[i].color && dataObj.links[i].color != 0 ) ? dataObj.links[i].color : comboColor;
                    if(dataObj.links[i].color) {
                        //console.log("Color edge "+dataObj.links[i].source+"-"+dataObj.links[i].target+" : "+dataObj.links[i].color);
                        linkLegends.set(dataObj.links[i].color, '');
                    }
                    dataObj.links[i].source = nodeList.indexOf(dataObj.links[i].source);
                    dataObj.links[i].target = nodeList.indexOf(dataObj.links[i].target);
                    maxLinkSize = (dataObj.links[i].weight > maxLinkSize || maxLinkSize === 0) ? dataObj.links[i].weight : maxLinkSize;
                    maxDistance = (dataObj.links[i].distance > maxDistance || maxDistance === 0) ? dataObj.links[i].distance : maxDistance;
                    rowMap.set(dataObj.links[i].row, {source: dataObj.links[i].source, target: dataObj.links[i].target});
                    comboColor = null, combo1 = null, combo2 = null;
                }
                oViz.setRowMap(rowMap);

                var isNodeColor = nodeLegends.size > 0 ? true : false;
                var isLinkColor = linkLegends.size > 0 ? true : false;

                var htmlContent = "<div class='networkvizcss'>" +  "<div class='canvas' id=" + cId + ">" +
                    "<div class='main'><p id=chart_" + cId + " class='chart'><\/p>" +
                    "<div id=footer_" + cId + "></div></div><div></div>";
                if(oViz.getLegendOption() === 'On'){
                    if(isLinkColor){
                        htmlContent += "<div><div id=legendPane2_"+cId+" class='title'>" +
                            "<span id=legendName2_"+cId+">Link Color</span></div>" +
                            "<div id=legend2_"+cId+" class='legend'></div>"+
                            "</div>";
                    }
                    if(isNodeColor) {
                        htmlContent += "<div>" +
                            "<div id=legendPane1_" + cId + " class='title'>" +
                            "<span id=legendName1_" + cId + ">Node Color</span></div>" +
                            "<div id=legend1_" + cId + " class='legend'></div></div>";
                    }
                }
                htmlContent += "</div></div>";
                $(elContainer).html(htmlContent);
              //  elContainer.style.overflow = "auto";

                $(".canvas").attr("width", $(elContainer).width());
                $(".canvas").attr("height", $(elContainer).height());
                var width = $(elContainer).width();
                var height = $(elContainer).height();
             //   var rect_width = 0.9 * width;

                /////// PLUGIN CODE STARTS HERE /////////
                /*var color = d3.scale.category20();
                var nColor = d3.scale.category20();
                var color = d3.scaleOrdinal(d3.schemeCategory10);
                var nColor = d3.scaleOrdinal(d3.schemeCategory10);*/

                /*var isFirstNodeColor = oViz.getFirstNodeColor() && oViz.getFirstNodeColor().startsWith("#") ? true : false;
                var isFirstLinkColor = oViz.getFirstLinkColor() && oViz.getFirstLinkColor().startsWith("#") ? true : false;
                var firstNodeColor = isFirstNodeColor ? oViz.getFirstNodeColor() : '';
                var firstLinkColor = isFirstLinkColor ? oViz.getFirstLinkColor() : '';*/

                var colorArray = ["#5FB9B5", "#DE7F11", "#B47282", "#4E4137",
                    "#A0C98B", "#84401F", "#295B62", "#9F80C9",
                    "#FEC36F", "#5B2F6F" , "#62A2B9", "#317A49"];

                var colorArray1 = [ "#8B008B", "#FF1493",
                    "#00FFFF", "#0000FF", "#7FFF00", "#00008B",
                    "#5FB9B5", "#DE7F11", "#B47282", "#4E4137",
                    "#A0C98B", "#84401F", "#295B62", "#9F80C9",
                    "#FEC36F", "#5B2F6F" , "#62A2B9", "#317A49"];

                var tempNodeColors = oViz.getFirstNodeColor() ? oViz.getFirstNodeColor().replaceAll(" ", "") : "";
                var tempLinkColors = oViz.getFirstLinkColor() ? oViz.getFirstLinkColor().replaceAll(" ", "") : "";

                var nColorArray = tempNodeColors ? tempNodeColors.split(",") : [];
                var lColorArray = tempLinkColors ? tempLinkColors.split(",") : [];

                var nodeColorArray = nColorArray && nColorArray.length > 0 ? nColorArray.concat(colorArray) : colorArray;
                var linkColorArray = lColorArray && lColorArray.length > 0 ? lColorArray.concat(colorArray) : colorArray;

                var color = function(d) {
                    return linkColorArray[d % linkColorArray.length];
                }
                var nColor = function(d) {
                    return nodeColorArray[d % nodeColorArray.length];
                }

                var widthParam = oViz.getLegendOption() === 'On' && (isNodeColor || isLinkColor) ? 130 : 0;
                width = width - widthParam;

                var order = function (a, b) {
                    return ('' + a).localeCompare(b, 'en', { numeric: true });
                    //return radius(b) - radius(a);
                };

                var nodeLegendList = isNodeColor ? Array.from(nodeLegends.keys()) : [];
                var linkLegendList = isLinkColor ? Array.from(linkLegends.keys()) : [];

                nodeLegendList.sort(order);
                linkLegendList.sort(order);

                if(isNodeColor){
                    //nodeLegends.set("Destination");
                    nodeLegendList.push("Dest Only");
                }

                var events = {
                    events: {},
                    subscribe: function (eventName, fn) {
                        this.events[eventName] = this.events[eventName] || [];
                        this.events[eventName].push(fn);
                    },
                    unsubscribe: function (eventName, fn) {
                        if (this.events[eventName]) {
                            for (var i = 0; i < this.events[eventName].length; i++) {
                                if (this.events[eventName][i] === fn) {
                                    this.events[eventName].splice(i, 1);
                                    break;
                                }
                            };
                        }
                    },
                    publish: function (eventName, data) {
                        if (this.events[eventName]) {
                            this.events[eventName].forEach(function (fn) {
                                fn(data);
                            });
                        }
                    }
                }

                function addLegendPane(){
                    var legendHeight, legendHeight1, legendHeight2;
                    var legendMaxHt = height * .85;
                    var marginOffset = 25;
                    var legendMarginTop;

                    if(isNodeColor && isLinkColor){
                        legendHeight1 = 20 * nodeLegendList.length;
                        addNodeLegend(legendHeight1, 0);
                        legendHeight2 = 20 * linkLegendList.length;
                        addLinkLegend(legendHeight2, 0);
                        //legendMaxHt = height/2;
                        legendHeight = legendHeight1 + legendHeight2;
                        legendMarginTop = legendMaxHt >= legendHeight ? ((legendMaxHt-legendHeight)/2)+marginOffset : marginOffset;

                        var l2Offset =  legendHeight1 > legendMaxHt/2 ? legendMaxHt/2 : legendHeight1;
                        $("#legend2_"+cId).css("max-height", legendMaxHt/2 - 10);
                        $("#legend2_"+cId).css("margin-top", l2Offset + 20 + legendMarginTop);
                        $("#legendPane2_"+cId).css("padding-top", l2Offset+ 25 + legendMarginTop-marginOffset);
                        $("#legendPane2_"+cId).css("height", "50%");

                        $("#legend1_"+cId).css("max-height", legendMaxHt/2 - 10);
                        $("#legend1_"+cId).css("margin-top", legendMarginTop);
                        $("#legendPane1_"+cId).css("padding-top", legendMarginTop-marginOffset);
                        $("#legendPane1_"+cId).css("height", "50%");

                    } else if (isNodeColor){
                        legendHeight1 = 20 * nodeLegendList.length;
                        addNodeLegend(legendHeight1, 0);
                        legendMarginTop = legendMaxHt >= legendHeight ? ((legendMaxHt-legendHeight)/2)+marginOffset : marginOffset;
                        $("#legend1_"+cId).css("max-height", legendMaxHt);
                        $("#legend1_"+cId).css("margin-top", legendMarginTop);
                        $("#legendPane1_"+cId).css("padding-top", legendMarginTop-marginOffset);
                    } else if(isLinkColor){
                        legendHeight2 = 20 * linkLegendList.length;
                        addLinkLegend(legendHeight2, 0);
                        legendMarginTop = legendMaxHt >= legendHeight ? ((legendMaxHt-legendHeight)/2)+marginOffset : marginOffset;
                        $("#legend2_"+cId).css("max-height", legendMaxHt);
                        $("#legend2_"+cId).css("margin-top", legendMarginTop);
                        $("#legendPane2_"+cId).css("padding-top", legendMarginTop-marginOffset);
                    }
                }

                function addNodeLegend(lHeight, yVal){
                    var svgLegend = d3.select("#legend1_"+cId).append("svg")
                        .attr("width", 110)
                        .attr("height", lHeight);
                    var legendN2 = svgLegend.selectAll("#legend1_"+cId)
                        .data(nodeLegendList)
                        .enter().append('g')
                        .attr("transform", function (d, i) {
                            return "translate(0," + i * 20 + ")";
                        })
                        .attr("width", 110)
                        .attr("height", lHeight);
                    legendN2.append('rect')
                        .attr("x", 0)
                        .attr("y", 0)
                        .attr("width", 10)
                        .attr("height", 10)
                        .style("fill", function (d, i) {
                            /*if(isFirstNodeColor && nodeLegendList.indexOf(d) === 0){
                                return firstNodeColor;
                            }*/
                            if(d === "Dest Only"){
                                if(oViz.getDestOnlyColor()){
                                    return oViz.getDestOnlyColor();
                                }
                                return '#474747';
                            }
                            return nColor(nodeLegendList.indexOf(d));
                        });
                    legendN2.append('text')
                        .attr("x", 20)
                        .attr("y", 10)
                        .text(function (d, i) {
                            return d
                        })
                        .attr("class", "textselected")
                        .style("text-anchor", "start")
                        .style("font-size", 10);
                }
                function addLinkLegend(lHeight, yVal){
                    var svgLegend = d3.select("#legend2_"+cId).append("svg")
                        .attr("width", 110)
                        .attr("height", lHeight);
                    var legendN2 = svgLegend.selectAll("#legend2_"+cId)
                        .data(linkLegendList)
                        .enter().append('g')
                        .attr("transform", function (d, i) {
                            return "translate(0," + i * 20 + ")";
                        })
                        .attr("width", 110)
                        .attr("height", lHeight);
                    legendN2.append('rect')
                        .attr("x", 0)
                        .attr("y", 0)
                        .attr("width", 10)
                        .attr("height", 10)
                        .style("fill", function (d, i) {
                            /*if(isFirstLinkColor && linkLegendList.indexOf(d) === 0){
                                return firstLinkColor;
                            }*/
                            return color(linkLegendList.indexOf(d));
                        });
                    legendN2.append('text')
                        .attr("x", 20)
                        .attr("y", 10)
                        .text(function (d, i) {
                            return d
                        })
                        .attr("class", "textselected")
                        .style("text-anchor", "start")
                        .style("font-size", 10);
                }

                function onOutsideClick(e)
                {
                    var circle = $("circle");
                    var line = $("line");
                    var path = $("path");
                    var clicked = false;
                    if(!e.ctrlKey){
                        // if the target of the click isn't the container nor a descendant of the container
                        if (!circle.is(e.target) && circle.has(e.target).length === 0)
                        {
                            $("circle").removeClass("mark");
                            clicked = true;
                        }
                        if (!line.is(e.target) && line.has(e.target).length === 0)
                        {
                            $("line").removeClass("mark");
                            clicked = true;
                        }
                        if (!path.is(e.target) && path.has(e.target).length === 0)
                        {
                            $("path").removeClass("mark");
                            clicked = true;
                        }
                        if(clicked){
                            var oMarkingService = oViz.getMarkingService();
                            oMarkingService.clearMarksForDataLayout(oDataLayout);
                            oViz._publishMarkEvent(oDataLayout/*, marking.EMarkContext.MARK_ALL*/);
                        }
                    }
                }

                var svg = d3.select("#chart_" + cId).append("svg:svg")
                    .attr("width", width)
                    .attr("height", height - 10)
                    .attr("pointer-event", "all")
                    .attr("id", "svg_"+cId)
                    .call(d3.zoom().scaleExtent([1/10, 20]).on("zoom", (event) => {
                        svg.attr('transform', event.transform);
                    }))
                    .on("click", function(event, d){
                        //console.log("svg on click..");
                        onOutsideClick(event);
                    })
                    .append("svg:g")
                    .attr("height", height - 10)
                    .append("svg:g")
                    .attr("height", height - 10);

                   
                svg.append("svg:rect")
                    .attr("id", "rect_"+cId)
                    .attr("width", width)
                    .attr("height", height - 10)
                    .attr("overflow", "hidden")
                    .attr('fill', 'white');

                //$("#chart_" + cId).mousedown(onOutsideClick);
                //$("#svg_" + cId).mouseup(onOutsideClick);
                //$("#rect_" + cId).mousedown(onOutsideClick);



                if(oViz.getArrows() === 'On'){
                    svg.append('svg:defs').append('marker')
                        .attr("id",'arrowhead_'+oViz.getCID())
                        .attr("class",'marker_only')
                        .attr('viewBox','0 -5 10 10') //the bound of the SVG viewport for the current SVG fragment. defines a coordinate system 10 wide and 10 high starting on (0,-5)
                        .attr('refX',0) // x coordinate for the reference point of the marker. If circle is bigger, this need to be bigger.
                        .attr('refY',0)
                        .attr('orient','auto')
                        .attr('markerWidth',5)
                        .attr('markerHeight',5)
                        //.attr('xoverflow','visible')
                        .append('svg:path')
                        .attr('d', 'M0,-5L10,0L0,5');
                }


                var drag_handler = d3.drag()
                    .on("start", dragstarted)
                    .on("drag", dragged)
                    .on("end", dragended);

                var link = svg.selectAll(".links");
                var node = svg.selectAll(".node");
                var markerPath = svg.selectAll("marker");
                var footer = svg.selectAll("footer");
                var linkLabels = svg.selectAll(".link-label");

                //drag_handler(node);

                /*var force = d3.layout.force()
                    .friction(0.01 * oViz.getClusterSpacingFactor())
                    .gravity(0.05)
                    .charge(-1000)
                    //.alpha(0)
                    .on('start', start)
                    /!*.friction(0.5)
                    .gravity(0.01)
                    .charge(-100)*!/
                    /!*.theta(0.8)*!/
                    .linkDistance(function (d) {
                        var dist = d.distance && d.distance > 1 ? (d.distance / maxDistance ) * oViz.getLineLengthMag() * 10 : oViz.getLineLengthMag() * 5;
                        return Math.round(dist);
                    })
                    .linkStrength(1)
                    .size([width, height]);
                force
                    .nodes(dataObj.nodes)
                    .links(dataObj.links);
                    //.start();*/

                var csf = oViz.getClusterSpacingFactor();
                var velFactor = 0.5;
                if (csf >= 1 && csf <= 100){
                    velFactor = (100 - csf + 1)/100;
                } else if (csf > 100){
                    velFactor = 0.01;
                } else {
                    velFactor = 1;
                }

                var force = d3
                    .forceSimulation(dataObj.nodes)
                    .force("x", d3.forceX(width / 2).strength(0.05))
                    .force("y", d3.forceY(height / 2).strength(0.05))
                    .force("charge", d3.forceManyBody().strength(-50))
                    .force("center", d3.forceCenter(width / 2, height / 2))
                    .force("link", d3.forceLink(dataObj.links).distance(function(d) {
                        var dist = d.distance && d.distance > 1 ? (d.distance / maxDistance ) * oViz.getLineLengthMag() * 10 : oViz.getLineLengthMag() * 5;
                        return Math.round(dist);
                    }).strength(1).id(function(d) { return d.id; }))
                    .force("collision", d3.forceCollide().radius(csf))
                    //.velocityDecay(0.05 * oViz.getClusterSpacingFactor())
                    //.velocityDecay(velFactor)
                    .alphaTarget(0)
                    .alphaDecay(0.2)
                    .on("tick", tick);

                function formatAndRound(num){
                    return thousands_separators(Math.round((num + Number.EPSILON) * 100) / 100);
                }
                function thousands_separators(num)
                {
                    var num_parts = num.toString().split(".");
                    num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    return num_parts.join(".");
                }
                function nodeTooltip(obj) {
                    var d = obj.srcElement.__data__;
                    var content = "<table>" +
                        "<tr><td class='tthead'>Name:</td><td class='ttval'>"+d.name+"</td></tr>";
                    if(d.color){
                        content += "<tr><td class='tthead'>"+d.cLabel+"(Color):</td><td class='ttval'>"+d.color+"</td></tr>";
                    } else if(isNodeColor && !d.isSource){
                        content += "<tr><td class='tthead'>"+d.cLabel+"(Color):</td><td class='ttval'>Dest Only</td></tr>";
                    }
                    if(d.isSource && d.size > 0){
                        content += "<tr><td class='tthead'>"+d.sLabel+"(Size):</td><td class='ttval'>"+formatAndRound(d.size)+"</td></tr>";
                    }
                    content += "</table>";

                    tooltip.style("display", null);
                    return content;
                }
                function linkTooltip(obj) {
                    var d = obj.srcElement.__data__;
                    /*var combo1 = dataObj.linkColorMap[d.source.name+'-'+d.target.name];
                    var combo2 = dataObj.linkColorMap[d.target.name+'-'+d.source.name];*/
                    var content = "<table>" +
                        "<tr><td class='tthead'>Source:</td><td class='ttval'>"+d.source.name+"</td></tr>"+
                        "<tr><td class='tthead'>Destination:</td><td class='ttval'>"+d.target.name+"</td></tr>";
                    if(d.distance && d.dLabel){
                        content += "<tr><td class='tthead'>"+d.dLabel+"(Distance):</td><td class='ttval'>"+formatAndRound(d.distance)+"</td></tr>";
                    }
                    if(d.color){
                        content += "<tr><td class='tthead'>"+d.cLabel+"(Color):</td><td class='ttval'>"+d.color+"</td></tr>";
                    }/*else if (combo1 && combo1.color){
                        content += "<tr><td class='tthead'>"+d.cLabel+"(Color):</td><td class='ttval'>"+combo1.color+"</td></tr>";
                    }else if (combo2 && combo2.color){
                        content += "<tr><td class='tthead'>"+d.cLabel+"(Color):</td><td class='ttval'>"+combo2.color+"</td></tr>";
                    }*/
                    if(d.weight > 0){
                        content += "<tr><td class='tthead'>"+d.sLabel+"(Size):</td><td class='ttval'>"+formatAndRound(d.weight)+"</td></tr>";
                    }
                    content += "</table>";
                    tooltip.style("display", null);
                    return content;
                }

                if(oViz.getCurvedLine() === 'Off'){
                    link = svg.selectAll(".link")
                        .data(dataObj.links)
                        .enter().append("line")
                        .attr("id", function(d) {
                            return d.row;
                        });

                    if(oViz.getArrows() === 'On'){
                        markerPath = svg.selectAll(".marker")
                            .data(dataObj.links)
                            .enter().append("svg:line")
                            .attr("id", function(d) {
                                return d.row;
                            })
                            /*.attr("fill", "none")*/
                            .attr("marker-end", "url(#arrowhead_"+oViz.getCID()+")");
                    }
                } else {
                    link = svg.selectAll(".link")
                        .data(dataObj.links)
                        .enter().append("path")
                        .attr("fill", "none")
                        .attr("id", function(d) {
                            return d.row;
                        });
                    if(oViz.getArrows() === 'On'){
                        markerPath = svg.selectAll(".marker")
                            .data(dataObj.links)
                            .enter().append("svg:path")
                            .attr("id", function(d) {
                                return d.row;
                            })
                            .attr("fill", "none")
                            .attr("marker-end", "url(#arrowhead_"+oViz.getCID()+")");
                    }
                }
               // add labels to lines
              //  if (oViz.getLabels() === 'On') {
                    linkLabels = svg.selectAll(".link-label")
                        .data(dataObj.links)
                        .enter()
                        .append("text")
                        .attr("class", "link-label")
                        .attr("text-anchor", "middle")
                        .attr("font-size", "4px")
                        .attr("fill", "#696969")
                        .attr("font-family", "sans-serif")
                        .text(function (d) {
                            return d.item;  // Dynamically use the item from each link
                        });
           //     }
               

                link
                    .attr("class", "links")
                    .attr("data-row", function(d) {
                        return d.row;
                    })
                    .style("stroke-width", function (d) {
                        var sWidth = d.weight ? Math.sqrt(d.weight / maxLinkSize) * oViz.getLineSizeMag() + .5 : 1;
                        return sWidth;
                    })
                    .attr("stroke", function (d) {
                        if (d.color) {
                            /*if(isFirstLinkColor && linkLegendList.indexOf(d.color) === 0){
                                return firstLinkColor;
                            }*/
                            return color(linkLegendList.indexOf(d.color));
                        }
                        else
                            return '#999';
                    })
                    .on("mouseover", function(d) {
                        //return tooltip.style("visibility", "visible").html(linkTooltip(d));
                        return tooltip.style("display", null).html(linkTooltip(d));
                    })
                    // we move tooltip during of "mousemove"
                    .on("mousemove", function() {
                        return tooltip.style("top", (event.pageY - 20) + "px")
                            .style("left", event.pageX + "px");
                    })
                    // we hide our tooltip on "mouseout"
                    .on("mouseout", function() {
                        //return tooltip.style("visibility", "hidden");
                        return tooltip.style("display", "none");
                    })
                    .on("click", function(event, d){
                        event.preventDefault();
                        event.stopPropagation();
                        var oMarkingService = oViz.getMarkingService();
                        if(!event.ctrlKey) {
                            oMarkingService.clearMarksForDataLayout(oDataLayout);
                        }
                        //oMarkingService.setMark(oDataLayout, datamodelshapes.Physical.ROW, 0, parseInt(d.row));
                        oMarkingService.setMark(oDataLayout, datamodelshapes.Physical.DATA, parseInt(d.row), 0);
                        oViz._publishMarkEvent(oDataLayout);
                        $("line").removeClass("mark");
                        $("path").removeClass("mark");
                        $("circle").removeClass("mark");
                        $(this).addClass("mark");
                        $("circle[data-row='"+d.source.id+"']").addClass("mark");
                        $("circle[data-row='"+d.target.id+"']").addClass("mark");
                        tooltip.style("display", "none");
                    })
                    .on("contextmenu", function (event, d) {
                        //d3.event.stopPropagation();
                        event.preventDefault();
                        var oMarkingService = oViz.getMarkingService();
                        //oMarkingService.clearMarksForDataLayout(oDataLayout);
                        oMarkingService.setMark(oDataLayout, datamodelshapes.Physical.DATA, parseInt(d.row), 0);
                        oViz._publishMarkEvent(oDataLayout);
                        $("line").removeClass("mark");
                        $("path").removeClass("mark");
                        $("circle").removeClass("mark");
                        $(this).addClass("mark");
                        $("circle[data-row='"+d.source.id+"']").addClass("mark");
                        $("circle[data-row='"+d.target.id+"']").addClass("mark");
                        tooltip.style("display", "none");
                    });


                node = svg.selectAll(".node")
                    .data(dataObj.nodes)
                    .enter().append("g")
                    .attr("class", "node")
                    .call(drag_handler)
                    .on("mouseover", function(d) {
                        //return tooltip.style("visibility", "visible").html(nodeTooltip(d));
                        return tooltip.style("display", null).html(nodeTooltip(d));
                    })
                    // we move tooltip during of "mousemove"
                    .on("mousemove", function() {
                        return tooltip.style("top", (event.pageY - 20) + "px")
                            .style("left", event.pageX + "px");
                    })
                    // we hide our tooltip on "mouseout"
                    .on("mouseout", function() {
                        //return tooltip.style("visibility", "hidden");
                        return tooltip.style("display", "none");
                    });

                node.append("circle")
                    .attr("data-row", function(d) {
                        return d.id;
                    })
                    .attr("r", function (d) {
                        var radius;
                        radius = d.size ? ((d.size / maxNodeSize) * oViz.getNodeSizeMag())+5 : 5;
                        return radius;
                    })
                    .attr("fill", function (d) {
                        if(isNodeColor){
                            if(d.isSource){
                                if(d.color){
                                    /*if(isFirstNodeColor && nodeLegendList.indexOf(d.color) === 0){
                                        return firstNodeColor;
                                    }*/
                                    //return nColor(d.color);
                                    return nColor(nodeLegendList.indexOf(d.color));
                                } else {
                                    return nColor("default");
                                }
                            }
                            else {
                                //return nColor("Destination");
                                if(oViz.getDestOnlyColor()){
                                    return oViz.getDestOnlyColor();
                                }
                                return '#474747';
                            }
                        } else {
                            //return '#1f77b4';
                            return '#62A2B9';
                        }

                    })
                    .on("click", function(event, d){
                        //force.alphaTarget(0);
                        force.stop();
                        event.preventDefault();
                        event.stopPropagation();
                        //force.tick(50);
                        var oMarkingService = oViz.getMarkingService();
                        if(!event.ctrlKey) {
                            oMarkingService.clearMarksForDataLayout(oDataLayout);
                        }
                        //oMarkingService.clearMarksForDataLayout(oDataLayout);
                        var links = dataObj.nodeMap.get(d.name);
                        $("line").removeClass("mark");
                        $("path").removeClass("mark");
                        $("circle").removeClass("mark");
                        for(let i=0; i<links.length; i ++){
                            //oMarkingService.setMark(oDataLayout, datamodelshapes.Physical.ROW, 0, parseInt(links[i]));
                            oMarkingService.setMark(oDataLayout, datamodelshapes.Physical.DATA, parseInt(links[i]), 0);
                            //console.log(links[i]);
                            $("line[data-row='"+links[i]+"']").addClass("mark");
                            $("path[data-row='"+links[i]+"']").addClass("mark");
                            $("circle[data-row='"+oViz.getRowMap().get(links[i]).source+"']").addClass("mark");
                            $("circle[data-row='"+oViz.getRowMap().get(links[i]).target+"']").addClass("mark");
                        }
                        oViz._publishMarkEvent(oDataLayout);
                        tooltip.style("display", "none");
                    })
                    .on("contextmenu", function (event, d) {
                        var oMarkingService = oViz.getMarkingService();
                        //oMarkingService.clearMarksForDataLayout(oDataLayout);
                        var links = dataObj.nodeMap.get(d.name);
                        $("line").removeClass("mark");
                        $("path").removeClass("mark");
                        $("circle").removeClass("mark");
                        for(let i=0; i<links.length; i ++){
                            oMarkingService.setMark(oDataLayout, datamodelshapes.Physical.DATA, parseInt(links[i]), 0);
                            $("line[data-row='"+links[i]+"']").addClass("mark");
                            $("path[data-row='"+links[i]+"']").addClass("mark");
                            $("circle[data-row='"+oViz.getRowMap().get(links[i]).source+"']").addClass("mark");
                            $("circle[data-row='"+oViz.getRowMap().get(links[i]).target+"']").addClass("mark");
                        }
                        oViz._publishMarkEvent(oDataLayout);
                        //$(this).parent().children().removeClass("mark");
                        $(this).addClass("mark");
                        tooltip.style("display", "none");
                    });

                if(oViz.getTurnDesc() === "On"){
                    node.append("text")
                        .attr("dx", 12)
                        .attr("dy", ".30em")
                        .text(function (d) {
                            return d.name
                        });
                }
                //force.on("tick", tick);

                var footerSvg = d3.select("#footer_"+cId)
                    .attr("width", 200)
                    .attr("height", 30)
                    .attr("x", (width / 2)-55)
                    .attr("y", height)
                    .attr("class", "footer")
                    .style("margin-left", (width / 2))
                    .append("svg")
                    .attr("class", "footer")
                    .style("margin-left", (width / 2))
                    .attr("width", 200)
                    .attr("height", 30)
                    .attr("x", (width / 2)-55)
                    .attr("y", height);

                footerSvg
                    .append('rect')
                    .attr("id", "footerDot_"+cId)
                    .attr("width", 12)
                    .attr("height", 12)
                    .attr("rx", 5)
                    .attr("ry", 5)
                    .style("fill", "#d50505");
                footerSvg
                    .append("text")
                    .attr("id", "footerText_"+cId)
                    .attr("width", 100)
                    .attr("height", 15)
                    .attr("x", 55)
                    .attr("y", 12)
                    .attr("text-anchor", "middle")
                    .style("display", null)
                    .style("font-weight", "bold")
                    .style("font-size", "16px")
                    .style("fill", "#000000")
                    .text("Loading...");

                var interval = 2;
                function loading(){
                    events.subscribe("ticking", function(data){
                        if(data){
                            interval++;
                        }
                    });
                }

                loading();
                var loadInterval = setInterval(function(){
                    //console.log("Interval : "+interval);
                    if(interval<0){
                        $("#footerDot_"+cId).css("display", "none");
                        $("#footerText_"+cId).css("display", "none");
                        clearInterval(loadInterval);
                        interval = 2;
                    } else {
                        $("#footerDot_"+cId).css("display", null);
                        $("#footerText_"+cId).css("display", null);
                        interval--;
                    }
                }, 1);
                //link.exit().remove();
                //node.exit().remove();
                //force.restart();

                function tick() {
                    events.publish("ticking", true);
                        if(oViz.getCurvedLine() === 'Off'){
                            link.attr("x1", function (d) {
                                return d.source.x;
                            })
                                .attr("y1", function (d) {
                                    return d.source.y;
                                })
                                .attr("x2", function (d) {
                                    return d.target.x;
                                })
                                .attr("y2", function (d) {
                                    return d.target.y;
                                });

                            if(oViz.getArrows() === 'On'){
                                markerPath
                                    .attr("x1", function (d) {
                                        return d.source.x;
                                    })
                                    .attr("y1", function (d) {
                                        return d.source.y;
                                    })
                                    .attr("x2", function (d) {
                                        return (d.target.x + d.source.x) / 2;
                                    })
                                    .attr("y2", function (d) {
                                        return (d.target.y + d.source.y) / 2;
                                    });
                            }
                        
                        } else {
                            link.attr("d", function(d) {
                                var dx = d.target.x - d.source.x,
                                    dy = d.target.y - d.source.y,
                                    dr = Math.sqrt(dx * dx + dy * dy);
                                if(!isNaN(dr) && !isNaN(d.source.x) && !isNaN(d.source.y) && !isNaN(d.target.x) && !isNaN(d.target.y))
                                return "M" +
                                    d.source.x + "," +
                                    d.source.y + "A" +
                                    dr + "," + dr + " 0 0,1 " +
                                    d.target.x + "," +
                                    d.target.y;
                            });
                            if(oViz.getArrows() === 'On'){
                                markerPath.attr("d", function(d) {
                                    var dx = d.target.x - d.source.x,
                                        dy = d.target.y - d.source.y,
                                        dr = Math.sqrt(dx * dx + dy * dy);

                                    var endX = (d.target.x + d.source.x) / 2;
                                    var endY = (d.target.y + d.source.y) / 2;

                                    var len = dr - ((dr/2) * Math.sqrt(3));

                                    endX = endX + (dy * len/dr);
                                    endY = endY + (-dx * len/dr);

                                    if(!isNaN(dr) && !isNaN(endX) && !isNaN(endY) && !isNaN(d.source.x) && !isNaN(d.source.y))
                                        return "M" + d.source.x + "," + d.source.y + "A" + dr + "," + dr + " 0 0,1 " + endX + "," + endY;
                                });
                            }
                    }
                    if (oViz.getCurvedLine() === 'Off') {
                        linkLabels
                            .attr("x", function (d) {
                                return (d.source.x + d.target.x) / 2;
                            })
                            .attr("y", function (d) {
                                return (d.source.y + d.target.y) / 2 - 5;
                            });
                    } else {
                        linkLabels
                            .attr("x", function (d) {
                                var dx = d.target.x - d.source.x;
                                var dy = d.target.y - d.source.y;
                                var dr = Math.sqrt(dx * dx + dy * dy);

                                var midX = (d.target.x + d.source.x) / 2;
                                var midY = (d.target.y + d.source.y) / 2;

                                var len = dr - ((dr / 2) * Math.sqrt(3));

                                var labelX = midX + (dy * len / dr);

                                return isNaN(labelX) ? midX : labelX;
                            })
                            .attr("y", function (d) {
                                var dx = d.target.x - d.source.x;
                                var dy = d.target.y - d.source.y;
                                var dr = Math.sqrt(dx * dx + dy * dy);

                                var midX = (d.target.x + d.source.x) / 2;
                                var midY = (d.target.y + d.source.y) / 2;

                                var len = dr - ((dr / 2) * Math.sqrt(3));

                                var labelY = [(midY + (-dx * len / dr))*0.98];
                                return isNaN(labelY) ? midY : labelY;
                            });
                    }

                    

                        node.attr("transform", function (d) {
                            if(!isNaN(d.x) && !isNaN(d.y))
                            return "translate(" + d.x + "," + d.y + ")";
                        });
                        /*node.attr("cx", function(d) { return d.x; })
                            .attr("cy", function(d) { return d.y; });*/
                };

                function start() {
                    var ticksPerRender = nRows > 1000 ? 10 : 5;
                    requestAnimationFrame(function render() {
                        for (var i = 0; i < ticksPerRender; i++) {
                            force.tick();
                            //tick();
                        }
                        if (force.alpha() > 0) {
                            requestAnimationFrame(render);
                        }
                    });
                }

                function zoom() {
                    //svg.attr("transform", "translate(" + d3.event.translate + ")scale(" + d3.event.scale + ")");
                    svg.attr("transform", d3.event.transform);
                }

                function dragstarted(event, d) {

                    if (!event.active) force.alphaTarget(0.1).restart();
                    d.fx = d.x;
                    d.fy = d.y;

                    //d3.select(this).classed("dragging", true);
                    tooltip.style("display", "none");
                }

                function dragged(event, d) {
                    //d3.select(this).attr("x", d.x = event.x).attr("y", d.y = event.y);
                    d.fx = event.x;
                    d.fy = event.y;
                    tooltip.style("display", "none");
                }

                function dragended(event, d) {
                    if (!event.active) force.alphaTarget(0);
                    d.fx = d.x;
                    d.fy = d.y;
                    //d3.select(this).classed("dragging", false);
                }
                if(oViz.getLegendOption() === 'On'){
                    addLegendPane();
                }
                /////// PLUGIN CODE ENDS HERE //////////
            } finally {
                this._setIsRendered(true);
            }


        }

        /**
         * Called whenever new data is ready and this visualization needs to update.
         * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
         */
        Network2Viz.prototype.render = function (oTransientRenderingContext) {
            // Note: all events will be received after initialize and start complete.  We may get other events
            // such as 'resize' before the render, i.e. this might not be the first event.

            this._render(oTransientRenderingContext);
            //this.renderLegend(oTransientRenderingContext);
            //this._buildSelectedItems(oTransientRenderingContext);
        };


        /**
         * Resize the visualization
         * @param {Object} oVizDimensions - contains two properties, width and height
         * @param {module:obitech-report/vizcontext#VizContext} oTransientVizContext the viz context
         */
        Network2Viz.prototype.resizeVisualization = function (oVizDimensions, oTransientVizContext) {
            var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
            this.render(oTransientRenderingContext);
        };

        /**
         * Re-render the visualization when settings changes
         */
        /*Network2Viz.prototype._onDefaultSettingsChanged = function () {
            var oTransientVizContext = this.assertOrCreateVizContext();
            var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
            this.render(oTransientRenderingContext);
            this._setIsRendered(true);
        };*/


        Network2Viz.prototype._publishMarkEvent = function (oDataLayout, eMarkContext) {

            try {
                // Create the marking event
                var markingEvent = new interactions.MarkingEvent(this.getID(), this.getViewName(), oDataLayout, null, eMarkContext);
                //markingEvent = jsx.isNull(markingEvent) ? marking.EPublishMarkingEvent.PUBLISH : markingEvent;
                var eventRouter = this.getEventRouter();
                if (eventRouter) {
                    // Publish the event to listeners
                    eventRouter.publish(markingEvent);
                }
            }
            catch (e) {
                console.log("Error during mark", e);
            }
        };


        /**
         * Override to add in options to the context menu
         *
         * @param {module:obitech-report/vizcontext#VizContext} oTransientVizContext the viz context
         * @param {string} sMenuType The menu type associated with the context menu being populated
         * @param {Array} The array of resulting menu options
         * @param {module:obitech-appservices/contextmenu} contextmenu The contextmenu namespace object (used to reduce dependencies)
         * @param {object} evtParams The entire 'params' object that is extracted from client evt
         * @param {object} oTransientRenderingContext the current transient rendering context
         */
        Network2Viz.prototype._addVizSpecificMenuOptions = function (oTransientVizContext, sMenuType, aResults, contextmenu, evtParams, oTransientRenderingContext) {
            //aResults.shift();
            Network2Viz.superClass._addVizSpecificMenuOptions.call(this, oTransientVizContext, sMenuType, aResults, contextmenu, evtParams, oTransientRenderingContext);
            if (sMenuType === euidef.CM_TYPE_VIZ_PROPS) {
                // Set up the column context for the last column in the ROWS bucket
                var oColumnContext = this.getDrillPathColumnContext(oTransientVizContext, datamodelshapes.Logical.ROW);

                // Set up events
                if(!this.isViewOnlyLimit()){
                    //this._addFilterMenuOption(oTransientVizContext, aResults, null, null, oTransientRenderingContext);
                    this._addFilterMenuOption(oTransientVizContext, aResults, null, null, oTransientRenderingContext);
                    //this._addRemoveSelectedMenuOption(oTransientVizContext, aResults, null, null, oTransientRenderingContext);
                    this._addRemoveSelectedMenuOption(oTransientVizContext, aResults, null, null, oTransientRenderingContext);
                    //this._addColorMenuOption(oTransientVizContext, aResults, oTransientRenderingContext);
                    //this._addDrillMenuOption(oTransientVizContext, aResults, null, null, oColumnContext, oTransientRenderingContext);
                    //this._addLateralDrillMenuOption(oTransientVizContext, elt me aResults);
                }
            }
        };

        Network2Viz.prototype._addVizSpecificPropsDialog = function (oTabbedPanelsGadgetInfo) {

            //var options = this.getViewConfig() || {};
            //this._fillDefaultOptions(options, null);
            //this._addLegendToVizSpecificPropsDialog(options, oTabbedPanelsGadgetInfo);

            this.doAddVizSpecificPropsDialog(this, oTabbedPanelsGadgetInfo);
            Network2Viz.superClass._addVizSpecificPropsDialog.call(this, oTabbedPanelsGadgetInfo);

        };

        /**
         * TODO: Legend should take care of this
         * Given an options / config object, configure it with default options for the visualization.
         *
         * @param {object} oOptions the options
         * @param {module:obitech-framework/actioncontext#ActionContext} oActionContext The ActionContext instance associated with this action
         * @protected
         */
        /*Network2Viz.prototype._fillDefaultOptions = function (oOptions/!*, oActionContext*!/) {
            if (!jsx.isNull(oOptions) && !jsx.isNull(oOptions.legend))
                return;

            // Legend
            oOptions.legend = jsx.defaultParam(oOptions.legend, {});
            oOptions.legend.rendered = jsx.defaultParam(oOptions.legend.rendered, "on");
            oOptions.legend.position = jsx.defaultParam(oOptions.legend.position, "auto");

            this.getSettings().setViewConfigJSON(dataviz.SettingsNS.CHART, oOptions);
        };*/

        Network2Viz.prototype.doAddVizSpecificPropsDialog = function (oTransientRenderingContext, oTabbedPanelsGadgetInfo) {
            jsx.assertObject(oTransientRenderingContext, "oTransientRenderingContext");
            jsx.assertInstanceOf(oTabbedPanelsGadgetInfo, gadgets.TabbedPanelsGadgetInfo, "oTabbedPanelsGadgetInfo", "obitech-application/gadgets.TabbedPanelsGadgetInfo");

            var oDataModel = this.getRootDataModel();
            if(!oDataModel){
                return;
            }

            this.setTabInfo(oTabbedPanelsGadgetInfo);
            var viewConfig = this.getViewConfig() || {};
            var options = this.getViewConfig() || {};
            this._fillDefaultOptions(options, null);
            var generalPanel = gadgetdialog.forcePanelByID(oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_GENERAL);

            var oGadgetFactory = this.getGadgetFactory();

            var turnDesc = [];
            turnDesc.push(new gadgets.OptionInfo('On','On'));
            turnDesc.push(new gadgets.OptionInfo('Off','Off'));

            var oTurnDescTypeGVP = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.turnDesc);
            var oTurnDescTypeGadgetInfo = new gadgets.TextSwitcherGadgetInfo("turnDescTypeGadget", 'Display Label', 'Display Label', oTurnDescTypeGVP, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE, false, turnDesc);
            generalPanel.addChild(oTurnDescTypeGadgetInfo);

            var oNodeSizeMagKey = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.nodeSizeMag);
            var oNodeSizeMagInfo = oGadgetFactory.createGadgetInfo("nodeSizeMagGadget", 'Node Size Magnifier', 'Node Size Magnifier', oNodeSizeMagKey);
            generalPanel.addChild(oNodeSizeMagInfo);

            var oLineSizeMagKey = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.lineSizeMag);
            var oLineSizeMagInfo = oGadgetFactory.createGadgetInfo("lineSizeMagGadget", 'Link Size Magnifier', 'Link Size Magnifier', oLineSizeMagKey);
            generalPanel.addChild(oLineSizeMagInfo);

            var oLineLengthMagKey = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.lineLengthMag);
            var oLineLengthMagInfo = oGadgetFactory.createGadgetInfo("lineLengthMagGadget", 'Link Length Magnifier', 'Link Length Magnifier', oLineLengthMagKey);
            generalPanel.addChild(oLineLengthMagInfo);

            var oClusterSpacingFactorKey = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.clusterSpacingFactor);
            var oClusterSpacingFactorInfo = oGadgetFactory.createGadgetInfo("clusterSpacingFactorGadget", 'Cluster Spacing Factor', 'Cluster Spacing Factor', oClusterSpacingFactorKey);
            generalPanel.addChild(oClusterSpacingFactorInfo);

            var oFirstNodeColorKey = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.firstNodeColor);
            var oFirstNodeColorInfo = oGadgetFactory.createGadgetInfo("firstNodeColorGadget", 'Node Series Color', 'Node Series Color', oFirstNodeColorKey);
            generalPanel.addChild(oFirstNodeColorInfo);

            var oFirstLinkColorKey = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.firstLinkColor);
            var oFirstLinkColorInfo = oGadgetFactory.createGadgetInfo("firstLinkColorGadget", 'Link Series Color', 'Link Series Color', oFirstLinkColorKey);
            generalPanel.addChild(oFirstLinkColorInfo);

            var oDestOnlyColorKey = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.destOnlyColor);
            var oDestOnlyColorInfo = oGadgetFactory.createGadgetInfo("destOnlyColorGadget", 'Dest Only Color', 'Dest Only Color', oDestOnlyColorKey);
            generalPanel.addChild(oDestOnlyColorInfo);

            var curvedLine = [];
            curvedLine.push(new gadgets.OptionInfo('On','On'));
            curvedLine.push(new gadgets.OptionInfo('Off','Off'));

            var oCurvedLineTypeGVP = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.curvedLine);
            var oCurvedLineTypeGadgetInfo = new gadgets.TextSwitcherGadgetInfo("curvedLineTypeGadget", 'Curved Line', 'Curved Line', oCurvedLineTypeGVP, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE, false, curvedLine);
            generalPanel.addChild(oCurvedLineTypeGadgetInfo);

            var legendOption = [];
            legendOption.push(new gadgets.OptionInfo('On','On'));
            legendOption.push(new gadgets.OptionInfo('Off','Off'));

            var oLegendOptionTypeGVP = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.legendOption);
            var oLegendOptionTypeGadgetInfo = new gadgets.TextSwitcherGadgetInfo("legendOptionTypeGadget", 'Legends', 'Legends', oLegendOptionTypeGVP, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE, false, legendOption);
            generalPanel.addChild(oLegendOptionTypeGadgetInfo);

            var arrowsOption = [];
            arrowsOption.push(new gadgets.OptionInfo('On','On'));
            arrowsOption.push(new gadgets.OptionInfo('Off','Off'));

            var oArrowsTypeGVP = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.arrows);
            var oArrowsTypeGadgetInfo = new gadgets.TextSwitcherGadgetInfo("arrowsTypeGadget", 'Direction Mark', 'Direction Mark', oArrowsTypeGVP, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE, false, arrowsOption);
            generalPanel.addChild(oArrowsTypeGadgetInfo);

            //var labelsOption = [];
            //labelsOption.push(new gadgets.OptionInfo('On', 'On'));
            //labelsOption.push(new gadgets.OptionInfo('Off', 'Off'));

            //var oLabelsTypeGVP = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.labels);
            //var oLabelsTypeGadgetInfo = new gadgets.TextSwitcherGadgetInfo("labelsTypeGadget", 'Labels', 'Labels', oLabelsTypeGVP, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE, false, labelsOption);
            //generalPanel.addChild(oLabelsTypeGadgetInfo);

            if (Network2Viz.superClass.doAddVizSpecificPropsDialog)
                Network2Viz.superClass.doAddVizSpecificPropsDialog.apply(this, arguments);
        };

        Network2Viz.prototype._handlePropChange = function (sGadgetID, oPropChange, oViewSettings, oActionContext) {
            var updateSettings = Network2Viz.superClass._handlePropChange.call(this, sGadgetID, oPropChange, oViewSettings, oActionContext);
            if (updateSettings) {
                return updateSettings; // super handled it
            }

            // Allow the super class an attempt to handle the changes
            var conf = oViewSettings.getViewConfigJSON(dataviz.SettingsNS.CHART) || {};

            if (sGadgetID === "turnDescTypeGadget")
            {
                if (jsx.isNull(conf.styleDefaults))
                {
                    conf.styleDefaults = {};
                }

                this.setTurnDesc(oPropChange.value);
                updateSettings = true;
            }
            if (sGadgetID === "nodeSizeMagGadget")
            {
                if (jsx.isNull(conf.styleDefaults))
                {
                    conf.styleDefaults = {};
                }

                this.setNodeSizeMag(oPropChange.value);
                updateSettings = true;
            }
            if (sGadgetID === "lineSizeMagGadget")
            {
                if (jsx.isNull(conf.styleDefaults))
                {
                    conf.styleDefaults = {};
                }

                this.setLineSizeMag(oPropChange.value);
                updateSettings = true;
            }
            if (sGadgetID === "lineLengthMagGadget")
            {
                if (jsx.isNull(conf.styleDefaults))
                {
                    conf.styleDefaults = {};
                }

                this.setLineLengthMag(oPropChange.value);
                updateSettings = true;
            }
            if (sGadgetID === "clusterSpacingFactorGadget")
            {
                if (jsx.isNull(conf.styleDefaults))
                {
                    conf.styleDefaults = {};
                }

                this.setClusterSpacingFactor(oPropChange.value);
                updateSettings = true;
            }
            if (sGadgetID === "curvedLineTypeGadget")
            {
                if (jsx.isNull(conf.styleDefaults))
                {
                    conf.styleDefaults = {};
                }

                this.setCurvedLine(oPropChange.value);
                updateSettings = true;
            }
            if (sGadgetID === "legendOptionTypeGadget")
            {
                if (jsx.isNull(conf.styleDefaults))
                {
                    conf.styleDefaults = {};
                }

                this.setLegendOption(oPropChange.value);
                updateSettings = true;
            }
            if (sGadgetID === "arrowsTypeGadget")
            {
                if (jsx.isNull(conf.styleDefaults))
                {
                    conf.styleDefaults = {};
                }

                this.setArrows(oPropChange.value);
                updateSettings = true;
            }
            //if (sGadgetID === "labelsTypeGadget") {
            //    if (jsx.isNull(conf.styleDefaults)) {
            //        conf.styleDefaults = {};
            //    }

            //    this.setLabels(oPropChange.value);
            //    updateSettings = true;
            //}
            if (sGadgetID === "firstNodeColorGadget")
            {
                if (jsx.isNull(conf.styleDefaults))
                {
                    conf.styleDefaults = {};
                }

                this.setFirstNodeColor(oPropChange.value);
                updateSettings = true;
            }
            if (sGadgetID === "firstLinkColorGadget")
            {
                if (jsx.isNull(conf.styleDefaults))
                {
                    conf.styleDefaults = {};
                }

                this.setFirstLinkColor(oPropChange.value);
                updateSettings = true;
            }
            if (sGadgetID === "destOnlyColorGadget")
            {
                if (jsx.isNull(conf.styleDefaults))
                {
                    conf.styleDefaults = {};
                }

                this.setDestOnlyColor(oPropChange.value);
                updateSettings = true;
            }
            return updateSettings;
        };

        /**
         * Builds the list of selected items
         * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext - The rendering context
         */
        Network2Viz.prototype._buildSelectedItems = function (oTransientRenderingContext) {
            var oViz = this;
            var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
            var oMarkingService = this.getMarkingService();

            function fMarksReadyCallback() {
                oViz.clearSelectedItems();

                var aSelectedItems = oViz.getSelectedItems();

                if(!oViz.isStarted()) {
                    return;
                }
                oMarkingService.traverseDataEdgeMarks(oDataLayout, function (nRow, nCol) {
                    aSelectedItems.set(nRow, nCol);
                    //console.log(nRow,nCol);
                });

                $("circle").removeClass("mark");
                $("line").removeClass("mark");
                $("path").removeClass("mark");
                for(let row of aSelectedItems.keys()){
                    $("line[data-row=`'`"+row+"']").addClass("mark");
                    $("path[data-row='"+row+"']").addClass("mark");
                    $("circle[data-row='"+oViz.getRowMap().get(row).source+"']").addClass("mark");
                    $("circle[data-row='"+oViz.getRowMap().get(row).target+"']").addClass("mark");
                }
                //oViz._render(oTransientRenderingContext);

            }

            // Traverse edge layer marks (if the data layout has columns on the edges - grid views will use this)
            /*var fHighlightMarkedCell = function(edge) {
                var nLayerCount = oDataLayout.getLayerCount(edge);
                for (var nLayer = 0; nLayer < nLayerCount; nLayer++ ) {
                    oMarkingService.traverseLayerMarks(oDataLayout, edge, nLayer, function(nSlice){
                        // Update rendering
                    });
                }
            };*/
            oMarkingService.getUpdatedMarkingSet(oDataLayout, marking.EMarkOperation.MARK_RELATED, fMarksReadyCallback);
            //oMarkingService.getUpdatedMarkingSet(oDataLayout, marking.EMarkOperation.MARK_RELATED, fHighlightMarkedCell);
        };


        /**
         * React to marking service highlight events
         */
        Network2Viz.prototype.onHighlight = function () {
            var oTransientVizContext = this.assertOrCreateVizContext();
            var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
            this._buildSelectedItems(oTransientRenderingContext);
        };

        /**
         * Override _doInitializeComponent in order to subscribe to events
         */
        Network2Viz.prototype._doInitializeComponent = function () {
            Network2Viz.superClass._doInitializeComponent.call(this);

            //this.subscribeToEvent(events.types.DEFAULT_SETTINGS_CHANGED, this._onDefaultSettingsChanged, "**");
            this.subscribeToEvent(events.types.INTERACTION_HIGHLIGHT, this.onHighlight, this.getViewName() + "." + events.types.INTERACTION_HIGHLIGHT);

            //this.initializeLegendAndVizContainer();
        };


        /**
         * Factory method declared in the plugin configuration
         * @param {string} sID Component ID for the visualization
         * @param {string=} sDisplayName Component display name
         * @param {string=} sOrigin Component host identifier
         * @param {string=} sVersion
         * @returns {module:com-company-network2Viz/network2Viz.Network2Viz}
         * @memberof module:com-company-network2Viz/network2Viz
         */
        network2.createClientComponent = function (sID, sDisplayName, sOrigin) {
            // Argument validation done by base class
            return new Network2Viz(sID, sDisplayName, sOrigin, Network2Viz.VERSION);
        };

        return network2;
    });