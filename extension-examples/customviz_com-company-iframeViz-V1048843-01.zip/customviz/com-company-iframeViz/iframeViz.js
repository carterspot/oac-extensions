define( ['jquery',
   'obitech-framework/jsx',
   'obitech-application/extendable-ui-definitions',
   'obitech-report/visualization',
   'obitech-report/gadgetdialog',
   'obitech-application/gadgets',
   'obitech-appservices/logger',
   'obitech-framework/actioncontext',
   'ojL10n!com-company-iframeViz/nls/messages',
   'obitech-framework/messageformat',
   'skin!css!com-company-iframeViz/iframeVizstyles'],
   function (
      $,
      jsx,
      euidef,
      viz,
      gadgetdialog,
      gadgets,
      logger,
      actioncontext,
      messages
   ) {
      "use strict";

      var MODULE_NAME = 'com-company-IFrameViz/IFrameViz';

      //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
      jsx.assertAllNotNullExceptLastN( arguments, "IFrameViz.js arguments", 2 );

      const _logger = new logger.Logger( MODULE_NAME );

      // The version of our Plugin
      const VERSION = "1.0.0";

      // source type enum: src or srcdoc
      const eSourceType = {
         SRC: 'SRC',
         SRCDOC: 'SRCDOC'
      }

      /**
       * The implementation of the IFrameViz visualization.
       *
       * @constructor
       * @param {string} sID
       * @param {string} sDisplayName
       * @param {string} sOrigin
       * @param {string} sVersion
       * @extends {module:obitech-report/visualization.Visualization}
       * @memberof module:com-company-IFrameViz/IFrameViz#
       */
      class IFrameViz extends viz.Visualization {
         constructor( sID, sDisplayName, sOrigin, sVersion ) {
            super( sID, sDisplayName, sOrigin, sVersion ); // Argument validation done by base class
         }

      /**
        * Called whenever this visualization needs to update.
        */
         render() {
            // Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
            // but may be used to render.
            try {
               this._renderTheIframeOnly()
            }
            finally {
               this._setIsRendered( true );
            }
         }

         /**
          * Get the version of a viz type's own view config setting. Note this is different from the global view config version.
          * @public
          * @returns {string} the version of this viz type's own view config setting.
          */
         getCurrentViewConfigVersion() {
            return "1.0.0";
         }

         _addVizSpecificPropsDialog( oTabbedPanelsGadgetInfo ) {
            super._addVizSpecificPropsDialog( oTabbedPanelsGadgetInfo );
            var oGadgetFactory = this.getGadgetFactory();
            var oViewConfig = this.getVizSpecificViewConfigSettingJSON();

            var oGeneralPanel = gadgetdialog.forcePanelByID( oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_GENERAL );
            oGeneralPanel.setBodyCSSClass( "bi_gadgets_no_cell_separator" );
            var nOrder = euidef.GD_FIELD_ORDER_GENERAL_VIZ_SPECIFIC;

            {
               const oSourceControlProps = new gadgets.GadgetValueProperties (euidef.GadgetTypeIDs.TEXT_SWITCHER,
                  jsx.isNull( oViewConfig?.sourceType ) ? 'SRC' : oViewConfig.sourceType)

               nOrder += 1
               const aSourceControlOptions = [
                 new gadgets.OptionInfo(
                   eSourceType.SRC,
                   messages.FORM_LABEL_SOURCE_TYPE_SRC
                 ),
                 new gadgets.OptionInfo(
                   eSourceType.SRCDOC,
                   messages.FORM_LABEL_SOURCE_TYPE_SRCDOC
                 )
               ];
               const oSourceControlGadgetInfo =
                 new gadgets.TextSwitcherGadgetInfo(
                   "iframe_source_type",
                   messages.FORM_LABEL_SOURCE,
                   messages.FORM_LABEL_SOURCE,
                   oSourceControlProps,
                   nOrder,
                   null,
                   aSourceControlOptions
                 );
                 oSourceControlGadgetInfo.setGroupName("iframe_props");

               oGeneralPanel.addChild(oSourceControlGadgetInfo);
             }

            var oGadgetValueProperties = new gadgets.GadgetValueProperties( euidef.GadgetTypeIDs.TEXT_AREA, oViewConfig?.frameSrc );
            var sGadgetId = "iframe_JSON";
            nOrder += 1;
            var oGadgetInfo = oGadgetFactory.createGadgetInfo( sGadgetId, messages.EMBED_SRC, messages.EMBED_SRC_VALUE,oGadgetValueProperties, nOrder );
            oGadgetInfo.setGroupName("iframe_props")
            oGeneralPanel.addChild( oGadgetInfo );
            {
               const isChecked = jsx.isNull( oViewConfig?.allowScripts ) ? false : oViewConfig.allowScripts
               const oGadgetAllowScriptsCheckbox = new gadgets.CheckboxGadgetValueProperties( euidef.GadgetTypeIDs.TEXT_TOGGLE, "iframe_allow_scripts", isChecked )
               nOrder += 1
               const oGadgetAllowScriptsCheckboxInfo = new gadgets.TextToggleGadgetInfo( "iframe_allow_scripts", messages.ALLOW_SCRIPTS, null, oGadgetAllowScriptsCheckbox, nOrder )
               oGeneralPanel.addChild( oGadgetAllowScriptsCheckboxInfo )
            }

            {
               const isChecked = jsx.isNull( oViewConfig?.allowForms ) ? false : oViewConfig.allowForms
               const oGadgetAllowFormsCheckbox = new gadgets.CheckboxGadgetValueProperties( euidef.GadgetTypeIDs.TEXT_TOGGLE, "iframe_allow_forms", isChecked )
               nOrder += 1
               const oGadgetAllowFormsCheckboxInfo = new gadgets.TextToggleGadgetInfo( "iframe_allow_forms", messages.ALLOW_FORMS, null, oGadgetAllowFormsCheckbox, nOrder )
               oGeneralPanel.addChild( oGadgetAllowFormsCheckboxInfo )
            }

         }

         _handlePropChange( sGadgetID, oPropChange, oViewSettings, oActionContext ) {
            jsx.assertString( sGadgetID, 'sGadgetID' );
            jsx.assertObject( oPropChange, 'oPropChange' );
            jsx.assertObject( oViewSettings, 'oViewSettings' );
            jsx.assertInstanceOf( oActionContext, actioncontext.ActionContext, "oActionContext", "actioncontext.ActionContext" );

            var bUpdateSettings = super._handlePropChange( sGadgetID, oPropChange, oViewSettings, oActionContext );
            var oConf = this.forceVizSpecificViewConfig( oViewSettings );

            if ( !jsx.isNull( oPropChange ) ) {
               switch ( sGadgetID ) {
                  case "iframe_JSON":
                     if ( !jsx.isNull( oPropChange.value ) ) {
                        this.setVizSpecificViewConfigSetting( oViewSettings, "frameSrc", oPropChange.value );
                        bUpdateSettings = true;
                     }
                     break;
                  case "iframe_allow_scripts":
                     this.setVizSpecificViewConfigSetting( oViewSettings, "allowScripts", oPropChange.checked )
                     bUpdateSettings = true;
                     break;
                  case "iframe_allow_forms":
                     this.setVizSpecificViewConfigSetting( oViewSettings, "allowForms", oPropChange.checked )
                     bUpdateSettings = true;
                     break;
                  case "iframe_source_type":
                      this.setVizSpecificViewConfigSetting(oViewSettings, "sourceType", oPropChange.value)
                      bUpdateSettings = true
                      break

               }
            }

            // Do we need to call render?
            return bUpdateSettings;
         }

         /**
          * @inheritdoc
         */
         _onSettingsChanged( oClientEvent, oChanges, oOldSettings ) {
            super._onSettingsChanged( oClientEvent, oChanges, oOldSettings );
            this.render();
         };

         _renderTheIframeOnly() {
            const elContainer = this.getContainerElem()
            const oViewConfig = this.getVizSpecificViewConfigSettingJSON() || {}
            if (this.$content != null) {
               this.$content.remove()
            }
            this.$content = $( '<div class="bitechdev-card-container"></div>' )
            $( elContainer ).append( this.$content )
            if ( oViewConfig['frameSrc'] == undefined ) {
               this.$content.html( `<p>${messages.NO_SRC_DEFINED}</p>` )
            } else {
               const sFrameSrc = oViewConfig['frameSrc']
               const eType = jsx.isNull( oViewConfig?.sourceType ) ? 'SRC' : oViewConfig.sourceType
               // check if it is a src or srcdoc.
               // We will assume anything that doesn't start with http or https is srcdoc
               let sSource = ""
               if (this._isHttpOrHttps(sFrameSrc)) {
                  sSource = `src=${sFrameSrc}`
               } else {
                  sSource = `srcdoc=${sFrameSrc}`
               }
               let sSandboxPermissions = ""
               // TODO: do we need to disable allowScripts if it is srcdoc
               if ( !jsx.isNull( oViewConfig['allowScripts'] ) && oViewConfig['allowScripts'] == true ) {
                  sSandboxPermissions = "allow-scripts"
               }
               if ( !jsx.isNull( oViewConfig['allowForms'] ) && oViewConfig['allowForms'] == true ) {
                  sSandboxPermissions += ' allow-forms'
               }
               switch (eType) {
                  case eSourceType.SRCDOC:
                     $(`<iframe id="eid_iframe_deleteme" sandbox="${sSandboxPermissions}" frameborder=0 style="width: 100vw;" height="100%">`)
                  .attr('srcdoc',sFrameSrc).appendTo(this.$content)
                     break
                  case eSourceType.SRC:
                     this.$content.html( `<iframe sandbox="${sSandboxPermissions}" frameborder=0 style="width: 100vw;" height="100%" ${sSource}/>` )
                     break
               }
            }
         }

        _isHttpOrHttps(sUrl) {
            return sUrl.startsWith('http://') || sUrl.startsWith('https://');
        }
      }


      /**
       * Factory method declared in the plugin configuration
       * @param {string} sID Component ID for the visualization
       * @param {string=} sDisplayName Component display name
       * @param {string=} sOrigin Component host identifier
       * @param {string=} sVersion
       * @returns {module:bitech-dev-iFrameViz/iFrameViz.IFrameViz}
       * @memberof module:bitech-dev-iFrameViz/iFrameViz
       */
      function createClientComponent( sID, sDisplayName, sOrigin ) {
      // Argument validation done by base class
         return new IFrameViz( sID, sDisplayName, sOrigin, VERSION );
      };

      function log( msg ) {
         console.log( `${IFrameViz.name}: ${msg}` )
      }

      return {
         createClientComponent: createClientComponent
      };
   } );
