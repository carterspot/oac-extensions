define({
   "ALLOW_FORMS":"Allow Forms",
   "ALLOW_SCRIPTS":"Allow Scripts",
   "EMBED_SRC":"Embed",
   "EMBED_SRC_VALUE":"Enter the value for 'src' or 'srcdoc' parameter",
   "FORM_LABEL_SOURCE":"iframe source",
   "FORM_LABEL_SOURCE_TYPE_SRCDOC":"SRCDOC",
   "FORM_LABEL_SOURCE_TYPE_SRC":"SRC",
   "IFRAMEVIZ_DISPLAY_NAME": "iframe",
   "IFRAMEVIZ_SHORT_DISPLAY_NAME": "iframe",
   "NO_SRC_DEFINED": "There is no 'src' or 'srcdoc' defined"
});
