define(['jquery',
        'obitech-framework/jsx',
        'obitech-report/datavisualization',
        'obitech-reportservices/datamodelshapes',
		'obitech-reportservices/data',
		'obitech-application/gadgets',
		'obitech-report/gadgetdialog',
		'obitech-application/extendable-ui-definitions',		
        'obitech-reportservices/events',
		'obitech-reportservices/interactionservice',
		'obitech-reportservices/markingservice',		
        'obitech-appservices/logger',
        'ojL10n!com-company-collapsibleTreeViz/nls/messages',
		'd3js',
        'obitech-framework/messageformat',
        'skin!css!com-company-collapsibleTreeViz/collapsibleTreeVizstyles'],
        function($,
                 jsx,
                 dataviz,
                 datamodelshapes,
				 data,
				 gadgets,
				 gadgetdialog,
				 euidef,
                 events,
				 interactions,
				 marking,
                 logger,
                 messages,d3) {
   "use strict";

   var MODULE_NAME = 'com-company-collapsibleTreeViz/collapsibleTreeViz';

   //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   jsx.assertAllNotNullExceptLastN(arguments, "collapsibleTreeViz.js arguments", 2);

   var _logger = new logger.Logger(MODULE_NAME);
   var my_Data;
   var resize = false;
   var vizs = [];
   // The version of our Plugin
   CollapsibleTreeViz.VERSION = "1.0.0";

   /**
    * The implementation of the heirarchyViz visualization.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @extends {module:obitech-report/visualization.Visualization}
    * @memberof module:com-company-heirarchyViz/heirarchyViz#
    */
	

   function CollapsibleTreeViz(sID, sDisplayName, sOrigin, sVersion) {
      // Argument validation done by base class
      CollapsibleTreeViz.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);
	  
	 var aSelectedItems = [];
	  
	 this.getSelectedItems = function(){
	    return aSelectedItems;
	 };
	  
 	 this.clearSelectedItems = function(){
	    aSelectedItems = [];
	 }; 
	 
   };
   jsx.extend(CollapsibleTreeViz, dataviz.DataVisualization);
   /**
    * Called whenever new data is ready and this visualization needs to update.
    * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
    */

	function fNum(num){
		num = Number(num);
		if (num % 1 != 0){
		 if (Math.abs(num) <1) 
			num = Math.round(num*1000)/1000;
		 else 
			num = Math.round(num*100)/100;
		}
		return num.toLocaleString();
	}

	
	CollapsibleTreeViz.prototype._generateData = function (oDataLayout,oDataModel) {
	var myArray = [];
	//var valueArray = [];
	//using the row expander code
	//	var oDataModel = this.getRootDataModel();
		if (!oDataModel || !oDataLayout) {
			return;
		}

		var aAllMeasures = oDataModel.getColumnIDsIn(datamodelshapes.Physical.DATA);
		var nMeasures = aAllMeasures.length;

		var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
		var nRowLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
		var nCols = oDataLayout.getEdgeExtent(datamodelshapes.Physical.COLUMN);
		var nColLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.COLUMN);
		var measureName = oDataLayout.getValue(datamodelshapes.Physical.COLUMN, 0, 0);
		for(var i=0;i<nRowLayerCount;i++){
			var array = [];
			myArray.push(array);
		}
		var children_array = [];
		var metric_names = [];
		for(var m=0;m<nMeasures;m++){
			metric_names.push(oDataLayout.getValue(datamodelshapes.Physical.COLUMN, 0, m, false));
		}

		var nRow;
		var nMeasCnt = 0;
		var current1;
		for (nRow = 0; nRow< Math.max(nRows,1); nRow++) {
			var nMeasuresLayer = 1;		
			for (var nCol = 0; nCol < (nRowLayerCount); nCol++) {			
			var column_value = oDataLayout.getValue(datamodelshapes.Physical.ROW, nCol, nRow, false);

			if(column_value && column_value !=""){
				var obj = null;
				if(obj === null){
					//logic to build children array
						if(children_array.length == 0){
							var obj ={
							"name" : column_value,
							"children" : [],
							}
							children_array.push(obj);
							myArray[0].push(column_value);
						}else{
							var obj ={
							"name" : column_value,
							"children" : []							
							}
							if(nCol==nRowLayerCount-1){
								obj["row_number"] = nMeasCnt;
								obj["col_number"] = 0;
								nMeasCnt++;
							}
						if(nCol == 0){
							if(myArray[0].indexOf(column_value) == -1){
								children_array.push(obj);
								myArray[0].push(column_value);
							   for(var i=nCol+1;i<nRowLayerCount;i++){
								   myArray[i] = [];
							   }
							}
						}else{
									if(nCol == 1){
										if(myArray[1].indexOf(column_value) == -1){
										 children_array[children_array.length - 1]["children"].push(obj);
										 myArray[1].push(column_value);
											if(nRowLayerCount > 2){
											   for(var i=nCol+1;i<nRowLayerCount;i++){
												   myArray[i] = [];
											   }												
											}
										} 
									}else{
											if(nCol == 2){
												if(myArray[2].indexOf(column_value) == -1){
												children_array[children_array.length - 1]["children"][myArray[1].length-1]["children"].push(obj);
												myArray[2].push(column_value);
												if(nRowLayerCount > 3){
												   for(var i=nCol+1;i<nRowLayerCount;i++){
													   myArray[i] = [];
												   }													
												}
											 }
											}else if(nCol == 3){
												if(myArray[3].indexOf(column_value) == -1){
												children_array[children_array.length - 1]["children"][myArray[1].length-1]["children"][myArray[2].length-1]["children"].push(obj);
												myArray[3].push(column_value);
												if(nRowLayerCount > 4){
												   for(var i=nCol+1;i<nRowLayerCount;i++){
													   myArray[i] = [];
												   }													
												}												
											  }
											}else if(nCol == 4){
												if(myArray[4].indexOf(column_value) == -1){
												children_array[children_array.length - 1]["children"][myArray[1].length-1]["children"][myArray[2].length - 1]["children"][myArray[3].length-1]["children"].push(obj);		
												myArray[4].push(column_value);
													if(nRowLayerCount > 4){
													   for(var i=nCol+1;i<nRowLayerCount;i++){
														   myArray[i] = [];
													   }														
													}
												}
											}else if(nCol == 5){
												if(myArray[5].indexOf(column_value) == -1){
													children_array[children_array.length - 1]["children"][myArray[1].length-1]["children"][myArray[2].length - 1]["children"][myArray[3].length - 1]["children"][myArray[4].length -1]["children"].push(obj);
													myArray[5].push(column_value);																
												}
											}
										}
							}
				}
			}
		}	
	  }
		if(measureName != ''){
			var obj = {
				"name": fNum(oDataLayout.getValue(datamodelshapes.Physical.DATA, nRow, 0)),
				"children": []
			}
			var sizeArray = [];
			var x = children_array;
			for(var i=0;i < nRowLayerCount;i++){
				sizeArray.push(x.length);
				x = x[sizeArray[sizeArray.length-1] -1]["children"];
			}
			var insert_position = children_array;
			for(var i=0;i< nRowLayerCount-1;i++){
				insert_position = insert_position[sizeArray[i]-1]["children"];
			}
			var x = String(insert_position[sizeArray[sizeArray.length -1]-1]["name"]) + '\xa0\xa0' + fNum(oDataLayout.getValue(datamodelshapes.Physical.DATA, nRow, 0)); 
			insert_position[sizeArray[sizeArray.length -1]-1]["name"] = x;
		}
	}
		return children_array;
}
	
   CollapsibleTreeViz.prototype.render = function(oTransientRenderingContext) {
      try {
         // Note: all events will be received after initialize and start complete.  We may get other events
         // such as 'resize' before the render, i.e. this might not be the first event.
         var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
		 var oDataModel = this.getRootDataModel();
			if (!oDataModel || !oDataLayout) {
				return;
			}
		 //var oMarkingService = this.getMarkingService(); 
		 var json_data = this._generateData(oDataLayout,oDataModel);
		 var str_tb_replaced = ',"children":[]';
		 var json_data1 = JSON.stringify(json_data).replace(str_tb_replaced,'');
		 var elContainer = this.getContainerElem();
		 var elString = JSON.stringify(elContainer);
		 if(my_Data == json_data1){
			 if(!resize){
						 if(vizs.indexOf(elString) == -1){
							vizs.push(elString);
						}else{
							return;
						}
			 }else{
				 resize = false;
			 }			
		 }else{
			 my_Data = json_data1;
		 }		 
		 var _self = this;
		 while(json_data1.indexOf(str_tb_replaced) != -1){
			 json_data1 = json_data1.replace(str_tb_replaced,'');
		 }
		 var json_obj = JSON.parse(json_data1);
		 var flare = {
			 "name" : "All",
			 "children": json_obj
		 }
			
			$(elContainer).html('');
			var margin = {top: 20, right: 30, bottom: 20, left: 30},
				width = $(elContainer).width() - margin.right - margin.left,
				height = $(elContainer).height() - margin.top - margin.bottom;

			var i = 0,
				duration = 750,
				root;

			var tree = d3.layout.tree()
				.size([height, width]);

			var diagonal = d3.svg.diagonal()
				.projection(function(d) { return [d.y, d.x]; });
            
			
			var svg = d3.select(elContainer).append("svg")
				.attr('class', 'svgcollapse')
				.attr("width", width + margin.right + margin.left)
				.attr("height", height + margin.top + margin.bottom)
			    .append("g")
				.attr("transform", "translate(" + margin.left + "," + margin.top + ")");		 

				
         // Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
         // but may be used to render.
		 
  
		  root = flare;
		  root.x0 = height / 2;
		  root.y0 = 0;

		  function collapse(d) {
			if (d.children) {
			  d._children = d.children;
			  d._children.forEach(collapse);
			  d.children = null;
			}
		  }

		  root.children.forEach(collapse);
		  update(root);


		d3.select(self.frameElement).style("height", "800px");

		function update(source) {

		  // Compute the new tree layout.
		  var nodes = tree.nodes(root).reverse(),
			  links = tree.links(nodes);

		  // Normalize for fixed-depth.
		  nodes.forEach(function(d) { d.y = d.depth * 180; });

		  // Update the nodes…
		  var node = svg.selectAll("g.node")
			  .data(nodes, function(d) { return d.id || (d.id = ++i); });

		  // Enter any new nodes at the parent's previous position.
		  var nodeEnter = node.enter().append("g")
			  .attr("class", "node")
			  .attr("transform", function(d) { return "translate(" + source.y0 + "," + source.x0 + ")"; })
			  .on("click", click);

		  nodeEnter.append("circle")
			  .attr("r", 1e-6)
			  .style("fill", function(d) { return d._children ? "lightsteelblue" : "#fff"; });
			 
		  nodeEnter.append("text")
			  .attr("x", function(d) { return d.children || d._children ? -10 : 10; })
			  .attr("dy", ".35em")
			  .attr("text-anchor", function(d) { return d.children || d._children ? "end" : "start"; })
			  .text(function(d) { return d.name; })
			  .style("fill-opacity", 1e-6);

		  // Transition nodes to their new position.
		  var nodeUpdate = node.transition()
			  .duration(duration)
			  .attr("transform", function(d) { return "translate(" + d.y + "," + d.x + ")"; });

		  nodeUpdate.select("circle")
			  .attr("r", 4.5)
			  .style("fill", function(d) { return d._children ? "lightsteelblue" : "#fff"; });

		  nodeUpdate.select("text")
			  .style("fill-opacity", 1);

		  // Transition exiting nodes to the parent's new position.
		  var nodeExit = node.exit().transition()
			  .duration(duration)
			  .attr("transform", function(d) { return "translate(" + source.y + "," + source.x + ")"; })
			  .remove();

		  nodeExit.select("circle")
			  .attr("r", 1e-6);

		  nodeExit.select("text")
			  .style("fill-opacity", 1e-6);

		  // Update the links…
		  var link = svg.selectAll("path.link")
			  .data(links, function(d) { return d.target.id; });

		  // Enter any new links at the parent's previous position.
		  link.enter().insert("path", "g")
			  .attr("class", "link")
			  .attr("d", function(d) {
				var o = {x: source.x0, y: source.y0};
				return diagonal({source: o, target: o});
			  });

		  // Transition links to their new position.
		  link.transition()
			  .duration(duration)
			  .attr("d", diagonal);

		  // Transition exiting nodes to the parent's new position.
		  link.exit().transition()
			  .duration(duration)
			  .attr("d", function(d) {
				var o = {x: source.x, y: source.y};
				return diagonal({source: o, target: o});
			  })
			  .remove();

		  // Stash the old positions for transition.
		  nodes.forEach(function(d) {
			d.x0 = d.x;
			d.y0 = d.y;
		  });
		}

		// Toggle children on click.
		//var lastClickD = null;
		function click(d) {
		  if (d.children) {
			d._children = d.children;
			d.children = null;
			var oMarkingService = _self.getMarkingService();
		    oMarkingService.clearMarksForDataLayout(oDataLayout);
		    _self._publishMarkEvent(oDataLayout);				 				
			d3.selectAll("circle")
				.style("stroke", "steelblue")
				.style("stroke-width", "1.5px");
				
			
		  } else { 
			d.children = d._children;
			d._children = null;
			

		  if(typeof d.children == "undefined" || !(d.children)){
			  var oMarkingService = _self.getMarkingService();
			  oMarkingService.clearMarksForDataLayout(oDataLayout);
			  if(typeof d["row_number"] != "undefined" && typeof d["col_number"] != undefined){
				  oMarkingService.setMark(oDataLayout, datamodelshapes.Physical.DATA, d["row_number"], d["col_number"]);
			  }
			    _self._publishMarkEvent(oDataLayout);			
				d3.selectAll("circle")
					 .style("stroke", "steelblue")
					 .style("stroke-width", "1.5px");
				
				d3.select(this).select("circle")
					 .style("stroke", "black")
					 .style("stroke-width", "2.5px");
					 
		  }else{
			  //do a BFS for all the child nodes and add it to the array 
				d3.selectAll("circle")
					 .style("stroke", "steelblue")
					 .style("stroke-width", "1.5px");
				
				d3.select(this).select("circle")
					 .style("stroke", "black")
					 .style("stroke-width", "2.5px");			  
			  var leafs = [];
			  var queue = [];
			  if(typeof d.children != "undefined" && (d.children)){
				  for(var i=0;i<d.children.length;i++){
					  queue.push(d.children[i]);
				  }				  
			  }
			  while(queue.length != 0 ){
				  var top = queue[0];
				  if((typeof top._children == "undefined" || top._children == null) && (typeof top.children == "undefined" || top.children == null)){
					  //this is a leaf node						
					  var obj = {};
					  obj["row"] = top["row_number"];
					  obj["col"] = top["col_number"];
					  if(typeof obj["row"] != "undefined" && typeof obj["col"] != "undefined"){
						leafs.push(obj);						  
					  }
				  }else{
					  //this is not a leaf node
					  if(top._children != null){
						  for(var i=0;i<top._children.length;i++){
							  queue.push(top._children[i]);
						  }						  
					  }
					  if(top.children != null){
						  for(var i=0;i<top.children.length;i++){
							  queue.push(top.children[i]);
						  }						  						  
					  }
				  }
				  queue.shift();
			  }
			//traverse all the leafs array and call publish mark event
			 var oMarkingService = _self.getMarkingService();
			 oMarkingService.clearMarksForDataLayout(oDataLayout);
			 for(var i=0;i<leafs.length;i++){
				oMarkingService.setMark(oDataLayout, datamodelshapes.Physical.DATA, leafs[i]["row"], leafs[i]["col"]);
			 }
			 _self._publishMarkEvent(oDataLayout);				 
		  }
			
		}
		  update(d);
		 
		  d3.event.stopPropagation();
	}	
  
    }	  
      finally {
         this._setIsRendered(true);
      }
    };

	
	CollapsibleTreeViz.prototype.resizeVisualization = function(oVizDimensions, oTransientVizContext){
		resize = false;
		var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
		this.render(oTransientRenderingContext);
	};
	
	CollapsibleTreeViz.prototype._publishMarkEvent = function (oDataLayout, eMarkContext) {
	   try {
		  // Create the marking event
		  var markingEvent = new interactions.MarkingEvent(this.getID(), this.getViewName(), oDataLayout, null, eMarkContext);
		  var eventRouter = this.getEventRouter();
		  if (eventRouter) {
			 // Publish the event to listeners
			 eventRouter.publish(markingEvent);
		  }
	   }
	   catch (e) {
		  console.log("Error during mark", e);
	   }
	};
	CollapsibleTreeViz.prototype._buildSelectedItems = function(oTransientRenderingContext){
	   var oViz = this;
	   var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
	   var oMarkingService = this.getMarkingService();
		
	   function fMarksReadyCallback() {
		  oViz.clearSelectedItems();
		  var aSelectedItems = oViz.getSelectedItems();
		   
		  if(!oViz.isStarted()) {
			 return;
		  }
		  oMarkingService.traverseDataEdgeMarks(oDataLayout, function (nRow, nCol) {
			 aSelectedItems.push(nRow + ':' + nCol);
		  });
		   
		  oViz.render(oTransientRenderingContext);         
	   }
		
	   oMarkingService.getUpdatedMarkingSet(oDataLayout, marking.EMarkOperation.MARK_RELATED, fMarksReadyCallback);
	};	
	
	CollapsibleTreeViz.prototype.onHighlight = function(){
		var oTransientVizContext = this.assertOrCreateVizContext();
		var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
		this._buildSelectedItems(oTransientRenderingContext);
	};


	CollapsibleTreeViz.prototype._addVizSpecificMenuOptions = function(oTransientVizContext, sMenuType, aResults, contextmenu, evtParams, oTransientRenderingContext){
		if(!oTransientRenderingContext){
						oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
		}

		if (sMenuType === euidef.CM_TYPE_VIZ_PROPS) {
						// Set up the column context for the last column in the ROWS bucket
						var oColumnContext = this.getDrillPathColumnContext(oTransientVizContext, datamodelshapes.Logical.ROW);

						// Set up events
						if(!this.isViewOnlyLimit()){
										this._addFilterMenuOption(oTransientVizContext, aResults, null, null, oTransientRenderingContext);
										this._addRemoveSelectedMenuOption(oTransientVizContext, aResults, null, null,oTransientRenderingContext);
										//this._addDrillMenuOption(oTransientVizContext, aResults, null, null, oColumnContext);
										//this._addLateralDrillMenuOption(oTransientVizContext, aResults);
										this._addActionLinkMenuOption(oTransientVizContext,aResults,null,null,oTransientRenderingContext);
										this._addColorMenuOption(oTransientVizContext, aResults, oTransientRenderingContext);
						}
		}
	};

	
	/*CollapsibleTreeViz.prototype._doInitializeComponent = function() {
			CollapsibleTreeViz.superClass._doInitializeComponent.call(this);  
			this.subscribeToEvent(events.types.INTERACTION_HIGHLIGHT, this.onHighlight, this.getViewName() + "." + events.types.INTERACTION_HIGHLIGHT)
	};*/
	

   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the visualization
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {string=} sVersion 
    * @returns {module:com-company-heirarchyViz/heirarchyViz.HeirarchyViz}
    * @memberof module:com-company-heirarchyViz/heirarchyViz
    */
   function createClientComponent(sID, sDisplayName, sOrigin) {
     // Argument validation done by base class
      return new CollapsibleTreeViz(sID, sDisplayName, sOrigin, CollapsibleTreeViz.VERSION);
   };

   return {
      createClientComponent : createClientComponent
   };
});