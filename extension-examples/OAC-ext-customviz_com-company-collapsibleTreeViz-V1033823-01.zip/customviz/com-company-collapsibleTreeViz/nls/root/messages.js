define({
    "COLLAPSIBLETREEVIZ_DISPLAY_NAME": "CollapsibleTreeViz Plugin",
    "COLLAPSIBLETREEVIZ_SHORT_DISPLAY_NAME": "CollapsibleTreeViz Plugin",
    "COLLAPSIBLETREEVIZ_CATEGORY":"CollapsibleTreeViz Plugin",
    "COLLAPSIBLETREEVIZ_ROW_LABEL":"CollapsibleTreeViz Plugin Row",
    "COLLAPSIBLETREEVIZ_ITEM_SIZE":"Item Size",
    "TEXT_MESSAGE": "Hello!  This is the {0} visualization and I have {1} rows of data."

});