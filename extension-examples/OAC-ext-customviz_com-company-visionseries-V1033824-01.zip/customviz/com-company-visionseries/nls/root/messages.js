define({
    "VISIONSERIES_DISPLAY_NAME": "Vision Viz Plugin",
    "VISIONSERIES_SHORT_DISPLAY_NAME": "Vision Plugin",
    "VISIONSERIES_ROW_LABEL":"Image Location",
    "VISIONSERIES_DETAIL":"Vertices",
    "VISIONSERIES_COLOR":"Color",
    "VISIONSERIES_GLYPH":"Tooltip",
    "TEXT_MESSAGE": "Hello!  This is the {0} visualization and I have {1} rows of data."
});