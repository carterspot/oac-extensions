define(['obitech-framework/jsx',
        'obitech-reportservices/datamodelshapes',
        'obitech-viz/genericDataModelHandler',
        'obitech-report/vizdatamodelsmanager'],
        function(jsx, 
                 datamodelshapes,
                 genericDataModelHandler,
                 vdm) {
   "use strict";
   var visionSeriesDataModelHandler = {};

   /**
    * @class The data model handler.
    * @constructor
    * @param {object=} oConfig
    * @param {string=} sId
    * @param {string=} sDisplayName
    * @param {string=} sOrigin
    * @param {string=} sVersion
    * @memberof module:com-company-visionseries/VisionSeriesDataModelHandler#
    * @extends module:obitech-viz/vizDataModelHandlerBase#VisualizationHandlerBase
    */
   function VisionSeriesDataModelHandler(oConfig, sId, sDisplayName, sOrigin, sVersion)
   {
      VisionSeriesDataModelHandler.baseConstructor.call(this, oConfig, sId, sDisplayName, sOrigin, sVersion);
   }
   jsx.extend(VisionSeriesDataModelHandler, genericDataModelHandler.GenericDataModelHandler);
   visionSeriesDataModelHandler.VisionSeriesDataModelHandler = VisionSeriesDataModelHandler;

   /**
    * @returns module:obitech-report/vizdatamodelsmanager#Mapper
    */
   VisionSeriesDataModelHandler.prototype.getLogicalMapper = function () {
      var oRow = new datamodelshapes.PhysicalPlacement(datamodelshapes.Physical.ROW);

      var oMapper = new vdm.Mapper();

      oMapper.addCategoricalMapping(datamodelshapes.Logical.SIZE,   null); // don't place
      oMapper.addCategoricalMapping(datamodelshapes.Logical.COLOR,  oRow); // color -> row
      oMapper.addCategoricalMapping(datamodelshapes.Logical.CATEGORY,  oRow); // det -> row
      //oMapper.addCategoricalMapping(datamodelshapes.Logical.GLYPH,  oRow); // gylph -> row
      oMapper.addCategoricalMapping(datamodelshapes.Logical.ROW, oRow); // row -> row
      oMapper.addCategoricalMapping(datamodelshapes.Logical.TOOLTIP, oRow); // row -> row

      oMapper.addMeasureMapping(datamodelshapes.Logical.SIZE,   oRow); // Don't place
      oMapper.addMeasureMapping(datamodelshapes.Logical.COLOR,  oRow); // Don't place
      oMapper.addMeasureMapping(datamodelshapes.Logical.CATEGORY,  oRow); // det -> row
      //oMapper.addMeasureMapping(datamodelshapes.Logical.GLYPH,  null); // gylph -> row
      oMapper.addMeasureMapping(datamodelshapes.Logical.TOOLTIP,  oRow); // gylph -> row

      // where to place physical measure label in case no measure layer is present in logical
      oMapper.setDefaultPhysicalMeasureLabel(datamodelshapes.Physical.COLUMN, this.getMeasureLabelConfig().visibility);

      return oMapper;
   };

   /**
    * Returns the handler
    *@param {String} extensionPointName
    *@param {Object} config
    */
   visionSeriesDataModelHandler.getHandler = function(extensionPointName, config) {
      return new VisionSeriesDataModelHandler(config, extensionPointName);
   };

   return visionSeriesDataModelHandler;
});
