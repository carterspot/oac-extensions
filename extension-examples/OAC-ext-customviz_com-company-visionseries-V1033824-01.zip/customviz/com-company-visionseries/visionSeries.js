define(['jquery',
        'obitech-framework/jsx',
        'obitech-report/datavisualization',
        'obitech-application/gadgets',
        'obitech-report/gadgetdialog',
        'obitech-application/extendable-ui-definitions',
        'obitech-reportservices/datamodelshapes',
        'obitech-reportservices/events',
        'obitech-appservices/logger',
        'ojL10n!com-company-visionseries/nls/messages',
        'd3v6js',
        'obitech-reportservices/data',
        'obitech-framework/messageformat',
        'skin!css!com-company-visionseries/visionSeriesstyles'],
        function($,
                 jsx,
                 dataviz,
                 gadgets,
                 gadgetdialog,
                 euidef,
                 datamodelshapes,
                 events,
                 logger,
                 messages,
                 d3,
                 data) {
   "use strict";

   var MODULE_NAME = 'com-company-visionseries/visionSeries';

   //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   jsx.assertAllNotNullExceptLastN(arguments, "visionSeries.js arguments", 2);

   var _logger = new logger.Logger(MODULE_NAME);

   // The version of our Plugin
   VisionSeries.VERSION = "1.0.0";

   /**
    * The implementation of the visionSeries visualization.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @extends {module:obitech-report/visualization.Visualization}
    * @memberof module:com-company-visionseries/visionSeries#
    */
   function VisionSeries(sID, sDisplayName, sOrigin, sVersion) {
      // Argument validation done by base class
      VisionSeries.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);

       var tabInfo = '';
       this.Config = {
           boxColor: ''
       }
       this.loadConfig = function () {
           var conf = this.getSettings().getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
           if (conf.boxColor) this.Config.boxColor=conf.boxColor;
       }

       this._saveSettings = function () {
           this.getSettings().setViewConfigJSON(dataviz.SettingsNS.CHART, this.Config);
       };
       this.getBoxColor = function(){
           return(this.Config.boxColor);
       };
       this.setBoxColor = function (o){
           this.Config.boxColor = o;
           this._saveSettings();
       };
       this.getTabInfo = function () {
           return (tabInfo);
       };

       this.setTabInfo = function (o) {
           tabInfo = o;
       };
   };
   jsx.extend(VisionSeries, dataviz.DataVisualization);
   VisionSeries.prototype._generateData = function(oDataLayout, oTransientRenderingContext){
        var oDataModel = this.getRootDataModel();
        if(!oDataModel || !oDataLayout){
            return;
        }
        var outputObj = [];
        var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
        var nRowLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
        var oDataLayoutHelper = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT_HELPER);

       var oColorContext = this.getColorContext(oTransientRenderingContext);
       var oColorInterpolator = this.getCachedColorInterpolator(oTransientRenderingContext, datamodelshapes.Logical.COLOR);
       var labels = [];

       //Get the display names of the rows
       for(var nRow = 0; nRow < nRowLayerCount; nRow++){
           var rowKey = oDataLayoutHelper.getLogicalEdgeName(datamodelshapes.Physical.ROW, nRow);
           var displayName = oDataLayout.getLayerMetadata(datamodelshapes.Physical.ROW, nRow, data.LayerMetadata.LAYER_DISPLAY_NAME);
           //console.log("row: "+nRow+", order: "+ rowKey+", name: "+ displayName);
           labels[nRow] = displayName;

       }

        var outputMap = new Map();
        const colors = new Set();
        for(var nRow = 0; nRow < Math.max(nRows, 1); nRow++) {

            var top, bottom, x1 = -1, y1 = -1, x2 = -1, y2 = -1;
            var colorObj, color;
            var url, tooltip;
            var tooltipMap = new Map();

            for (var nRowLayer = 0; nRowLayer < Math.max(nRowLayerCount, 1); nRowLayer++) {
                //var row = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                var rowType = oDataLayoutHelper.getLogicalEdgeName(datamodelshapes.Physical.ROW, nRowLayer);
                switch (rowType) {
                    case "row":
                        url = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                        break;
                    case "detail":
                        if (!top) {
                            top = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                            x1 = top.substring(top.indexOf("=") + 1, top.indexOf(";")).trim();
                            y1 = top.substring(top.lastIndexOf("=") + 1).trim();
                        } else {
                            bottom = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                            x2 = bottom.substring(bottom.indexOf("=") + 1, bottom.indexOf(";")).trim();
                            y2 = bottom.substring(bottom.lastIndexOf("=") + 1).trim();
                        }
                        break;
                    case "color":
                        //colorObj = this.getDataItemColorInfo(oDataLayoutHelper, oColorContext, oColorInterpolator, nRow, 0);
                        //color = colorObj.sColor ? colorObj.sColor : colorObj.sSeriesColor;
                        color = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                        colors.add(color);
                        break;
                    /*case "glyph":
                        //tooltip = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                        break;*/
                    case "tooltip":
                        tooltip = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                        tooltipMap.set(labels[nRowLayer], tooltip);
                        break;
                }
            }

            const colorVals = Array.from(colors);

            var points = {x1: x1, y1: y1, x2: x2, y2: y2, color: color, tooltip: tooltipMap, colorText: colorVals};
            if(!outputMap.get(url)){
                var pointsList = [];
                pointsList.push(points);
                outputMap.set(url, pointsList);
            } else {
                outputMap.get(url).push(points);
            }
            top = undefined;
        }

        if (outputMap)
            return outputMap;
        else
            return null;
    }
   /**
    * Called whenever new data is ready and this visualization needs to update.
    * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
    */
   VisionSeries.prototype.render = function(oTransientRenderingContext) {
      try {
         // Note: all events will be received after initialize and start complete.  We may get other events
         // such as 'resize' before the render, i.e. this might not be the first event.

         // Retrieve the data object for this visualization
         var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);

          if (!oDataLayout)
              return;

          var dataMap = this._generateData(oDataLayout, oTransientRenderingContext);
          this.loadConfig();
         // Determine the number of records available for rendering on ROW
         // Because we specified that Category should be placed on ROW in the data model handler,
         // this returns the number of rows for the data in Category.
         //var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);

         // Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
         // but may be used to render.
         var elContainer = this.getContainerElem();
          var sVizContainerId = this.getSubElementIdFromParent(this.getContainerElem(), "hvc");
          var pane = sVizContainerId.substring(sVizContainerId.indexOf("view") + 5, sVizContainerId.indexOf("pane"));
          var conetentPane = sVizContainerId.substring(sVizContainerId.indexOf("contentpane_") + 12, sVizContainerId.indexOf("vizCont") - 1);
          var cId = pane + "_" + conetentPane;
          var htmlContent = "<div class='canvas' id=canvas_" + cId + ">" +
                            "</div>"+
                            "<canvas id=myCanvas_" + cId + " style='display:none'></canvas>";
          $(elContainer).html(htmlContent);
          var oViz = this;

          var width = $(elContainer).width();
          var height = $(elContainer).height();
          //var canvas = document.getElementById("canvas_"+cId);

          var tooltip = d3.select("body")
              .append("div")
              .attr('class', 'tooltip')
              .style('display', 'none');

          function roundOff(d) {
              //var round1 = Number.isInteger(d) ? d : +d.toFixed(2);
              const round = Math.round(d * 100) / 100;
              //console.log(round);
              return round;
          }
          function numSeparator(num)
          {
              var num_parts = num.toString().split(".");
              num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
              return num_parts.join(".");
          }

          function tooltipContent(obj) {
              var map = obj.srcElement.__data__.tooltip;
              if(map && map.size > 0){
                  var content = "<table>" ;
                  for(let [key, value] of map){
                      if(parseFloat(value)){
                          value = numSeparator(roundOff(value));
                      }
                      content += "<tr><td class='tthead'>"+key+": </td><td class='ttval'>"+value+"</td></tr>";
                  }
                  content += "</table>";
                  tooltip.style("display", null);
                  return content;
              } else {
                  return tooltip.style("display", "none");
              }
          }

          var strDataURI = dataMap ? dataMap.entries().next().value[0] : '';
          var values = dataMap.entries().next().value[1];
          var iHeight, iWidth;

          var c = document.getElementById("myCanvas_"+cId);
          var cxt = c.getContext("2d");

          var colorArray = ["#DE7F11", "#5FB9B5", "#B47282", "#4E4137",
              "#A0C98B", "#84401F", "#295B62", "#9F80C9",
              "#FEC36F", "#5B2F6F" , "#62A2B9", "#317A49"];
          var userColors = oViz.getBoxColor() ? oViz.getBoxColor().replaceAll(" ", "") : "";
          var uColorArray = userColors ? userColors.split(",") : [];
          var colorList = uColorArray && uColorArray.length > 0 ? uColorArray.concat(colorArray) : colorArray;
          var color = function(d) {
              return colorList[d % colorList.length];
          }

          var image = new Image;
          image.onload = function() {
              iWidth = this.width;
              iHeight = this.height;
              cxt.drawImage(image, 0, 0);
              //console.log("inside width: "+iWidth+" height: "+iHeight);
              drawImage(iWidth, iHeight);
              $("#canvas_"+cId).attr("width", iWidth);
              $("#canvas_"+cId).attr("height", iHeight);

              if(iWidth/width > iHeight/height){
                  $("#canvas_"+cId).css("width", "95%");
                  $("#canvas_"+cId).css("height", "auto");

              } else {
                  $("#canvas_"+cId).css("height", "95%");
                  $("#canvas_"+cId).css("width", "auto");
              }
          }
          image.src = strDataURI;

          function drawImage(w, h){
              //console.log("image width: "+w+" height: "+h);
              const svg = d3.select("#canvas_" + cId)
                  .append("svg")
                  .attr("id", "svg_"+cId)
                  .attr("viewBox", [0, 0, w, h])
                  .attr('height', 'auto')
                  /*.attr('width', 'auto')*/;

              var myimage = svg.append('image')
                  .attr('xlink:href', strDataURI)
                  .attr('class', 'img')
                  .attr('width', w)
                  .attr('height', h);

              var strokeVal = 0.000005 * w * h;
              strokeVal = strokeVal > 10 ? 10 : (strokeVal < 2 ? 2 : strokeVal);

              var rect = svg.selectAll('rect')
                  .data(values)
                  .enter()
                  .append('rect')
                  .attr("x", function(d){ return Math.min(d.x1, d.x2) * w})
                  .attr("y", function(d){ return Math.min(d.y1, d.y2) * h})
                  .attr("width", function(d){ return Math.abs(d.x1 - d.x2) * w})
                  .attr("height", function(d){ return Math.abs(d.y1 - d.y2) * h})
                  .attr('stroke', function(d){
                      //console.log("["+i+"] "+d.color);
                      let val = d.color ? d.colorText.indexOf(d.color) : 0;
                      return val !=-1 ? color(val) : color(0);
                  })
                  .attr('stroke-width', function(d){
                      if(d.x1!=-1 && d.y1!=-1 && d.x2!=-1 && d.y2!=-1){
                          return strokeVal;
                      } else {
                          return 0;
                      }
                  })
                  .attr('fill', 'none')
                  .attr("pointer-events", "all")
                  .on("mouseover", function(d) {
                      var text = d.srcElement.__data__.tooltip;
                      if(text)
                        return tooltip.style("display", null).html(tooltipContent(d));
                  })
                  .on("mousemove", function() {
                      return tooltip.style("top", (event.pageY - 20) + "px")
                          .style("left", event.pageX + "px");
                  })
                  .on("mouseout", function() {
                      return tooltip.style("display", "none");
                  });
          }
      }
      finally {
         this._setIsRendered(true);
      }
    };

    /**
     * Resize the visualization
     * @param {Object} oVizDimensions - contains two properties, width and height
     * @param {module:obitech-report/vizcontext#VizContext} oTransientVizContext the viz context
     */
    VisionSeries.prototype.resizeVisualization = function (oVizDimensions, oTransientVizContext) {
        var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
        this.render(oTransientRenderingContext);
    };

    VisionSeries.prototype._addVizSpecificMenuOptions = function (oTransientVizContext, sMenuType, aResults, contextmenu, evtParams, oTransientRenderingContext) {
        //aResults.shift();
        VisionSeries.superClass._addVizSpecificMenuOptions.call(this, oTransientVizContext, sMenuType, aResults, contextmenu, evtParams, oTransientRenderingContext);
        if (sMenuType === euidef.CM_TYPE_VIZ_PROPS) {
            // Set up the column context for the last column in the ROWS bucket
            var oColumnContext = this.getDrillPathColumnContext(oTransientVizContext, datamodelshapes.Logical.ROW);

        }
    };

    VisionSeries.prototype._addVizSpecificPropsDialog = function (oTabbedPanelsGadgetInfo) {
        this.tabInfo = oTabbedPanelsGadgetInfo;
        this.doAddVizSpecificPropsDialog(this, oTabbedPanelsGadgetInfo);
        VisionSeries.superClass._addVizSpecificPropsDialog.call(this, oTabbedPanelsGadgetInfo);
    };

    VisionSeries.prototype.doAddVizSpecificPropsDialog = function (oTransientRenderingContext, oTabbedPanelsGadgetInfo) {
        jsx.assertObject(oTransientRenderingContext, "oTransientRenderingContext");
        jsx.assertInstanceOf(oTabbedPanelsGadgetInfo, gadgets.TabbedPanelsGadgetInfo, "oTabbedPanelsGadgetInfo", "obitech-application/gadgets.TabbedPanelsGadgetInfo");

        /*var oDataModel = this.getRootDataModel();
        if(!oDataModel){
            return;
        }*/

        this.setTabInfo(oTabbedPanelsGadgetInfo);
        var viewConfig = this.getViewConfig() || {};
        var options = this.getViewConfig() || {};
        this._fillDefaultOptions(options, null);
        var generalPanel = gadgetdialog.forcePanelByID(oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_GENERAL);

        var oGadgetFactory = this.getGadgetFactory();

        var oBoxColorKey = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.boxColor);
        var oBoxColorInfo = oGadgetFactory.createGadgetInfo("boxColorGadget", 'Color Values', 'Color Values', oBoxColorKey);
        generalPanel.addChild(oBoxColorInfo);

        if (VisionSeries.superClass.doAddVizSpecificPropsDialog)
            VisionSeries.superClass.doAddVizSpecificPropsDialog.apply(this, arguments);
    };

    VisionSeries.prototype._handlePropChange = function (sGadgetID, oPropChange, oViewSettings, oActionContext) {
        var updateSettings = VisionSeries.superClass._handlePropChange.call(this, sGadgetID, oPropChange, oViewSettings, oActionContext);
        if (updateSettings) {
            return updateSettings; // super handled it
        }

        // Allow the super class an attempt to handle the changes
        var conf = oViewSettings.getViewConfigJSON(dataviz.SettingsNS.CHART) || {};

        if (sGadgetID === "boxColorGadget")
        {
            if (jsx.isNull(conf.styleDefaults))
            {
                conf.styleDefaults = {};
            }
            this.setBoxColor(oPropChange.value);
            this.Config.boxColor = oPropChange.value;
            this._saveSettings();
            updateSettings = true;
        }
        return updateSettings;
    };


   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the visualization
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {string=} sVersion 
    * @returns {module:com-company-visionseries/visionSeries.VisionSeries}
    * @memberof module:com-company-visionseries/visionSeries
    */
   function createClientComponent(sID, sDisplayName, sOrigin) {
     // Argument validation done by base class
      return new VisionSeries(sID, sDisplayName, sOrigin, VisionSeries.VERSION);
   };

   return {
      createClientComponent : createClientComponent
   };
});