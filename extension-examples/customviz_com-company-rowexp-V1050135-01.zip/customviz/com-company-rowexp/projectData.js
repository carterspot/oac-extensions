var projData =   [
    {
        "id": "t1",
        "name": "Task 1",
        "resource": "Larry",
        "start": "2014-01-01",
        "end": "2014-10-01",
        "children": [
            {
                "id": "t1:1",
                "name": "Task 1-1",
                "resource": "Larry",
                "start": "2014-01-01",
                "end": "2014-03-01",
                "children": [
                    {
                        "id": "t1:1:1",
                        "name": "Task 1-1-1",
                        "resource": "Larry",
                        "start": "2014-01-01",
                        "end": "2014-02-01"
                    },
                    {
                        "id": "t1:1:2",
                        "name": "Task 1-1-2",
                        "resource": "Larry",
                        "start": "2014-02-01",
                        "end": "2014-03-01"
                    }
                ]
            },
            {
                "id": "t1:2",
                "name": "Task 1-2",
                "resource": "Larry",
                "start": "2014-03-01",
                "end": "2014-06-01",
                "children": [
                    {
                        "id": "t1:2:1",
                        "name": "Task 1-2-1",
                        "resource": "Larry",
                        "start": "2014-03-01",
                        "end": "2014-05-01"
                    },
                    {
                        "id": "t1:2:2",
                        "name": "Task 1-2-2",
                        "resource": "Larry",
                        "start": "2014-05-01",
                        "end": "2014-06-01"
                    }
                ]
            },
            {
                "id": "t1:3",
                "name": "Task 1-3",
                "resource": "Larry",
                "start": "2014-06-01",
                "end": "2014-08-01"
            },
            {
                "id": "t1:4",
                "name": "Task 1-4",
                "resource": "Larry",
                "start": "2014-08-01",
                "end": "2014-10-01"
            }
        ]
    },
    {
        "id": "t2",
        "name": "Task 2",
        "resource": "Larry",
        "start": "2014-04-01",
        "end": "2014-12-01",
        "children": [
            {
                "id": "t2:1",
                "name": "Task 2-1",
                "resource": "Larry",
                "start": "2014-04-01",
                "end": "2014-05-01"
            },
            {
                "id": "t2:2",
                "name": "Task 2-2",
                "resource": "Larry",
                "start": "2014-05-01",
                "end": "2014-08-01",
                "children": [
                    {
                        "id": "t2:2:1",
                        "name": "Task 2-2-1",
                        "resource": "Larry",
                        "start": "2014-05-01",
                        "end": "2014-07-01"
                    },
                    {
                        "id": "t2:2:2",
                        "name": "Task 2-2-2",
                        "resource": "Larry",
                        "start": "2014-07-01",
                        "end": "2014-08-01"
                    }
                ]
            },
            {
                "id": "t2:3",
                "name": "Task 2-3",
                "resource": "Larry",
                "start": "2014-08-01",
                "end": "2014-12-01",
                "children": [
                    {
                        "id": "t2:3:1",
                        "name": "Task 2-3-1",
                        "resource": "Larry",
                        "start": "2014-08-01",
                        "end": "2014-11-01",
                        "children": [
                            {
                                "id": "t2:3:1:1",
                                "name": "Task 2-3-1-1",
                                "resource": "Larry",
                                "start": "2014-08-01",
                                "end": "2014-9-01"
                            },
                            {
                                "id": "t2:3:1:2",
                                "name": "Task 2-3-1-2",
                                "resource": "Larry",
                                "start": "2014-9-01",
                                "end": "2014-11-01"
                            }
                        ]
                    },
                    {
                        "id": "t2:3:2",
                        "name": "Task 2-3-2",
                        "resource": "Larry",
                        "start": "2014-11-01",
                        "end": "2014-12-01"
                    }
                ]
            }
        ]
    },
    {
        "id": "t3",
        "name": "Task 3",
        "resource": "Larry",
        "start": "2014-05-01",
        "end": "2014-11-01",
        "children": [
            {
                "id": "t3:1",
                "name": "Task 3-1",
                "resource": "Larry",
                "start": "2014-05-01",
                "end": "2014-08-01",
                "children": [
                    {
                        "id": "t3:1:1",
                        "name": "Task 3-1-1",
                        "resource": "Larry",
                        "start": "2014-05-01",
                        "end": "2014-06-01"
                    },
                    {
                        "id": "t3:1:2",
                        "name": "Task 3-1-2",
                        "resource": "Larry",
                        "start": "2014-06-01",
                        "end": "2014-08-01"
                    }
                ]
            },
            {
                "id": "t3:2",
                "name": "Task 3-2",
                "resource": "Larry",
                "start": "2014-08-01",
                "end": "2014-11-01"
            }
        ]
    },
    {
        "id": "t4",
        "name": "Task 4",
        "resource": "Larry",
        "start": "2014-11-01",
        "end": "2014-12-01"
    }
];