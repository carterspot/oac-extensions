define({
    "ROWEXPANDER_DISPLAY_NAME": "RowExp Plugin",
    "ROWEXPANDER_SHORT_DISPLAY_NAME": "RowExp Plugin",
    "ROWEXPANDER_CATEGORY":"RowExp Plugin",
    "ROWEXP_ITEM_SIZE":"Item Size",
    "TEXT_MESSAGE": "Hello!  This is the {0} visualization and I have {1} rows of data."

});