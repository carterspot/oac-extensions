define(['jquery',
        'obitech-framework/jsx',
        'obitech-report/datavisualization',
        'obitech-reportservices/datamodelshapes',
        'obitech-reportservices/events',
        'obitech-appservices/logger',
        'ojL10n!com-company-rowexp/nls/messages',
        'knockout',
        'ojs/ojbootstrap',
        'ojs/ojflattenedtreedataproviderview',
        'ojs/ojarraytreedataprovider',
        'ojs/ojkeyset', 'obitech-application/extendable-ui-definitions',
        'ojs/ojknockout', 'ojs/ojtable',
        'ojs/ojrowexpander', 'ojs/ojbutton',
        'ojs/ojinputtext', 'ojs/ojlabel', 'ojs/ojtoolbar',
        'ojs/ojformlayout', 'ojs/ojinputnumber',
        'obitech-framework/messageformat',
        'css!com-company-rowexp/rowExpstyles'],
        function($,
                 jsx,
                 dataviz,
                 datamodelshapes,
                 events,
                 logger,
                 messages,
                 ko, bootstrap,
                 FlattenedTreeDataProviderView,
                 ArrayTreeDataProvider,
                 ojkeyset_1, euidef) {
   "use strict";

   var MODULE_NAME = 'com-company-rowexp/rowExp';

   //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   //jsx.assertAllNotNullExceptLastN(arguments, "rowExp.js arguments", 2);

   var _logger = new logger.Logger(MODULE_NAME);

   // The version of our Plugin
   RowExp.VERSION = "1.0.0";

   /**
    * The implementation of the rowExp visualization.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @extends {module:obitech-report/visualization.Visualization}
    * @memberof module:com-company-rowexp/rowExp#
    */
   function RowExp(sID, sDisplayName, sOrigin, sVersion) {
      // Argument validation done by base class
      RowExp.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);
   };
   jsx.extend(RowExp, dataviz.DataVisualization);

    RowExp.prototype._generateData = function (oDataLayout) {
        var oDataModel = this.getRootDataModel();
        if (!oDataModel || !oDataLayout) {
            return;
        }

        var aAllMeasures = oDataModel.getColumnIDsIn(datamodelshapes.Physical.DATA);
        var nMeasures = aAllMeasures.length;

        var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
        var nRowLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
        var nCols = oDataLayout.getEdgeExtent(datamodelshapes.Physical.COLUMN);
        var nColLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.COLUMN);
        console.log('Number of rows coming into the plugin :'+nRows);

        var metric_map = [];
        var metric_names = [];
        for(var m=0;m<nMeasures;m++){
            //metric_names.push(oDataLayout.getValue(datamodelshapes.Physical.COLUMN, 0, m, false));
            var m_name = oDataLayout.getValue(datamodelshapes.Physical.COLUMN, 0, m, false);
            metric_map.push(m_name);
            if(m_name === ""){
                metric_names.push("Count");
            } else {
                metric_names.push("measure_"+m);
            }
        }

        var nRow;
        var baseStructure =
            {
                "id": null,
                "name": null
                /*"attr": {
                    "id": null,
                    "name": null
                }*/
            };

        function find(parent, id) {
            for (var i = 0; parent.children && i < parent.children.length; i++) {
                //if (parent.children[i].attr.name == id) {
                if (parent.children[i].name == id) {
                    return parent.children[i];
                }
            }
            return null;
        }

        function findRecursive(parent, id) {
            var i, obj;
            //look in children
            for (i = 0; parent.children && i < parent.children.length; i++) {
                obj = find(parent.children[i], id);
                if (obj !== null) {
                    return obj;
                }
            }
            //look recursively in children
            for (i = 0; parent.children && i < parent.children.length; i++) {
                obj = findRecursive(parent.children[i], id);
                if (obj !== null) {
                    return obj;
                }
            }
            return null;
        }

        var id_count = 0;
        var nMeasCnt = 0;
        var column_names = [];
        for (var nRow = 0; nRow< Math.max(nRows,1); nRow++) {
            var nMeasuresLayer = 1;
            var current = baseStructure;
            for (var nCol = 0; nCol < (nRowLayerCount); nCol++) {
                var column_value = oDataLayout.getValue(datamodelshapes.Physical.ROW, nCol, nRow, false);
                var column_value_id = ++id_count;
                if(column_value && column_value !=""){
                    var obj = find(current, column_value);
                    var metric_value;
                    var metric_values = [];

                    if(nCol==(nRowLayerCount -1)){
                        for(var m=0;m<nMeasures;m++){
                            metric_value=oDataLayout.getValue(datamodelshapes.Physical.DATA,  nRow,m, false);
                            metric_values.push(Number(metric_value).toFixed(2));
                        }
                    }
                    else{
                        for(var m=0;m<nMeasures;m++){
                            metric_value=null;
                            metric_values.push(metric_value);
                        }

                    }
                    if (obj === null && nCol === 0) {
                        obj = findRecursive(current, column_value);
                    }

                    if (obj === null) {
                        //create a new one if not found
                        obj = {
                            id: column_value_id,
                            name: column_value
                            /*"attr": {
                                id: column_value_id,
                                name: column_value
                            }*/
                        };
                        for(var k=0 ; k < metric_names.length;k++){
                            //obj.attr[metric_names[k]] = metric_values[k] ? Number(metric_values[k]) : null;
                            obj[metric_names[k]] = metric_values[k] ? Number(metric_values[k]) : null;
                        }

                        if(current.children === undefined)
                        {
                            current.children = [];
                        }
                        current.children.push(obj);
                    }
                    current = obj;
                }
            }
        }
        var jsonObj = JSON.parse(JSON.stringify(baseStructure));
        function roundOff(d) {var round = Number.isInteger(d) ? d : +d.toFixed(2); return round;}
        function numSeparator(num)
        {
            var num_parts = num.toString().split(".");
            num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            return num_parts.join(".");
        }
        //For each metric, actual value is used to sum up at the parent levels. Display value has the thousands separator and is used only for display in the plugin.
        var rollup = function (node,metricname){
            var r=0, m=0;
            var n;
            //if (! node.attr[metricname]  && node.attr[metricname] !=0){
            if (! node[metricname]  && node[metricname] !=0){
                for (var i=0; i<node.children.length; i++){
                    n = node.children[i];
                    //if(n.attr[metricname])
                    //node.children[i].attr[metricname+'_display']= Number(node.children[i].attr[metricname]).toLocaleString();
                    var m_value = Number(node.children[i][metricname]);
                    m_value = Number.isInteger(m_value) ? m_value : m_value.toFixed(2);
                    node.children[i][metricname+'_display']= numSeparator(m_value);
                    //m = (n.attr[metricname])? n.attr[metricname] : rollup(n,metricname);
                    m = (n[metricname])? n[metricname] : rollup(n,metricname);
                    r += m;
                }
                //node.attr[metricname]= r.toFixed(2);
                //node[metricname]= r.toFixed(2);
                //node[metricname]= r.toFixed(2);
                //node.attr[metricname+'_display']=r.toLocaleString();
                var r_value =  Number(r);
                r_value = Number.isInteger(r_value) ? r_value : r_value.toFixed(2);
                node[metricname+'_display']=numSeparator(r_value);
            } else {
                //return node.attr[metricname];
                return node[metricname];
            }
            return r;
        }

        for(var nMeas=0;nMeas<metric_names.length;nMeas++){
            rollup(jsonObj,metric_names[nMeas]);
        }
        var totalObj= {
            "id": "Total",
            "name": "Total",
            /*"attr": {
                "id": "Total",
                "name": "Total"
            }*/
        };

        for(var k=0 ; k < metric_names.length;k++){
            //totalObj.attr[metric_names[k]+'_display'] = jsonObj.attr[metric_names[k]+'_display'];
            totalObj[metric_names[k]+'_display'] = jsonObj[metric_names[k]+'_display'];
        }
        jsonObj.children.push(totalObj);

        self.data = jsonObj;
        self.noOfMeasures= nMeasures;
        self.metric_names = metric_names;
        self.metric_map = metric_map;
        return null;
    }

   /**
    * Called whenever new data is ready and this visualization needs to update.
    * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
    */
   RowExp.prototype.render = function(oTransientRenderingContext) {
      try {
         // Note: all events will be received after initialize and start complete.  We may get other events
         // such as 'resize' before the render, i.e. this might not be the first event.

         // Retrieve the data object for this visualization
         var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);

         if (!oDataLayout)
              return;

         this._generateData(oDataLayout);

         // Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
         // but may be used to render.
         var elContainer = this.getContainerElem();
          elContainer.innerHTML = '';
          var containerDiv = document.createElement('div');
          var sVizContainerId = this.getSubElementIdFromParent(this.getContainerElem(), "hvc");
          var pane = sVizContainerId.substring(sVizContainerId.indexOf("view")+5,sVizContainerId.indexOf("pane"));
          var conetentPane = sVizContainerId.substring(sVizContainerId.indexOf("contentpane_")+12,sVizContainerId.indexOf("vizCont")-1);
          var cId = pane+"_"+conetentPane;
          //elContainer.style.overflow = "auto";
          var htmlContent = "<div id=\"canvas_"+cId+"\" class=\"demo-padding demo-container row-exp\">\n" +
              "        <div id=\"componentDemoContent\" class=\"componentDemoContent\">\n" +
              "          <div id=\"tablecontainer_"+cId+"\" class=\"demo-sample-page\">" +
              "             <div id=\"sampleBanner_"+cId+"\" class=\"demo-sample-banner demo-sample-banner-top oj-bg-neutral-10\">" +
              "                <oj-form-layout max-columns=\"1\" direction=\"row\">\n" +
              "                  <oj-buttonset-one\n" +
              "                    id=\"expandButtonSet\"\n" +
              "                    aria-label=\"Choose only one setting.\"\n" +
              "                    aria-controls=\"rowexpander-perf-expand\"\n" +
              "                    value=\"{{expandValue}}\">\n" +
              "                    <oj-option value=\"collapse\">Collapse All</oj-option>\n" +
              "                    <oj-option value=\"expand\">Expand All</oj-option>\n" +
              "                  </oj-buttonset-one>\n" +
              "                </oj-form-layout>" +
              "             </div>" +
              "            <oj-table\n" +
              "              id=\"table_"+cId+"\"\n" +
              "              aria-label=\"Tasks Table\"\n" +
              "              accessibility.row-header=\"name\"\n" +
              "              scroll-policy=\"loadMoreOnScroll\"\n" +
              "              scroll-policy-options.fetch-size=\"10\"\n" +
              "              scroll-policy-options.scroller=\"#tablecontainer_"+cId+"\"\n" +
     //         "              scroll-policy-options.scroller-offset-top=\"50\"" +
              "              scroll-policy-options.scroller-offset-top=\"1\"" +
              "              scroll-policy-options.max-count=\"10000\"" +
              "              data=\"[[dataProvider]]\"\n" +
              "              columns='[{\"headerText\": \"\", " +
                                      "\"sortProperty\": \"name\", " +
                                      "\"weight\": \"2\", " +
                                      "\"style\":\"font-weight: bold !important;\", " +
                                      "\"id\": \"name\"}\n";
              for (var i = 0; i < self.metric_names.length; i++) {
                  var m_name = "";
                  var m_level = self.metric_names[i];
                  if(m_level == "Count"){
                      m_name = m_level;
                  } else {
                      var m_index = Number(m_level.slice(m_level.indexOf('_')+1));
                      m_name = self.metric_map[m_index];
                  }
                  htmlContent += ",{\"headerText\": \""+m_name+"\", " +
                      "\"sortProperty\": \""+m_level+"\", " +
                      "\"id\": \""+m_level+"\"," +
                      "\"style\":\"font-weight: bold !important;\", " +
                      "\"className\": \"oj-helper-text-align-end\"" +
                      "}\n";
              }
              htmlContent +=    "]'" +
                  "              class=\"demo-table-container row-exp-table\">\n" +
              "              <template slot=\"rowTemplate\" data-oj-as=\"row\">\n" +
              "                <tr>\n" +
              "                  <td>\n" +
              "                    <oj-row-expander context=\"[[row]]\" data-oj-clickthrough=\"disabled\"></oj-row-expander>\n" +
              "                    <span>\n" +
              "                      <oj-bind-text value=\"[[row.item.data.name]]\"></oj-bind-text>\n" +
              "                    </span>\n" +
              "                  </td>\n";
              for (var i = 0; i < self.metric_names.length; i++) {
                  var m_value = self.metric_names[i]+"_display";
                  htmlContent +=
                  "                  <td>\n" +
                  "                    <span>\n" +
                  "                      <oj-bind-text value=\"[[row.item.data."+m_value+"]]\"></oj-bind-text>\n" +
                  "                    </span>\n" +
                  "                  </td>\n";
              }
            htmlContent +=
              "                </tr>\n" +
              "              </template>\n" +
              "            </oj-table>\n" +
              "          </div>\n" +
              "        </div>\n" +
              "      </div>";
          containerDiv.innerHTML = htmlContent;
          elContainer.appendChild(containerDiv);

          function ChartModel() {
              this.value = ko.observable();
              this.scrollPolicyValue = ko.observable("loadMoreOnScroll");
              this.task1expanded = ko.observable();
              this.isAddAll = ko.observable();
              this.expanded = ko.observable();
              this.expandValue = ko.observable("collapse");
              this.arrayTreeDataProvider = new ArrayTreeDataProvider(self.data.children, {
                  keyAttributes: 'id'
              });
              this.dataProvider = ko.observable();
              this.updateData = () => {
                  this.dataProvider(new FlattenedTreeDataProviderView(new ArrayTreeDataProvider(self.data.children, {
                      keyAttributes: "id",
                  }), {
                      expanded: this.expanded,
                  }));
              };
              this.expandKeySet = ko.computed(() => {
                  if (this.expandValue() === "collapse") {
                      this.expanded = new ojkeyset_1.KeySetImpl();
                  }
                  else {
                      this.expanded = new ojkeyset_1.AllKeySetImpl();
                  }
                  this.updateData();
                  return this.expanded;
              });
              this.expanded = new ojkeyset_1.KeySetImpl();
              this.updateData();
          }

          bootstrap.whenDocumentReady().then(
              function()
              {
                  ko.applyBindings(new ChartModel(), containerDiv);
              }
          );
          //var tbl_container = document.getElementsByClassName("demo-table-container")[0];
          var tbl_container = document.getElementById("table_"+cId);
          tbl_container.style.height = $(elContainer).height() - 50 + "px";
      }
      finally {
         this._setIsRendered(true);
      }
    };

    /**
     * Resize the visualization
     * @param {Object} oVizDimensions - contains two properties, width and height
     * @param {module:obitech-report/vizcontext#VizContext} oTransientVizContext the viz context
     */
    RowExp.prototype.resizeVisualization = function(oVizDimensions, oTransientVizContext){
        var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
        this.render(oTransientRenderingContext);
    };


    /**
     * Override to add in options to the context menu
     *
     * @param {module:obitech-report/vizcontext#VizContext} oTransientVizContext the viz context
     * @param {string} sMenuType The menu type associated with the context menu being populated
     * @param {Array} The array of resulting menu options
     * @param {module:obitech-appservices/contextmenu} contextmenu The contextmenu namespace object (used to reduce dependencies)
     * @param {object} evtParams The entire 'params' object that is extracted from client evt
     * @param {object} oTransientRenderingContext the current transient rendering context
     */
    RowExp.prototype._addVizSpecificMenuOptions = function(oTransientVizContext, sMenuType, aResults, contextmenu, evtParams, oTransientRenderingContext){
        document.getElementById("table_contextmenu") ? document.getElementById("table_contextmenu").remove() :
        aResults.shift();
        RowExp.superClass._addVizSpecificMenuOptions.call(this, oTransientVizContext, sMenuType, aResults, contextmenu, evtParams, oTransientRenderingContext);
        if (sMenuType === euidef.CM_TYPE_VIZ_PROPS) {
            // Set up the column context for the last column in the ROWS bucket
            var oColumnContext = this.getDrillPathColumnContext(oTransientVizContext, datamodelshapes.Logical.ROW);

            // Set up events
            /*if(!this.isViewOnlyLimit()){
                this._addFilterMenuOption(oTransientVizContext, aResults, null, null, oTransientRenderingContext);
                this._addRemoveSelectedMenuOption(oTransientVizContext, aResults, null, null, oTransientRenderingContext);
                //this._addDrillMenuOption(oTransientVizContext, aResults, null, null, oColumnContext, oTransientRenderingContext);
                //this._addLateralDrillMenuOption(oTransientVizContext, aResults);
            }*/
        }
    };

   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the visualization
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {string=} sVersion 
    * @returns {module:com-company-rowexp/rowExp.RowExp}
    * @memberof module:com-company-rowexp/rowExp
    */
   function createClientComponent(sID, sDisplayName, sOrigin) {
     // Argument validation done by base class
      return new RowExp(sID, sDisplayName, sOrigin, RowExp.VERSION);
   };

   return {
      createClientComponent : createClientComponent
   };
});