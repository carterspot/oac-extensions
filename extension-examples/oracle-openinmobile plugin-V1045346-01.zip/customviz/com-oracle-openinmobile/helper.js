var helper = {};

helper.convertURLtoMobileFriendlyURL = function (sURL, sInternalCanvasName){
   const mobileURL = new URL(sURL);
   mobileURL.pathname = "/public/majel/share";
   return mobileURL.href + "&canvasname=" + sInternalCanvasName
}