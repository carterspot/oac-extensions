requirejs.config({
   paths: {
       qrcode: "com-oracle-openinmobile/qrcode",
       myfunctions: "com-oracle-openinmobile/helper"
   }, 
   // Shim configurations for modules that do not expose AMD
   shim: {
      qrcode: {
      exports: 'QRCode'
    },
    myfunctions: {
      exports: 'helper'
    }
   },
});

define(['jquery',   
        'obitech-framework/jsx',
        'obitech-report/visualization',
        'qrcode',
        'obitech-report/gadgetdialog',
        'obitech-application/extendable-ui-definitions',
        'obitech-application/gadgets',
        'obitech-framework/actioncontext',
        'obitech-appservices/logger',
        'ojL10n!com-oracle-openinmobile/nls/messages',
        'myfunctions',
        'obitech-framework/messageformat',
        'skin!css!com-oracle-openinmobile/openinmobilestyles'],
        function($,
                 jsx,
                 viz,
                 qrcode,
                 gadgetdialog,
                 euidef,
                 gadgets,
                 actioncontext,
                 logger,
                 messages) {
   "use strict";

   var MODULE_NAME = 'com-oracle-openinmobile/openinmobile';

   //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   jsx.assertAllNotNullExceptLastN(arguments, "openinmobile.js arguments", 2);

   var _logger = new logger.Logger(MODULE_NAME);

   // The version of our Plugin
   Openinmobile.VERSION = "1.0.0";

   /**
    * The implementation of the openinmobile visualization.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @extends {module:obitech-report/visualization.Visualization}
    * @memberof module:com-oracle-openinmobile/openinmobile#
    */
   function Openinmobile(sID, sDisplayName, sOrigin, sVersion) {
      // Argument validation done by base class
      Openinmobile.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);
   };
   jsx.extend(Openinmobile, viz.Visualization);
   /**
    * Called whenever this visualization needs to update.
    */
   Openinmobile.prototype.render = function() {
      // Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
      // but may be used to render.
      try {
         var oConf = this.getVizSpecificViewConfigSettingJSON() || {};
         //get a unique ID per viz
         var codeID = this.getID() + 'qrcode';
         var elContainer = this.getContainerElem();
         var htmlString ="";
         
         //check if default or blank and add the header text if not blank.
         var sInitialHeaderText = oConf.headerTextAreaValue;
         if (jsx.isNull(sInitialHeaderText)) {
            sInitialHeaderText = messages.OPENINMOBILE_HEADER_TEXT;
            htmlString = htmlString + "<div class='mainTitle'><p>" + sInitialHeaderText + "</p></div>";
         }
         else {
            if (oConf.headerTextAreaValue){
               htmlString = htmlString + "<div class='mainTitle'><p>" + oConf.headerTextAreaValue + "</p></div>";
            }
         }

         //add the QR code tag
         htmlString = htmlString + "<div class='qrImage' id='" + codeID + "'></div>";
 
         //check if default or blank and add the footer text if not blank.
         var sInitialFooterText = oConf.footerTextAreaValue;
         if (jsx.isNull(sInitialFooterText)) {
            sInitialFooterText = messages.OPENINMOBILE_FOOTER_TEXT;
            htmlString = htmlString +"<div class='info'><p>" + sInitialFooterText + "</p></div>";
         }
         else{
            if (oConf.footerTextAreaValue){
               htmlString = htmlString +"<div class='info'><p>" + oConf.footerTextAreaValue + "</p></div>";
            }
         }

         $(elContainer).html(htmlString);

         //modify the URL to be the mobile friendly version.
         var sMobileURL = helper.convertURLtoMobileFriendlyURL(window.location.href,this.getCurrentCanvasName());

         //get the internal name of the canvas
         var canvasName = this.getCurrentCanvasName();

         //create the qr code with a link to the workbook and current canvas
         var testqrcode = new QRCode(codeID, {
            text: sMobileURL,
            width: 100,
            height: 100,
            colorDark : "#000000",
            colorLight : "#ffffff",
            correctLevel : QRCode.CorrectLevel.L
        });
         
      }
      finally{
         this._setIsRendered(true);
      }
   };

   /**
     * returns the name of the current canvas
     **/
   Openinmobile.prototype.getCurrentCanvasName = function (){
      var oReportManager = this.getReportManager();
      var sCanvasName = oReportManager.getCurrentCanvasName();
      
      return(sCanvasName);
    }

   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the visualization
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {string=} sVersion 
    * @returns {module:com-oracle-openinmobile/openinmobile.Openinmobile}
    * @memberof module:com-oracle-openinmobile/openinmobile
    */
   function createClientComponent(sID, sDisplayName, sOrigin) {
     // Argument validation done by base class
      return new Openinmobile(sID, sDisplayName, sOrigin, Openinmobile.VERSION);
   };

   Openinmobile.prototype.getCurrentViewConfigVersion = function () {
      return "1.0.0";
   };

   Openinmobile.prototype._addVizSpecificPropsDialog = function (oTabbedPanelsGadgetInfo){
 
      Openinmobile.superClass._addVizSpecificPropsDialog.call(this, oTabbedPanelsGadgetInfo);
      var oGadgetFactory = this.getGadgetFactory();
      var oConf = this.getVizSpecificViewConfigSettingJSON() || {};
     
      var oGeneralPanel = gadgetdialog.forcePanelByID(oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_GENERAL);
      oGeneralPanel.setBodyCSSClass("bi_gadgets_no_cell_separator");
      var nOrder = euidef.GD_FIELD_ORDER_GENERAL_VIZ_SPECIFIC;

      var sInitialHeaderText = oConf.headerTextAreaValue;
      if (jsx.isNull(sInitialHeaderText)) {
         sInitialHeaderText = messages.OPENINMOBILE_HEADER_TEXT;
      }
    
      var oGadgetValueProperties = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_AREA, sInitialHeaderText);
      var sGadgetId = "Header_Text";
      nOrder+=1;
      var oGadgetInfo = oGadgetFactory.createGadgetInfo(sGadgetId,  "Header Text", "Add text to appear above the QR code.", oGadgetValueProperties, nOrder);
      oGeneralPanel.addChild(oGadgetInfo);

      var sInitialFooterText = oConf.footerTextAreaValue;
      if (jsx.isNull(sInitialFooterText)) {
         sInitialFooterText = messages.OPENINMOBILE_FOOTER_TEXT;
      }

      var oGadgetValueProperties = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_AREA, sInitialFooterText);
      var sGadgetId = "Footer_Text";
      nOrder+=1;
      var oGadgetInfo = oGadgetFactory.createGadgetInfo(sGadgetId,  "Footer Text", "Add text to appear below the QR code.", oGadgetValueProperties, nOrder);
      oGeneralPanel.addChild(oGadgetInfo);

   };
    
   Openinmobile.prototype._handlePropChange = function (sGadgetID, oPropChange, oViewSettings, oActionContext) {
      jsx.assertString(sGadgetID, 'sGadgetID');
      jsx.assertObject(oPropChange, 'oPropChange');
      jsx.assertObject(oViewSettings, 'oViewSettings');
      jsx.assertInstanceOf(oActionContext, actioncontext.ActionContext, "oActionContext", "actioncontext.ActionContext");
    
      //Allow the super class an attempt to handle the changes
      var bUpdateSettings = Openinmobile.superClass._handlePropChange.call(this, sGadgetID, oPropChange, oViewSettings, oActionContext);
       
      if (!bUpdateSettings) {
         switch (sGadgetID)
         {
         case "Header_Text":
            if(!jsx.isNull(oPropChange.value)) {
               this.setVizSpecificViewConfigSetting(oViewSettings, "headerTextAreaValue", oPropChange.value);
               bUpdateSettings = true;
            }
            break;
         case "Footer_Text":
            if(!jsx.isNull(oPropChange.value)) {
               this.setVizSpecificViewConfigSetting(oViewSettings, "footerTextAreaValue", oPropChange.value);
               bUpdateSettings = true;
            }
            break;
         }  
      }

      if(bUpdateSettings){
         this.render();
      }

      return bUpdateSettings;
   };

   return {
      createClientComponent : createClientComponent
   };
});