define({
    "OPENINMOBILE_DISPLAY_NAME": "Open in Mobile QR Code",
    "OPENINMOBILE_SHORT_DISPLAY_NAME": "Open in Mobile QR Code",
    "OPENINMOBILE_CATEGORY":"Open in Mobile QR Code",
    "OPENINMOBILE_ROW_LABEL":"Open in Mobile QR Code",
    "OPENINMOBILE_ITEM_SIZE":"Item Size",
    "OPENINMOBILE_HEADER_TEXT":"To visit this workbook on mobile scan the code below.",
    "OPENINMOBILE_FOOTER_TEXT":"To Install Oracle Analytics Mobile visit the Mobile Access section in your profile."
});