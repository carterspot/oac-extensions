define({
   "OGLWORKBOOKVIZ_DISPLAY_NAME": "Guided Learning",
   "OGLWORKBOOKVIZ_DESCRIPTION": "The plugin description"
});