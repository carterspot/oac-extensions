define(['jquery',
    'knockout',
    'ojs/ojcore',
    'obitech-framework/jetfactory2',
    'obitech-framework/browserdom',
    'obitech-framework/jsx',
    "obitech-application/extendable-ui-definitions",
    "obitech-appservices/contextmenumanager",
    'obitech-appservices/logger',
    'obitech-report/reportnode',
    'obitech-appservices/events',
    'ojL10n!com-company-oglworkbookviz/nls/messages',
    'ojs/ojattributegrouphandler',
    'obitech-framework/actioncontext',
        'obitech-framework/messageformat',
        'skin!css!com-company-oglworkbookviz/oglworkbookvizstyles'],
    function ($,
        ko,
        oj,
        jetfactory2,
        browserdom,
        jsx,
        euidef,
        contextmenu,
        logger,
        reportnode,
        events,
        messages,
        attributeGroupHandler,
        actioncontext) {
   "use strict";

   var MODULE_NAME = 'com-company-oglworkbookviz/oGLWorkbookViz';

   // Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   jsx.assertAllNotNullExceptLastN(arguments, "oGLWorkbookViz.js arguments", 2);

   var _logger = new logger.Logger(MODULE_NAME);
   _logger.info("Initializing the custom workbook plugin: oGLWorkbookViz");

   /** 
    * This package provides the implementation for OGLWorkbookViz Plugin.
    * @exports com-company-oglworkbookviz/oGLWorkbookViz
    */
   var oGLWorkbookViz = {};

   // The version of this module
   oGLWorkbookViz.VERSION = "1.0.0";

   /**
    * The implementation of the oGLWorkbookViz plugin.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @param {Object=} oPropertyBag The custom property bag
    * @extends {module:obitech-report/reportnode.ReportNode}
    * @memberof module:com-company-oglworkbookviz/oGLWorkbookViz#
    */
   function OGLWorkbookViz(sID, sDisplayName, sOrigin, sVersion, oPropertyBag) {
      // Argument validation done by base class
       OGLWorkbookViz.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);


      var _oPropertyBag = oPropertyBag;

      /**
       * Returns the custom property bag
       * 
       * @returns {Object} The custom Properties
       * @private
       * @deprecated
       */     
      this._getCustomPropertyBag = function () {
         return _oPropertyBag;       
      };

      /**
       * Returns the custom properties
       * 
       * @returns {Object} The custom properties
       * @protected
       */
      this.getCustomSettingsBag = function () {
         return _oPropertyBag;
      };
   };
   jsx.extend(OGLWorkbookViz, reportnode.ReportNode);

      
        OGLWorkbookViz.prototype.performMainAction = function () {
            // Callback code
            var sId = "inspectID_8675320";
           var csrftoken = this.getSessionInfoService().getCSRFToken();
            var self = this;
            var oSettings = null;
            var oSettings = JSON.parse(this.getPluginRegistry().getCustomPlugins()["com-company-oglworkbookviz"].customSettings);
            var AppID = oSettings.AppID;
            var ServerURL = oSettings.ServerURL;
            ServerURL = ServerURL + "/player/latest/static/js/iridizeLoader.min.js";


            var sessionInfo = this.getSessionInfoService();
                window.iridize = window.iridize || function (e, t, n) { return iridize.api.call(e, t, n); };
                iridize.api = iridize.api || { q: [], call: function (e, t, n) { iridize.api.q.push({ method: e, data: t, callback: n }); } };
               iridize.appId = AppID;

                /*FOR YOUR DEV OR STAGING ENVIRONMENTS PLEASE UNCOMMENT THE NEXT LINE*/
                iridize.env = "dev";
                /*TO ENABLE USER CONDITIONS UNCOMMENT THE NEXT LINE.
                Add as many fields as you would like (e.g. user_role, user_name, etc.) */
                //iridize("api.fields.set", {user_id:"LOGGED_IN_USER_ID_GOES_HERE"});
                var e = document.createElement("script");
            var t = document.body; e.src = "https://guidedlearning.oracle.com/player/latest/static/js/iridizeLoader.min.js";
            var t = document.body; e.src = ServerURL;
                e.type = "text/javascript"; e.async = true; t.appendChild(e);
   
        };

   /**
    * This method returns the description of this plugin
    * @static
    * @returns {string} The description of this plugin
    */
   OGLWorkbookViz.prototype.getDescription = function () {
      return messages.OGLWORKBOOKVIZ_DESCRIPTION;
   };

   /**
    * This method returns the Display Name for this plugin
    * @static
    * @returns {string} The Display Name for this plugin
    */
   OGLWorkbookViz.prototype.getDisplayName = function () {
      return messages.OGLWORKBOOKVIZ_DISPLAY_NAME;
   };

   /**
    * Handles the POPULATE_CONTEXT_MENU event
    */
   OGLWorkbookViz.prototype._onPopulateContextMenu = function (oClientEvent) {
      var oParams = oClientEvent.getParams();
      var aResults = oParams.results;
      var oContext = oParams.contributionContext;
      var eMenuType = oContext[contextmenu.contrmgr.TYPE];
      if (eMenuType === euidef.CM_TYPE_CUSTOM_WORKBOOK_PLUGINS_MENU_OPTIONS) {
         var oOptionInfo = {
            "name": this.getDisplayName(),
            "description": this.getDescription(),
            "callback": browserdom.createCallback(this, this.performMainAction)
         };
         contextmenu.addOptionToResults(aResults, oOptionInfo, this.getID(), euidef.CM_ID_GROUP_CUSTOM_WORKBOOK_PLUGINS);
      }
   };

   /**
    * This method is used to initialize the component
    */
   OGLWorkbookViz.prototype._doInitializeComponent = function () {
     OGLWorkbookViz.superClass._doInitializeComponent.apply(this, arguments);
      // Populate context menu
      this.subscribeToEvent(events.types.POPULATE_CONTEXT_MENU, this._onPopulateContextMenu);
   };

   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the plugin
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {Object=} oPropertyBag The custom property bag
    * @returns {module:com-company-oglworkbookviz/oGLWorkbookViz.OGLWorkbookViz}
    * @memberof module:com-company-oglworkbookviz/oGLWorkbookViz
    */
   oGLWorkbookViz.createInstance = function (sID, sDisplayName, sOrigin, oPropertyBag) {
     // Argument validation done by base class
      return new OGLWorkbookViz(sID, sDisplayName, sOrigin, oGLWorkbookViz.VERSION, oPropertyBag);
   };

   oGLWorkbookViz.OGLWorkbookViz = OGLWorkbookViz;

  return oGLWorkbookViz;
});