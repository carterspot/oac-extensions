define({
    "MOTIONCHARTVIZ_DISPLAY_NAME": "MotionChartViz Plugin",
    "MOTIONCHARTVIZ_SHORT_DISPLAY_NAME": "MotionChart Plugin",
    "MOTIONCHARTVIZ_CATEGORY":"MotionChart Plugin",
    "MOTIONCHARTVIZ_ROW":"X-Axis & Y-Axis",
    "MOTIONCHARTVIZ_TIME":"Z-Axis (Slider)",
    "MOTIONCHARTVIZ_CATEGORY":"Points",
    "TEXT_MESSAGE": "MotionChart!  This is the {0} visualization and I have {1} rows of data."

});