define(['jquery',
        'obitech-framework/jsx',
        'obitech-report/datavisualization',
        'obitech-legend/legendandvizcontainer',
        'obitech-reportservices/datamodelshapes',
        'obitech-reportservices/events',
        'obitech-reportservices/interactionservice',
        'obitech-reportservices/markingservice',
        'obitech-application/gadgets',
        'obitech-report/visualization',
        'obitech-report/gadgetdialog',
        'obitech-application/bi-definitions',
        'obitech-appservices/logger',
        'ojL10n!com-company-motionChartViz/nls/messages',
        'obitech-application/extendable-ui-definitions',
        'obitech-reportservices/data',
        'd3js',
        'knockout',
        'ojs/ojattributegrouphandler',
        'obitech-framework/messageformat',
        'skin!css!com-company-motionChartViz/motionChartVizstyles'],
    function($,
             jsx,
             dataviz,
             legendandvizcontainer,
             datamodelshapes,
             events,
             interactions,
             marking,
             gadgets,
             viz,
             gadgetdialog,
             definitions,
             logger,
             messages,
             euidef,
             data,
             d3,
             ko,
             attributeGroupHandler) {
        "use strict";

        var MODULE_NAME = 'com-company-motionChartViz/motionChartViz';

        //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
        jsx.assertAllNotNullExceptLastN(arguments, "motionChartViz.js arguments", 2);

        var motionChart = {};

        var _logger = new logger.Logger(MODULE_NAME);

        // The version of our Plugin
        MotionChartViz.VERSION = "1.0.0";

        /**
         * The implementation of the motionchartViz visualization.
         *
         * @constructor
         * @param {string} sID
         * @param {string} sDisplayName
         * @param {string} sOrigin
         * @param {string} sVersion
         * @extends {module:obitech-report/visualization.Visualization}
         * @memberof module:com-company-motionchartViz/motionchartViz#
         */

        function MotionChartViz(sID, sDisplayName, sOrigin, sVersion) {
            // Argument validation done by base class
            MotionChartViz.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);

            var duration = '5';
            var xScale = 'Linear';
            var yScale = 'Linear';
            var displayLabel = 'Off';
            var value_panel = '';
            var tabInfo = '';
            var groupInfo = '';
            var xMin = 0, xMax = 0, yMin = 0, yMax = 0, tMin = 0, tMax = 0, sMin = 0, sMax = 0, tToggle = tMin;
            var xDisplayName ='', yDisplayName='';
            var rowDisplayNames=[];
            var tArray = [];
            var legendItems = new Map();
            var timeArray = [];
            var cID = '';

            this.Config = {
                duration: '5',
                xScale: 'Linear',
                yScale: 'Linear',
                displayLabel: 'Off',
                c_title:'Auto',
                xMin: 0,
                xMax: 0,
                yMin: 0,
                yMax: 0,
                tMin: 0,
                tMax: 0,
                sMin: 0,
                sMax: 0,
                tToggle: 0,
                xDisplayName: '',
                yDisplayName: '',
                rowDisplayNames: [],
                tArray: [],
                legendItems: new Map(),
                timeArray: [],
                cID: ''
            }

            this._saveSettings = function() {
                this.getSettings().setViewConfigJSON(dataviz.SettingsNS.CHART, this.Config);
            };

            this.loadConfig = function (){
                var conf = this.getSettings().getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
                if (conf.duration) this.Config.duration = conf.duration;
                if (conf.xScale) this.Config.xScale = conf.xScale;
                if (conf.yScale) this.Config.yScale = conf.yScale;
                if (conf.displayLabel) this.Config.displayLabel = conf.displayLabel;
                if (conf.c_title) this.Config.c_title = conf.c_title;
                if (conf.xMin) this.Config.xMin = conf.xMin;
                if (conf.xMax) this.Config.xMax = conf.xMax;
                if (conf.yMin) this.Config.yMin = conf.yMin;
                if (conf.yMax) this.Config.yMax = conf.yMax;
                if (conf.tMin) this.Config.tMin = conf.tMin;
                if (conf.tMax) this.Config.tMax = conf.tMax;
                if (conf.sMin) this.Config.sMin = conf.sMin;
                if (conf.sMax) this.Config.sMax = conf.sMax;
                if (conf.tToggle) this.Config.tToggle = conf.tToggle;
                if (conf.xDisplayName) this.Config.xDisplayName = conf.xDisplayName;
                if (conf.yDisplayName) this.Config.yDisplayName = conf.yDisplayName;
                if (conf.rowDisplayNames) this.Config.rowDisplayNames = conf.rowDisplayNames;
                if (conf.tArray) this.Config.tArray = conf.tArray;
                if (conf.legendItems) this.Config.legendItems = conf.legendItems;
                if (conf.timeArray) this.Config.timeArray = conf.timeArray;
                if (conf.cID) this.Config.cID = conf.cID;

            }

            this.getXMin = function(){
                return(this.Config.xMin);
            };

            this.setXMin = function (o){
                this.Config.xMin = o;
            };

            this.getXMax = function(){
                return(this.Config.xMax);
            };

            this.setXMax = function (o){
                this.Config.xMax = o;
            };

            this.getYMin = function(){
                return(this.Config.yMin);
            };

            this.setYMin = function (o){
                this.Config.yMin = o;
            };

            this.getYMax = function(){
                return(this.Config.yMax);
            };

            this.setYMax = function (o){
                this.Config.yMax = o;
            };

            this.getTMin = function(){
                return(this.Config.tMin);
            };

            this.setTMin = function (o){
                this.Config.tMin = o;
            };

            this.getTMax = function(){
                return(this.Config.tMax);
            };

            this.setTMax = function (o){
                this.Config.tMax = o;
            };

            this.getSMin = function(){
                return(this.Config.sMin);
            };

            this.setSMin = function (o){
                this.Config.sMin = o;
            };

            this.getSMax = function(){
                return(this.Config.sMax);
            };

            this.setSMax = function (o){
                this.Config.sMax = o;
            };

            this.getTToggle = function(){
                return(this.Config.tToggle);
            };

            this.setTToggle = function (o){
                this.Config.tToggle = o;
            };

            this.getXDisplayName = function(){
                return(this.Config.xDisplayName);
            };

            this.setXDisplayName = function (o){
                this.Config.xDisplayName = o;
            };

            this.getYDisplayName = function(){
                return(this.Config.yDisplayName);
            };

            this.setYDisplayName = function (o){
                this.Config.yDisplayName = o;
            };

            this.getRowDisplayNames = function(){
                return(this.Config.rowDisplayNames);
            };

            this.setRowDisplayNames = function (o){
                this.Config.rowDisplayNames = o;
            };

            this.getTArray = function(){
                return(this.Config.tArray);
            };

            this.setTArray = function (o){
                this.Config.tArray = o;
            };

            this.getLegendItems = function(){
                return(this.Config.legendItems);
            };

            this.setLegendItems = function (o){
                this.Config.legendItems = o;
            };

            this.getTimeArray = function(){
                return(this.Config.timeArray);
            };

            this.setTimeArray = function (o){
                this.Config.timeArray = o;
            };

            this.getCID = function(){
                return(this.Config.cID);
            };

            this.setCID = function (o){
                this.Config.cID = o;
            };

            this.getCTitle = function(){
                return(this.Config.c_title);
            };

            this.setCTitle = function (o){
                this.Config.c_title = o;
                this._saveSettings();
            };

            this.getDuration = function(){
                return(this.Config.duration);
            };

            this.setDuration = function (o){
                this.Config.duration = o;
                this._saveSettings();
            };

            this.getXScale = function(){
                return(this.Config.xScale);
            };

            this.setXScale = function (o){
                this.Config.xScale = o;
                this._saveSettings();
            };

            this.getYScale = function(){
                return(this.Config.yScale);
            };

            this.setYScale = function (o){
                this.Config.yScale = o;
                this._saveSettings();
            };

            this.getDisplayLabel = function(){
                return(this.Config.displayLabel);
            };

            this.setDisplayLabel = function (o){
                this.Config.displayLabel = o;
                this._saveSettings();
            };

            this.getValuePanel = function(){
                return(value_panel);
            };

            this.setValuePanel = function (o){
                value_panel = o;
            };

            this.getTabInfo = function(){
                return(tabInfo);
            };

            this.setTabInfo = function (o){
                tabInfo = o;
            };

            this.getGroupInfo = function(){
                return(groupInfo);
            };

            this.setGroupInfo = function (o){
                groupInfo = o;
            };

            /**
             * @type {Array.<String>} - The array of selected items
             */
            var aSelectedItems = new Map();

            /**
             * @return  {Array.<String>} - The array of selected items
             */
            this.getSelectedItems = function(){
                return aSelectedItems;
            };

            /**
             * Clears the current list of selected items
             */
            this.clearSelectedItems = function(){
                aSelectedItems = new Map();
            };
        };


        jsx.extend(MotionChartViz, dataviz.DataVisualization);

        MotionChartViz.prototype._generateData = function(oDataLayout, oTransientRenderingContext){

            var oDataModel = this.getRootDataModel();
            if(!oDataModel || !oDataLayout){
                return;
            }
            this.setRowDisplayNames(new Map());
            var aAllMeasures = oDataModel.getColumnIDsIn(datamodelshapes.Physical.DATA);
            var nMeasures = aAllMeasures.length;
            var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
            var nRowLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
            var nCols = oDataLayout.getEdgeExtent(datamodelshapes.Physical.COLUMN);
            var nColLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.COLUMN);
            var oDataLayoutHelper = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT_HELPER);

            //Get the display names of the x-axis and y-axis measures
            if(nMeasures === 2){
                this.setXDisplayName(oDataLayout.getValue(datamodelshapes.Physical.COLUMN, 0, 0, false));
                this.setYDisplayName(oDataLayout.getValue(datamodelshapes.Physical.COLUMN, 0, 1, false));
            } else {
                this.setXDisplayName("X-Axis");
                this.setYDisplayName("Y-Axis");
            }

            //Get the display names of the rows
            for(var nRow = 0; nRow < nRowLayerCount; nRow++){
                var rowKey = oDataLayoutHelper.getLogicalEdgeName(datamodelshapes.Physical.ROW, nRow);
                var displayName = oDataLayout.getLayerMetadata(datamodelshapes.Physical.ROW, nRow, data.LayerMetadata.LAYER_DISPLAY_NAME);
                this.getRowDisplayNames().set(rowKey, {order: nRow, name: displayName});
            }

            var oColorContext = this.getColorContext(oTransientRenderingContext);
            var oColorInterpolator = this.getCachedColorInterpolator(oTransientRenderingContext, datamodelshapes.Logical.COLOR);

            // Measure labels layer
            var isMeasureLabelsLayer = function (eEdgeType, nLayer) {
                return oDataLayout.getLayerMetadata(eEdgeType, nLayer, data.LayerMetadata.LAYER_ISMEASURE_LABELS);
            };

            // Last layer: we get the data values and colors from this layer
            var getLastNonMeasureLayer = function (eEdge) {
                var nLayerCount = oDataLayout.getLayerCount(eEdge);
                for (var i = nLayerCount - 1; i >= 0; i--) {
                    if (!isMeasureLabelsLayer(eEdge, i))
                        return i;
                }
                return -1;
            };

            var nLastEdge = datamodelshapes.Physical.COLUMN; // check column edge first

            var nLastLayer = getLastNonMeasureLayer(datamodelshapes.Physical.COLUMN);
            if (nLastLayer < 0) { // if not on column edge look on row edge
                nLastEdge = datamodelshapes.Physical.ROW;
                nLastLayer = getLastNonMeasureLayer(datamodelshapes.Physical.ROW);
            }

            function evaluateRange(obj, xVal, yVal, tVal, sVal){
                obj.setXMin((xVal < obj.getXMin() || obj.getXMin() === 0) ? xVal : obj.getXMin());
                obj.setXMax((xVal > obj.getXMax() || obj.getXMax() === 0) ? xVal : obj.getXMax());

                obj.setYMin((yVal < obj.getYMin() || obj.getYMin() === 0) ? yVal : obj.getYMin());
                obj.setYMax((yVal > obj.getYMax() || obj.getYMax() === 0) ? yVal : obj.getYMax());

                obj.setTMin((tVal < obj.getTMin() || obj.getTMin() === 0) ? tVal : obj.getTMin());
                obj.setTMax((tVal > obj.getTMax() || obj.getTMax() === 0) ? tVal : obj.getTMax());

                obj.setSMin((sVal < obj.getSMin() || obj.getSMin() === 0) ? sVal : obj.getSMin());
                obj.setSMax((sVal > obj.getSMax() || obj.getSMax() === 0) ? sVal : obj.getSMax());
            }

            //--------------------------------------------------------
            var outputMap = [], outputObj = [];
            this.setXMin(0), this.setXMax(0), this.setYMin(0), this.setYMax(0),
            this.setSMin(0), this.setSMax(0), this.setTMin(0), this.setTMax(0);

            var tArray = [], legendItems = new Map();
            var timeLimit = new Map();

            for(var nRow = 0; nRow < Math.max(nRows, 1); nRow++) {
                var time, size, colorObj, color, point, xval, yval;
                for (var nRowLayer = 0; nRowLayer < Math.max(nRowLayerCount, 1); nRowLayer++) {
                    var row = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                    var rowType = oDataLayoutHelper.getLogicalEdgeName(datamodelshapes.Physical.ROW, nRowLayer);
                    switch (rowType) {
                        case "row":
                            time = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                            tArray.push(time);
                            timeLimit.set(time, '');
                            break;
                        case "detail":
                            point = oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
                            break;
                        case "color":
                            colorObj = this.getDataItemColorInfo(oDataLayoutHelper, oColorContext, oColorInterpolator, nRow, 0);
                            color = colorObj.sSeriesColorLabel ? colorObj.sSeriesColorLabel : row;
                            legendItems.set(color, '');
                            break;
                        case "size":
                            size = parseFloat(oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false));
                            break;
                    }
                }

                this.setTArray(tArray);
                this.setLegendItems(legendItems);

                if (nCols === 2) {
                    xval = parseFloat(oDataLayout.getValue(datamodelshapes.Physical.DATA, nRow, 0));
                    yval = parseFloat(oDataLayout.getValue(datamodelshapes.Physical.DATA, nRow, 1));
                }
                evaluateRange(this, xval, yval, time, size);

                var aOutput = {point: point, color: color, x_values: [], y_values: [], size: [], rows: [], cols: []};

                var xArray = [time, xval];
                var yArray = [time, yval];
                var rowArray = [time, nRow];
                var colArray = [time, 0];
                aOutput.x_values.push(xArray);
                aOutput.y_values.push(yArray);
                aOutput.rows.push(rowArray);
                aOutput.cols.push(colArray);
                if (this.getRowDisplayNames().get("size")) {
                    size = size ? size : 1000;
                } else {
                    size = 1000;
                }
                var sizeArray = [time, size];
                aOutput.size.push(sizeArray);
                if (this.getRowDisplayNames().get("color")) {
                    aOutput.color = color;
                }
                outputMap.push(aOutput);
            }

            var grouped = outputMap.reduce(function (r, a) {
                r[a.point] = r[a.point] || [];
                r[a.point].push(a);
                return r;
            }, Object.create(null));

            outputObj = [];
            for(var key in grouped){
                if(key !== ""){
                    //var items = {point: key, color: [], x_values:[], y_values:[], size: []};
                    var groupByPoint = {point: key, colorValues: []};
                    var groupByColor = grouped[key].reduce(function (r, a) {
                        r[a.color] = r[a.color] || [];
                        r[a.color].push(a);
                        return r;
                    }, Object.create(null));
                    var colorObject = [];
                    for(var keyColor in groupByColor){
                        var items = {color: keyColor, x_values:[], y_values:[], size: [], rows: [], cols: []};
                        groupByColor[keyColor].forEach(function(item){
                            items.x_values.push(item.x_values[0]);
                            items.y_values.push(item.y_values[0]);
                            items.size.push(item.size[0]);
                            items.rows.push(item.rows[0]);
                            items.cols.push(item.cols[0]);
                        });
                        colorObject.push(items);
                    }
                    groupByPoint.colorValues.push(colorObject);
                    outputObj.push(groupByPoint);
                }
            }

            var tempTimeArray = Array.from(timeLimit.keys());

            this.setTimeArray(tempTimeArray.sort(function (a, b) {
                return ('' + a.attr).localeCompare(b.attr, 'en', { numeric: true });
            }));

            if (outputObj)
                return outputObj;
            else
                return null;
        }


        MotionChartViz.prototype._render = function(oTransientRenderingContext) {
            // Note: all events will be received after initialize and start complete.  We may get other events
            // such as 'resize' before the render, i.e. this might not be the first event.

            try{
                this.loadConfig();
                // Retrieve the data object for this visualization
                var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);

                if (!oDataLayout)
                    return;

                var durationValue = parseInt(this.getDuration());
                var xScaleValue = this.getXScale();
                var yScaleValue = this.getYScale();

                var grouped = this._generateData(oDataLayout, oTransientRenderingContext);
                this.setSMax(this.getSMax() ? this.getSMax() : 10000);
                this.setTToggle(this.getTToggle() === 0 ? 1 : 1);

                // Determine the number of records available for rendering on ROW
                // Because we specified that Category should be placed on ROW in the data model handler,
                // this returns the number of rows for the data in Category.
                var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);

                // Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
                // but may be used to render.
                var elContainer = this.getContainerElem();
                //console.log("Container ID: "+$(elContainer)[0].id);
                var sVizContainerId = this.getSubElementIdFromParent(this.getContainerElem(), "hvc");
                var pane = sVizContainerId.substring(sVizContainerId.indexOf("view")+5,sVizContainerId.indexOf("pane"));
                var conetentPane = sVizContainerId.substring(sVizContainerId.indexOf("contentpane_")+12,sVizContainerId.indexOf("vizCont")-1);
                var cId = pane+"_"+conetentPane;
                this.setCID(cId);
                var colorCategory = this.getRowDisplayNames().get("color") ? this.getRowDisplayNames().get("color").name : "";
                var sliderMax = this.getTimeArray().length;
                var sliderVal;
                var minVal = sliderVal ? sliderVal : 1;


                var htmlContent = "<div class='canvas' id="+cId+">" +
                                "<div class='main'><p id=chart_"+cId+" class='chart'><\/p>"+
                                "<div class='playarea'><div id=play_"+cId+" data-role=button data-inline=true data-icon=refresh class='play play_button'>" +
                                "<span id=playText_"+cId+" class='playText'><\/span><\/div>\n" +
                                "<input class=slider name=slider id=slider_"+cId+" min="+this.getTToggle()+" max="+sliderMax+" value=1 step=1 type=range \/>" +
                                "<\/div></div>"+
                                "<div>"+
                                "<div id=legendPane_"+cId+" class='title'>" +
                                "<span id=legendName_"+cId+">"+colorCategory+"</span></div>" +
                                "<div id=legend_"+cId+" class='legend'></div>"+
                                "</div></div>";
                $(elContainer).html(htmlContent);
                if (sliderMax <= this.getTToggle())
                    this.setTToggle(1);
                //elContainer.style.overflow = "auto";

                $(".canvas").attr("width", $(elContainer).width());
                $(".canvas").attr("height", $(elContainer).height());
                var cWidth = $(elContainer).width();
                var cHeight = $(elContainer).height();
                var sMax = this.getSMax();

                // Various accessors that specify the four dimensions of data to visualize.
                function x(d) { return d.x_axis; }
                function y(d) { return d.y_axis; }
                function radius(d) { return Math.round(getRadius(d.size)); }
                function color(d) { return d.color; }
                function key(d) { return d.point.concat(d.color); }
                function getRadius(d) {return (d/sMax)*130;}
                function roundOff(d) {var round = Number.isInteger(d) ? d : +d.toFixed(2); return round;}

                // Chart dimensions.
                var margin = {top: 19.5, right: 19.5, bottom: 25.5, left: 59.5},
                    width = ($(elContainer).width() * .85) - margin.right - 100,
                    height = $(elContainer).height() - margin.top - margin.bottom - 80;
                var yMargin = this.getYMax() * .1;
                this.setYMax(Math.round(yMargin)+this.getYMax());
                this.setYMin((this.getYMin() >= 0) ? 0 : Math.round(this.getYMin() - Math.round(yMargin)));

                var xMargin = this.getXMax() * .1;
                this.setXMax(Math.round(xMargin)+this.getXMax());

                //Adding Legend Data
                var uniqueLegends = [];
                for(let color of this.getLegendItems().keys()){
                    uniqueLegends.push(color);
                }

                // Various scales. These domains make assumptions of data, naturally.
                var maxVal = 1000;
                var maxRadius = maxVal/10;
                var xscale, yscale;
                var yAxis, xAxis;

                if(xScaleValue === "Logarithmic" && yScaleValue === "Logarithmic"){
                    xscale = d3.scale.log().domain([.1, this.getXMax()*10]).range([0, width]);
                    yscale = d3.scale.log().domain([.1, this.getYMax()*10]).range([height, 0]);
                    xAxis = d3.svg.axis().orient("bottom").scale(xscale).ticks(10, "s");
                    yAxis = d3.svg.axis().orient("left").scale(yscale).ticks(10, "s");
                } else if(xScaleValue === "Linear" && yScaleValue === "Logarithmic"){
                    xscale = d3.scale.linear().domain([this.getXMin(), this.getXMax()]).range([0, width]);
                    yscale = d3.scale.log().domain([.1, this.getYMax()*10]).range([height, 0]);
                    xAxis = d3.svg.axis().orient("bottom").scale(xscale).ticks(10, "s");
                    yAxis = d3.svg.axis().orient("left").scale(yscale).ticks(10, "s");
                } else if(xScaleValue === "Logarithmic" && yScaleValue === "Linear"){
                    xscale = d3.scale.log().domain([.1, this.getXMax()*10]).range([0, width]);
                    yscale = d3.scale.linear().domain([this.getYMin(), this.getYMax()]).range([height, 0]);
                    xAxis = d3.svg.axis().orient("bottom").scale(xscale).ticks(10, "s");
                    yAxis = d3.svg.axis().orient("left").scale(yscale).ticks(10, "s");
                } else {
                    xscale = d3.scale.linear().domain([this.getXMin(), this.getXMax()]).range([0, width]);
                    yscale = d3.scale.linear().domain([this.getYMin(), this.getYMax()]).range([height, 0]);
                    xAxis = d3.svg.axis().orient("bottom").scale(xscale).ticks(10, "s");
                    yAxis = d3.svg.axis().orient("left").scale(yscale).ticks(10, "s");
                }
                var radiusScale = d3.scale.sqrt().domain([0, maxVal]).range([0, maxRadius]);
                /*var colorHandler = new attributeGroupHandler.ColorAttributeGroupHandler();
                var colorScale = function(str) {
                    return colorHandler.getValue(str);
                }*/
                var colorScale = function(str) {
                    var num = (str.length+str.charCodeAt(0))*17911;
                    str = str.concat(str);
                    str = str.concat(getSplChar(num.toString()));
                    //str = getSplChar(num.toString());
                    var hash = 0;
                    for (var i = 0; i < str.length; i++) {
                        hash = str.charCodeAt(i) + ((hash << 5) - hash);
                        //hash |= 0;
                    }
                    /*var h = hash % 971, s = 60, l = 60;
                    return 'hsl('+h+', '+s+'%, '+l+'%)';*/
                    var hex = ((hash>>24)&0xFF).toString(16) +
                        ((hash>>16)&0xFF).toString(16) +
                        ((hash>>8)&0xFF).toString(16) +
                        (hash&0xFF).toString(16);
                    // Sometimes the string returned will be too short so we
                    // add zeros to pad it out, which later get removed if
                    // the length is greater than six.
                    hex += '000000';
                    return "#"+hex.substring(0, 6);
                }

                var getSplChar = function(num){
                    var result = '';
                    for(var i = 0; i < num.length; i++){
                        switch (num.charAt(i)) {
                            case 0: result.concat('!OA'); break;
                            case 1: result.concat('@YNM'); break;
                            case 2: result.concat('#NAB'); break;
                            case 3: result.concat('$)JA'); break;
                            case 4: result.concat('%HJAGT'); break;
                            case 5: result.concat('^BAVF'); break;
                            case 6: result.concat('&EGQ>'); break;
                            case 7: result.concat('*MABTD'); break;
                            case 8: result.concat('(%GJAI'); break;
                            case 9: result.concat(')*JGBYNBHA'); break;
                        }
                    }
                    return result;
                }

                // Create the SVG container and set the origin.
                var svg = d3.select("#chart_"+cId).append("svg")
                    .attr("width", width + margin.left + margin.right + 100)
                    .attr("height", height + margin.top + margin.bottom)
                    .append("g")
                    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

                // Add the x-axis.
                svg.append("g")
                    .attr("class", "x axis")
                    .attr("transform", "translate(0," + height + ")")
                    .call(xAxis);

                // Add the y-axis.
                svg.append("g")
                    .attr("class", "y axis")
                    .call(yAxis);

                // Add an x-axis label.
                svg.append("text")
                    .attr("class", "x label")
                    .attr("text-anchor", "end")
                    .attr("x", width)
                    .attr("y", height - 6)
                    .text(this.getXDisplayName());

                // Add a y-axis label.
                svg.append("text")
                    .attr("class", "y label")
                    .attr("text-anchor", "end")
                    .attr("y", 6)
                    .attr("dy", ".75em")
                    .attr("transform", "rotate(-90)")
                    .text(this.getYDisplayName());

                // Add the year label; the value is set on transition.
                var label = svg.append("text")
                    .attr("class", "year label")
                    .attr("text-anchor", "end")
                    .attr("y", height - 24)
                    .attr("x", width)
                    .text(this.getTimeArray()[0]);

                //legend_"+cId+"
                var legendHeight = 20*uniqueLegends.length;
                var legendMaxHt = height + .7;
                var marginOffset = 25;
                var legendMarginTop = legendMaxHt >= legendHeight ? ((legendMaxHt-legendHeight)/2)+marginOffset : marginOffset;

                var svgLegned4 = d3.select("#legend_"+cId).append("svg")
                    .attr("width", width * .2)
                    .attr("height", legendHeight);
                    /*.attr("class", "legendSvg");*/

                var legend4 = svgLegned4.selectAll("#legend_"+cId)
                    .data(uniqueLegends.sort())
                    .enter().append('g')
                    .attr("transform", function (d, i) {
                        return "translate(0," + i * 20 + ")";
                    });

                legend4.append('rect')
                    .attr("x", 0)
                    .attr("y", 0)
                    .attr("width", 10)
                    .attr("height", 10)
                    .style("opacity", 0.7)
                    .style("fill", function (d, i) {
                        return colorScale(d);
                    });

                legend4.append('text')
                    .attr("x", 20)
                    .attr("y", 10)
                    .text(function (d, i) {
                        return d
                    })
                    .attr("class", "textselected")
                    .style("text-anchor", "start")
                    .style("font-size", 10);

                $("#legend_"+cId).css("max-height", legendMaxHt);
                $("#legend_"+cId).css("margin-top", legendMarginTop);
                $("#legendPane_"+cId).css("padding-top", legendMarginTop-marginOffset);

                // Load the data.
                drawMotionChart(grouped, this);
                function drawMotionChart(data, o) {

                    // A bisector since many nation's data is sparsely-defined.
                    var bisect = d3.bisector(function(d) { return d[0]; });

                    var tooltip = d3.select("body")
                        .append("div")
                        .style("position", "absolute")
                        .style("z-index", "10")
                        .style("visibility", "hidden")
                        .text("a simple tooltip");

                    tooltip.text("my tooltip text");
                    
                    function tooltipContent(d) {
                        var content = "<table>" +
                            "<tr><td class='tthead'>(X-Axis)"+o.getXDisplayName()+"</td><td class='ttval'>"+roundOff(d.x_axis)+"</td></tr>"+
                            "<tr><td class='tthead'>(Y-Axis)"+o.getYDisplayName()+"</td><td class='ttval'>"+roundOff(d.y_axis)+"</td></tr>";
                        if(o.getRowDisplayNames().get("size") && d.size){
                            content += "<tr><td class='tthead'>(Size)"+o.getRowDisplayNames().get("size").name+"</td><td class='ttval'>"+roundOff(d.size)+"</td></tr>";
                        }
                        content += "<tr><td class='tthead'>"+o.getRowDisplayNames().get("detail").name+"</td><td class='ttval'>"+d.point+"</td></tr>";
                        if(o.getRowDisplayNames().get("color") && d.color){
                            content += "<tr><td class='tthead'>"+o.getRowDisplayNames().get("color").name+"</td><td class='ttval'>"+d.color+"</td></tr>";
                        }
                        //content += "<tr><td class='tthead'>Z-Axis</td><td class='ttval'>"+o.getTimeArray()[d.time]+"</td></tr>";
                         content += "</table>";
                        tooltip.html(content);
                        tooltip.attr('class', 'd3-tip');
                    }

                    var dotElement;
                    var dotEnter;
                    var dot;
                    dotElement = svg.attr("class", "dots")
                        .selectAll(".dot")
                        .data(interpolateData(1));
                    dotEnter = dotElement.enter().append("g");
                    drawCircles();
                    dot.call(position).sort(order);

                    function drawCircles(){
                        dot = dotEnter.append("circle")
                            /*.attr("id", function (d) {
                                return d.row;
                            })*/
                            .attr("class", function(d) { return "dot"; })
                            .style("opacity", 0.7)
                            .style("fill", function(d, i) { return colorScale(color(d)); })
                            .on("mouseover", function(d) {
                                tooltipContent(d);
                                return tooltip.style("visibility", "visible");
                            })
                            .on("mousemove", function(d) {
                                tooltipContent(d);
                                return tooltip.style("top", (d3.event.pageY - 10) + "px").style("left", (d3.event.pageX + 10) + "px");
                            })
                            .on("mouseout", function(d) {
                                return tooltip.style("visibility", "hidden");
                            })
                            .on("click", function(d){
                                //sliderVal = $("#slider_"+cId).val();
                                var oMarkingService = o.getMarkingService();
                                var selectedItems = o.getSelectedItems();
                                oMarkingService.clearMarksForDataLayout(oDataLayout);
                                oMarkingService.setMark(oDataLayout, datamodelshapes.Physical.DATA, d.row, d.col);
                                o._publishMarkEvent(oDataLayout);
                                //o.setTToggle(sliderVal);
                                $(this).parent().children().removeClass("mark");
                                $(this).addClass("mark");
                                selectedItems.set(d.row, d.col);
                                return tooltip.style("visibility", "hidden");
                            });
                    }

                    //Add text on each circle
                    if(o.getDisplayLabel() === "On"){
                        dotEnter.selectAll('g text').remove();
                        dotEnter.append("text").call(positionText);
                    }

                    // Add a title.
                    dot.append("title")
                        .text(function(d) { return d.name; });

                    // Add an overlay for the year label.
                    var box = label.node().getBBox();

                    var i=1;
                    var playing = false;
                    var duration = parseInt(durationValue) * 1000;
                    var tSlice = parseInt(duration/(o.getTArray().length));
                    var remaining = o.getTArray().length + 1;
                    var delayInMilliseconds = 300; //1 second
                    $("#play_"+cId).click(function() {
                        if(playing === false) {
                            if (o.getTToggle() === o.getTimeArray().length){
                                $("#slider_"+cId).val(1);
                                setTimeout(function() { 
                                    startPlaying();
                                    }, delayInMilliseconds);
                                }
                            else {
                                startPlaying();
                            }    
                        } else {
                            pausePlaying();
                        }
                    });

                    //slider
                    $("#slider_"+cId).ready(function() {
                        $("#slider_"+cId).change(function(){
                            //console.log("Slider Value: "+$(this).val());
                            //$("circle").removeClass();
                            o.setTToggle( $("#slider_"+cId).val());
                            displayYear($(this).val());
                        });
                    });
                    

                    

                    function startPlaying() {
                        playing = true;
                       // 
                                
                        $("#playText_"+cId).parent().removeClass("play_button");
                        $("#playText_"+cId).parent().addClass("pause_button");
                        
                        // Start a transition that interpolates the data based on year.
                        var start = o.getTToggle() >= o.getTimeArray().length ? 1 : parseInt(o.getTToggle())+1;
                        remaining = o.getTArray().length - o.getTArray().indexOf(start) + 1;
                        svg.transition()
                            .duration(tSlice * remaining)
                            //.delay(function(d, i) {return 15; })
                            .ease("linear")
                            .tween("year", function() {return tweenYear(start, o.getTimeArray().length) })
                            .each("end", stopPlaying);
                        //$("#slider_"+cId).prop("disabled", true);
                    }

                    function pausePlaying() {
                        playing = false;
                        $("#playText_"+cId).parent().removeClass("pause_button");
                        $("#playText_"+cId).parent().addClass("play_button");
                        svg.transition().duration(0);
                        o.setTToggle( $("#slider_"+cId).val());
                        //$("#slider_"+cId).prop("disabled", true);
                    }

                    function stopPlaying() {
                        playing = false;
                        $("#playText_"+cId).parent().removeClass("pause_button");
                        $("#playText_"+cId).parent().addClass("play_button");
                        svg.transition().duration(0);
                        o.setTToggle(o.getTimeArray().length);
                        $("#slider_"+cId).val(o.getTimeArray().length);
                        //$("#slider_"+cId).prop("disabled", false);
                    }

                    // Positions the dots based on data.
                    function position(dot) {
                        dot.attr("cx", function(d) {
                            if(xscale(x(d)))
                                return xscale(x(d));
                        })
                        .attr("cy", function(d) {
                            if(yscale(y(d)))
                                return yscale(y(d));
                        })
                        .attr("r", function(d) {
                            if(radiusScale(radius(d) > 0))
                                return radiusScale(radius(d));
                            else
                                return 0;
                        })
                        .attr("data-row", function(d) { return d.row; });
                        var selectedItems = o.getSelectedItems();
                        $("circle").parent().children().removeClass("mark");
                        for(let row of selectedItems.keys()){
                            $("circle[data-row='"+row+"']").addClass("mark");
                        }
                    }

                    //Positions the text for each dot
                    function positionText(dotEnter) {
                        dotEnter.attr("dx", function(d) {
                            if(xscale(x(d)))
                                return xscale(x(d));
                        })
                        .attr("dy", function(d) {
                            if(yscale(y(d)))
                                return yscale(y(d))-radiusScale(radius(d)+5);
                        })
                        .text(function(d){if(xscale(x(d)) && yscale(y(d))) return d.point;})
                        .style("text-anchor", "middle")
                        .style("opacity", .7);
                    }

                    // Defines a sort order so that the smallest dots are drawn on top.
                    function order(a, b) {
                        return radius(b) - radius(a);
                    }

                    // Tweens the entire chart by first tweening the year, and then the data.
                    // For the interpolated dacta, the dots and label are redrawn.
                    function tweenYear(start, stop) {
                        var year = d3.interpolateNumber(start, stop);
                        //console.log("Year",+year)
                        return function(t) { displayYear(year(t)); };
                    }

                    // Updates the display to show the specified year.
                    function displayYear(year) {
                        //dotElement.selectAll('circle').remove();
                        dotEnter.selectAll('g text').remove();
                        //drawCircles();
                        dot.data(interpolateData(year), key).call(position).sort(order);
                        if(o.getDisplayLabel() === "On"){
                            dotEnter.data(interpolateData(year), key).append("text").call(positionText);
                        }
                        //console.log("Display Year: "+ o.getTimeArray()[year]);
                        label.text(o.getTimeArray()[Math.round(year)-1]);
                        
                        i++;
                        //console.log("i",+i);
                        if ((i%25) == 0) {
                            //console.log("i%25",+i%25);
                            $("#slider_"+cId).val(year);
                        }
                    }

                    // Interpolates the dataset for the given (fractional) year.
                    function interpolateData(year) {
                        year = Math.round(year);
                        var result = [];
                        data.map(function(a) {
                            a.colorValues[0].map(function(d){
                                var items =   {
                                    point: a.point,
                                    color: d.color,
                                    x_axis: interpolateValues(d.x_values, year),
                                    size: interpolateValues(d.size, year),
                                    y_axis: interpolateValues(d.y_values, year),
                                    row: interpolateValues(d.rows, year),
                                    col: interpolateValues(d.cols, year)
                                };
                                if(!(xScaleValue === "Logarithmic" && items.x_axis < 0) && !(yScaleValue === "Logarithmic" && items.y_axis < 0))
                                    result.push(items);
                            });
                        });
                        return result;
                    }

                    // Finds (and possibly interpolates) the value for the specified year.
                    function interpolateValues(values, year) {
                        var t = o.getTimeArray();
                        var val = t[year-1];
                        var a;
                        for (var i = 0; i < values.length; i++){
                            if(val === values[i][0]){
                                return values[i][1];
                            }
                        }
                    }
                };
            }
            finally {
                this._setIsRendered(true);
            }


        }

        /**
         * Called whenever new data is ready and this visualization needs to update.
         * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
         */
        MotionChartViz.prototype.render = function(oTransientRenderingContext) {
            // Note: all events will be received after initialize and start complete.  We may get other events
            // such as 'resize' before the render, i.e. this might not be the first event.

            this._render(oTransientRenderingContext);
            //this.renderLegend(oTransientRenderingContext);
            //this._buildSelectedItems(oTransientRenderingContext);
        };


        /**
         * Resize the visualization
         * @param {Object} oVizDimensions - contains two properties, width and height
         * @param {module:obitech-report/vizcontext#VizContext} oTransientVizContext the viz context
         */
        MotionChartViz.prototype.resizeVisualization = function(oVizDimensions, oTransientVizContext){
            var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
            this._render(oTransientRenderingContext);
        };

        /**
         * Re-render the visualization when settings changes
         */
        MotionChartViz.prototype._onDefaultSettingsChanged = function(){
            var oTransientVizContext = this.assertOrCreateVizContext();
            var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
            this.render(oTransientRenderingContext);
            this._setIsRendered(true);
        };


        MotionChartViz.prototype._publishMarkEvent = function (oDataLayout, eMarkContext) {

            $(function() {
                $(".oj-dvt-datatip").css("visibility", "hidden");
            });

            try {
                // Create the marking event
                var markingEvent = new interactions.MarkingEvent(this.getID(), this.getViewName(), oDataLayout, null, eMarkContext);
                var eventRouter = this.getEventRouter();
                if (eventRouter) {
                    // Publish the event to listeners
                    eventRouter.publish(markingEvent);
                }
            }
            catch (e) {
                console.log("Error during mark", e);
            }
        };


        /**
         * Override to add in options to the context menu
         *
         * @param {module:obitech-report/vizcontext#VizContext} oTransientVizContext the viz context
         * @param {string} sMenuType The menu type associated with the context menu being populated
         * @param {Array} The array of resulting menu options
         * @param {module:obitech-appservices/contextmenu} contextmenu The contextmenu namespace object (used to reduce dependencies)
         * @param {object} evtParams The entire 'params' object that is extracted from client evt
         * @param {object} oTransientRenderingContext the current transient rendering context
         */
        MotionChartViz.prototype._addVizSpecificMenuOptions = function(oTransientVizContext, sMenuType, aResults, contextmenu, evtParams, oTransientRenderingContext){
            aResults.shift();
            MotionChartViz.superClass._addVizSpecificMenuOptions.call(this, oTransientVizContext, sMenuType, aResults, contextmenu, evtParams, oTransientRenderingContext);
            if (sMenuType === euidef.CM_TYPE_VIZ_PROPS) {
                // Set up the column context for the last column in the ROWS bucket
                var oColumnContext = this.getDrillPathColumnContext(oTransientVizContext, datamodelshapes.Logical.ROW);

                // Set up events
                /*if(!this.isViewOnlyLimit()){
                    this._addFilterMenuOption(oTransientVizContext, aResults, null, null, oTransientRenderingContext);
                    this._addRemoveSelectedMenuOption(oTransientVizContext, aResults, null, null, oTransientRenderingContext);
                    //this._addDrillMenuOption(oTransientVizContext, aResults, null, null, oColumnContext, oTransientRenderingContext);
                    //this._addLateralDrillMenuOption(oTransientVizContext, aResults);
                }*/
            }
        };

        MotionChartViz.prototype._addVizSpecificPropsDialog = function(oTabbedPanelsGadgetInfo){

            //var options = this.getViewConfig() || {};
            //this._fillDefaultOptions(options, null);
            //this._addLegendToVizSpecificPropsDialog(options, oTabbedPanelsGadgetInfo);

            this.doAddVizSpecificPropsDialog(this, oTabbedPanelsGadgetInfo);
            MotionChartViz.superClass._addVizSpecificPropsDialog.call(this, oTabbedPanelsGadgetInfo);

        };

        /**
         * TODO: Legend should take care of this
         * Given an options / config object, configure it with default options for the visualization.
         *
         * @param {object} oOptions the options
         * @param {module:obitech-framework/actioncontext#ActionContext} oActionContext The ActionContext instance associated with this action
         * @protected
         */
        MotionChartViz.prototype._fillDefaultOptions = function (oOptions/*, oActionContext*/) {
            if (!jsx.isNull(oOptions) && !jsx.isNull(oOptions.legend))
                return;

            // Legend
            oOptions.legend = jsx.defaultParam(oOptions.legend, {});
            oOptions.legend.rendered = jsx.defaultParam(oOptions.legend.rendered, "on");
            oOptions.legend.position = jsx.defaultParam(oOptions.legend.position, "auto");

            this.getSettings().setViewConfigJSON(dataviz.SettingsNS.CHART, oOptions);
        };

        MotionChartViz.prototype.doAddVizSpecificPropsDialog = function (oTransientRenderingContext, oTabbedPanelsGadgetInfo) {
            jsx.assertObject(oTransientRenderingContext, "oTransientRenderingContext");
            jsx.assertInstanceOf(oTabbedPanelsGadgetInfo, gadgets.TabbedPanelsGadgetInfo, "oTabbedPanelsGadgetInfo", "obitech-application/gadgets.TabbedPanelsGadgetInfo");

            var oDataModel = this.getRootDataModel();

            this.setTabInfo(oTabbedPanelsGadgetInfo);
            var viewConfig = this.getViewConfig() || {};
            var options = this.getViewConfig() || {};
            //this._fillDefaultOptions(options, oTransientRenderingContext.get(viz.ContextProperty.ACTION_CONTEXT));
            this._fillDefaultOptions(options, null);
            /*var valuePanel = gadgetdialog.forcePanelByID(oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_VALUE);
            this.setValuePanel(valuePanel);*/
            var generalPanel = gadgetdialog.forcePanelByID(oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_GENERAL);

            var oGadgetFactory = this.getGadgetFactory();
            var oDuration = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.duration);
            var oDurationGadgetInfo = oGadgetFactory.createGadgetInfo("durationGadget", 'Duration(seconds)', 'Duration', oDuration);
            generalPanel.addChild(oDurationGadgetInfo);

            var xScale = [];
            xScale.push(new gadgets.OptionInfo('Linear','Linear'));
            xScale.push(new gadgets.OptionInfo('Logarithmic','Logarithmic'));
            var oXScaleGVP = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.xScale);
            var oXScaleGadgetInfo = new gadgets.TextSwitcherGadgetInfo("xScaleGadget", 'X-Scale', 'X-Scale', oXScaleGVP, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE, false, xScale);
            generalPanel.addChild(oXScaleGadgetInfo);

            var yScale = [];
            yScale.push(new gadgets.OptionInfo('Linear','Linear'));
            yScale.push(new gadgets.OptionInfo('Logarithmic','Logarithmic'));
            var oYScaleGVP = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.yScale);
            var oYScaleGadgetInfo = new gadgets.TextSwitcherGadgetInfo("yScaleGadget", 'Y-Scale', 'Y-Scale', oYScaleGVP, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE, false, yScale);
            generalPanel.addChild(oYScaleGadgetInfo);

            //DisplayLabel
            var displayLabel = [];
            displayLabel.push(new gadgets.OptionInfo('On','On'));
            displayLabel.push(new gadgets.OptionInfo('Off','Off'));
            var oDisplayLabelGVP = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.displayLabel);
            var oDisplayLabelGadgetInfo = new gadgets.TextSwitcherGadgetInfo("displayLabelGadget", 'Display Label', 'Display Label', oDisplayLabelGVP, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE, false, displayLabel);
            generalPanel.addChild(oDisplayLabelGadgetInfo);

            if (MotionChartViz.superClass.doAddVizSpecificPropsDialog)
                MotionChartViz.superClass.doAddVizSpecificPropsDialog.apply(this, arguments);
        };

        MotionChartViz.prototype._handlePropChange = function (sGadgetID, oPropChange, oViewSettings, oActionContext){
            var updateSettings = MotionChartViz.superClass._handlePropChange.call(this, sGadgetID, oPropChange, oViewSettings, oActionContext);
            if (updateSettings) {
                return updateSettings; // super handled it
            }
            /*var conf = oViewSettings.getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
            if(this._handleLegendPropChange(conf, sGadgetID, oPropChange, oViewSettings, oActionContext)){
                updateSettings = true;
            }*/

            // Allow the super class an attempt to handle the changes
            var conf = oViewSettings.getViewConfigJSON(dataviz.SettingsNS.CHART) || {};

            if (sGadgetID === "durationGadget") {
                if (jsx.isNull(conf.styleDefaults))
                {
                    conf.styleDefaults = {};
                }
                this.setDuration(oPropChange.value);
                updateSettings = true;
            }

            if (sGadgetID === "xScaleGadget") {
                if (jsx.isNull(conf.styleDefaults))
                {
                    conf.styleDefaults = {};
                }
                this.setXScale(oPropChange.value);
                updateSettings = true;
            }

            if (sGadgetID === "yScaleGadget") {
                if (jsx.isNull(conf.styleDefaults))
                {
                    conf.styleDefaults = {};
                }
                this.setYScale(oPropChange.value);
                updateSettings = true;
            }

            if (sGadgetID === "displayLabelGadget") {
                if (jsx.isNull(conf.styleDefaults))
                {
                    conf.styleDefaults = {};
                }
                this.setDisplayLabel(oPropChange.value);
                updateSettings = true;
            }


            /*$('#slider').val(1);
            this.setTToggle(1);*/
            return updateSettings;
        };

        /**
         * Builds the list of selected items
         * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext - The rendering context
         */
        MotionChartViz.prototype._buildSelectedItems = function(oTransientRenderingContext){
            var oViz = this;
            var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
            var oMarkingService = this.getMarkingService();

            function fMarksReadyCallback() {
                oViz.clearSelectedItems();
                var aSelectedItems = oViz.getSelectedItems();
                //var selectedMap = new Map();

                if(!oViz.isStarted()) {
                    return;
                }
                oMarkingService.traverseDataEdgeMarks(oDataLayout, function (nRow, nCol) {
                    //aSelectedItems.push(nRow + ':' + nCol);
                    aSelectedItems.set(nRow, nCol);
                });
                console.log("selected items mocha: ");
                for(let row of aSelectedItems.keys())
                    console.log(row);
                //var first = aSelectedItems.keys().next().value;
                $("circle").parent().children().removeClass("mark");
                for(let row of aSelectedItems.keys()){
                    $("circle[data-row='"+row+"']").addClass("mark");
                }
                //oViz._render(oTransientRenderingContext);
            }
            oMarkingService.getUpdatedMarkingSet(oDataLayout, marking.EMarkOperation.MARK_RELATED, fMarksReadyCallback);
        };


        /**
         * React to marking service highlight events
         */
        MotionChartViz.prototype.onHighlight = function(){
            var oTransientVizContext = this.assertOrCreateVizContext();
            var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
            this._buildSelectedItems(oTransientRenderingContext);
        };

        /**
         * Override _doInitializeComponent in order to subscribe to events
         */
        MotionChartViz.prototype._doInitializeComponent = function() {
            MotionChartViz.superClass._doInitializeComponent.call(this);

            //this.subscribeToEvent(events.types.DEFAULT_SETTINGS_CHANGED, this._onDefaultSettingsChanged, "**");
            this.subscribeToEvent(events.types.INTERACTION_HIGHLIGHT, this.onHighlight, this.getViewName() + "." + events.types.INTERACTION_HIGHLIGHT);

            //this.initializeLegendAndVizContainer();
        };


        /**
         * Factory method declared in the plugin configuration
         * @param {string} sID Component ID for the visualization
         * @param {string=} sDisplayName Component display name
         * @param {string=} sOrigin Component host identifier
         * @param {string=} sVersion
         * @returns {module:com-company-motionchartViz/motionchartViz.MotionChartViz}
         * @memberof module:com-company-motionchartViz/motionchartViz
         */
        motionChart.createClientComponent = function (sID, sDisplayName, sOrigin) {
            // Argument validation done by base class
            return new MotionChartViz(sID, sDisplayName, sOrigin, MotionChartViz.VERSION);
        };

        return motionChart;
    });