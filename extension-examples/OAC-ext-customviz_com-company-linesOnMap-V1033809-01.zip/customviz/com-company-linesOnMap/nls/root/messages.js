define({
    "LINESONMAP_DISPLAY_NAME": "LinesOnMap Plugin",
    "LINESONMAP_SHORT_DISPLAY_NAME": "LinesOnMap Plugin",
    "LINESONMAP_CATEGORY":"LinesOnMap Plugin",
	"LINESONMAP_SRC": "Source (Lat & Long)",
	"LINESONMAP_DEST": "Dest (Lat & Long)",
	"LINESONMAP_LABEL": "Line Labels",
	"LINESONMAP_COLOR": "of Lines",
	"LINESONMAP_SIZE": "Thickness"
});