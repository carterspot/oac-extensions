define(['jquery',
        'obitech-framework/jsx',
        'obitech-report/datavisualization',
        'obitech-reportservices/datamodelshapes',
		'obitech-reportservices/data',
        'obitech-reportservices/events',
		'obitech-reportservices/interactionservice',
		'obitech-reportservices/markingservice',
		'obitech-application/gadgets',	
		'obitech-report/visualization',
		'obitech-report/gadgetdialog',
		'obitech-application/bi-definitions',
        'obitech-application/extendable-ui-definitions',		
        'obitech-appservices/logger',
        'ojL10n!com-company-linesOnMap/nls/messages',
        'obitech-framework/messageformat',
        'skin!css!com-company-linesOnMap/linesOnMapstyles',
		'obitech-map/omaps_api_va',
		'obitech-map/va_maps'],
        function($,
                 jsx,
                 dataviz,
                 datamodelshapes,
				 data,
                 events,
				 interactions,
				 marking,
				 gadgets,
				 viz,
				 gadgetdialog,
				 definitions,
				 euidef,
                 logger,
                 messages) {
   "use strict";

   var MODULE_NAME = 'com-company-linesOnMap/linesOnMap';

   //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   jsx.assertAllNotNullExceptLastN(arguments, "linesOnMap.js arguments", 2);

   var _logger = new logger.Logger(MODULE_NAME);
   var orientation = 'Straight';
   var markerStyle = 'Yes';
   var wrapAround = 'No';
   var mapKey = '';
   var copyRight = null;
   var map = null;
   var flowsLayer = null;
   var countriesLayer = null;
   var arrowLayer = null;


   // The version of our Plugin
   LinesOnMap.VERSION = "1.0.0";

   /**
    * The implementation of the linesOnMap visualization.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @extends {module:obitech-report/visualization.Visualization}
    * @memberof module:com-company-linesOnMap/linesOnMap#
    */



	function fNum(num){
		num = Number(num);
		if (num % 1 != 0){
		 if (Math.abs(num) <1) 
			num = Math.round(num*1000)/1000;
		 else 
			num = Math.round(num*100)/100;
		}
		return num.toLocaleString();
	}
	
	function convertRange(inputArr){
		var outputX = [];
		if(inputArr.length==1){
			outputX.push(3);
			return outputX;
		}
		var xMax = 10;
		var xMin = 3;
		
		var yMax = Math.max.apply(Math, inputArr);		
		var yMin = Math.min.apply(Math, inputArr);

		for(var i=0;i<inputArr.length;i++){
			var new_value = ( (inputArr[i] - yMin) / (yMax - yMin) ) * (xMax - xMin) + xMin;			
		    outputX.push(new_value);			
		}
		return outputX;
	}
	
   function rendermap(elContainer,odata,config)
   {
	   var mapType = config.background;
       var baseURL  = "http://"+document.location.host+"/mapviewer";
       var center = new OM.geometry.Point(20,50,8307);
       map = new OM.Map(elContainer,
           {mapviewerURL: baseURL}) ;
		if(config.wrapAround == 'Yes'){
			map.enableMapWraparound(true);	
		}else{
			map.enableMapWraparound(false);
		}
	   var tilelayer;
	   
	   /**********tile layer code ************/
	   
	  if ( mapType == 'OpenStreetMap')
      {
		tilelayer = new OM.layer.OSMTileLayer("osm.maps");
        var copyRightOSM = new OM.control.CopyRight(
            {anchorPosition:6,
            textValue:'&copy; <a href="http://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
            fontSize:10,fontFamily:'Helvetica Neue,Arial',fontColor:'black'});
        // remove any existing copyRight and add new one 
        map.removeMapDecoration(copyRight);
        map.addMapDecoration(copyRightOSM);
        copyRight = copyRightOSM;
      }
	  else if ( mapType == 'Google Maps')
	  {
		  //var conf = this.getSettings().getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
			var conf_google_maps = 
			{
			mapTypeList:"OM.layer.GoogleTileLayer.TYPE_ROAD;OM.layer.GoogleTileLayer.TYPE_ROAD;OM.layer.GoogleTileLayer.TYPE_SATELLITE;OM.layer.GoogleTileLayer.TYPE_SHADED;OM.layer.GoogleTileLayer.TYPE_HYBRID",
			mapTypeVisible:true,
			libURL:"https://maps.googleapis.com/maps/api/js?",
			key:""
			};
		  conf_google_maps["key"]  = mapKey;
		  tilelayer = new OM.layer.GoogleTileLayer("google.maps", conf_google_maps);
          map.removeMapDecoration(copyRight);
	  }
	  else if ( mapType == 'Carto Positron')
	  {
        var copyRightCarto = new OM.control.CopyRight(
            {anchorPosition:6,
            textValue:'&copy; <a href="http://cartodb.com/attributions" target="_blank">Carto</a> free basemaps <a href="https://carto.com/legal" target="_blank">terms</a>. &copy; <a href="http://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors', fontSize:10,fontFamily:'Helvetica Neue,Arial',fontColor:'black'});    
        
		  var conf_carto_maps={};
          conf_carto_maps.tileServerArray=[
          "http://a.basemaps.cartocdn.com/light_all", 
          "http://b.basemaps.cartocdn.com/light_all", 
          "http://c.basemaps.cartocdn.com/light_all", 
          "http://d.basemaps.cartocdn.com/light_all"];	

		  tilelayer = new OM.layer.OSMTileLayer("carto.light", conf_carto_maps.tileServerArray, ".png");
        // remove copyRight and add new one 
        map.removeMapDecoration(copyRight);
        map.addMapDecoration(copyRightCarto);
        copyRight = copyRightCarto;
      }
	  else if ( mapType == 'Carto Dark')
	  {
        var copyRightCarto = new OM.control.CopyRight(
        {anchorPosition:6,
        textValue:'&copy; <a href="http://cartodb.com/attributions" target="_blank">Carto</a> free basemaps <a href="https://carto.com/legal" target="_blank">terms</a>. &copy; <a href="http://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors', fontSize:10,fontFamily:'Helvetica Neue,Arial',fontColor:'black'});    
        
		  var conf_carto_maps={};
          conf_carto_maps.tileServerArray=[
          "http://a.basemaps.cartocdn.com/dark_all", "http://b.basemaps.cartocdn.com/dark_all", 
          "http://c.basemaps.cartocdn.com/dark_all", "http://d.basemaps.cartocdn.com/dark_all"];	
          
		  tilelayer = new OM.layer.OSMTileLayer("carto.dark", conf_carto_maps.tileServerArray, ".png");
        // remove copyRight and add new one 
        map.removeMapDecoration(copyRight);
        map.addMapDecoration(copyRightCarto);
        copyRight = copyRightCarto;
      }      
	  else if ( mapType == 'Oracle Maps')
      {
		tilelayer = new OM.layer.ElocationTileLayer("oracle.maps");
        map.removeMapDecoration(copyRight);
      }
	  else if (mapType == 'None')
	  {
		tilelayer = new OM.layer.OSMTileLayer("osm.maps");
		map.removeMapDecoration(copyRight);
		copyRight = null;
		tilelayer.setVisible(false);
	  }		  
	   /**********tile layer code ends ******/
	    map.addLayer(tilelayer) ;		   

       flowsLayer = new OM.layer.VectorLayer("connections",{def:{type:OM.layer.VectorLayer.TYPE_LOCAL}});
       function endMakerfunc(fill_color){
		var endMarker00 = new OM.style.Marker({
           vectorDef: [{
              shape: {type: "path", coords: [[0,0,20,10,0,20,10,10,0,0]]},
              style: {fill: fill_color,strokeThickness:0.4, stroke:"#cc9999"}
           }],
           width: 20,
           height:20,
           xOffset:10,
           yOffset:10
		});
		return endMarker00;   
	   }
       for (var i=0;i<odata.length; i++){
           var fid = i;
           var oPoint = new OM.geometry.Point(odata[i]["source"].long,odata[i]["source"].lat,8307);
           var dPoint = new OM.geometry.Point(odata[i]["destination"].long,odata[i]["destination"].lat,8307);
		   
		   console.log(odata[i]["source"].long + "\t" + odata[i]["source"].lat + "\n");
		   console.log(odata[i]["destination"].long + "\t" + odata[i]["destination"].lat + "\n");
		   
		   var line;
			   if(config.orientation == "Geodesic"){
				   if((oPoint["coordinates"][0] == dPoint["coordinates"][0])){
						oPoint["coordinates"][0] +=  0.000001;
						line = OM.util.GeomUtil.createGreatCircle(oPoint,dPoint);
					}else{
						console.log(JSON.stringify(oPoint) + "\t" + JSON.stringify(dPoint));
						line = OM.util.GeomUtil.createGreatCircle(oPoint,dPoint);				   
				   }
			   }else if(config.orientation == "Straight"){
				   var arr = [];
					if((oPoint["coordinates"][0] == dPoint["coordinates"][0])){
						odata[i]["source"].lat +=  0.000001;
					}				   
				   arr.push(odata[i]["source"].long);arr.push(odata[i]["source"].lat);
				   arr.push(odata[i]["destination"].long);arr.push(odata[i]["destination"].lat);
				   line = new OM.geometry.LineString(arr,8307);			   
			   }
		   var hoverStyle;
		   if(config.markerStyle == 'Yes'){
				hoverStyle = new OM.style.Line({fillWidth:3, fill:odata[i]["fill_color"], fillWidth:odata[i]["actual_size"],endMarker:endMakerfunc(odata[i]["fill_color"])});			   
		   }else{
				hoverStyle = new OM.style.Line({fillWidth:3, fill:odata[i]["fill_color"], fillWidth:odata[i]["actual_size"]});			   
		   }
		   var labelString = '';
		   for(var k=0;k< odata[i]["labels"].length;k++){
			   labelString = labelString.concat(odata[i]["labels"][k] + "\n");
		   }
		   labelString = labelString.slice(0,labelString.length-1);
           var lineFeature = new OM.Feature(fid, line, {attributes :{"COLORS":odata[i]["color"], "SIZE":odata[i]["size"],"LABELS":labelString}});
		   lineFeature["renderingStyle"] = hoverStyle;
           flowsLayer.addFeature(lineFeature);
       }
       flowsLayer.setBringToTopOnMouseOver(false);
       flowsLayer.setToolTipCustomizer(getTooltip);
       flowsLayer.enableInfoWindow(false);
       map.addLayer(flowsLayer);
       map.setMapCenter(center);
       map.setMapZoomLevel(1) ;
	   
      // show only the +/- zoom buttons. i.e. {style:3}
	   var navigationPanelBar = new OM.control.NavigationPanelBar({style:3,anchorPosition:4});
	   map.addMapDecoration(navigationPanelBar);	   
       map.init() ;
   }
	function getTooltip(feature)
	{
		var res='';
		if(feature.getAttributes()["LABELS"] != "NONE"){
			res = res.concat(feature.getAttributes()["LABELS"]);
			res = res.concat("\n");
		}
		if(feature.getAttributes()["COLORS"] != "NONE"){
			//res = res.concat("Color(");
			res = res.concat(feature.getAttributes()["COLORS"]);
			res = res.concat("\n");
		}		
		if(feature.getAttributes()["SIZE"] != "NONE"){
			//res = res.concat("Size(");
			res = res.concat(feature.getAttributes()["SIZE"]);

		}				
		//return feature.getAttributes()["LABELS"] + "\nColor by "+ feature.getAttributes()["COLORS"]+ "\nSize by " +feature.getAttributes()["SIZE"];
		return res;
	}

	
	function parseGrammar(row_count,oDataLayoutHelper,oDataLayout){
		var result = {"row":[],"glyph":[],"detail":[],"color":[],"size":[],"detail":[]};
		
		for(var i=0;i<row_count;i++){
			var key = oDataLayoutHelper.getLogicalEdgeName(datamodelshapes.Physical.ROW,i);
			if(key == "detail"){
				result[key].push(i+"," + oDataLayout.getLayerMetadata(datamodelshapes.Physical.ROW,i, data.LayerMetadata.LAYER_DISPLAY_NAME));				
			}else if(key == "color" || key == "size"){
				result[key].push(oDataLayout.getLayerMetadata(datamodelshapes.Physical.ROW,i, data.LayerMetadata.LAYER_DISPLAY_NAME)+"," + i);
			}
			else{
				result[key].push(i);
			}
		}
		
		return result;
	}

	 function LinesOnMap(sID, sDisplayName, sOrigin, sVersion) {
		  // Argument validation done by base class
		  LinesOnMap.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);
		  
      //this.copyRight = null;
	  
	  this.Config ={
	   background: 'Oracle Maps', //'Oracle Maps is set as default', 
	   imageurl:'',
	   mapkey:'',
	   orientation:'Straight',
	   markerStyle: 'Yes',
	   zoomtotheme:false,
	   repeatbackground:false
      };

	  this._saveSettings = function() {
         this.getSettings().setViewConfigJSON(dataviz.SettingsNS.CHART, this.Config);
      };
	  
	  this.loadConfig = function (){
		 var conf = this.getSettings().getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
		 if (conf.background) this.Config.background=conf.background;
		 if (conf.imageurl) this.Config.imageurl=conf.imageurl;
         // mapkey will conatin either the Google key or the mapbox access token   
		 if (conf.mapkey) this.Config.mapkey=conf.mapkey;
		 if (conf.zoomtotheme) this.Config.zoomtotheme=conf.zoomtotheme;
		 if (conf.orientation) this.Config.orientation=conf.orientation;	
		 if (conf.markerStyle) this.Config.markerStyle=conf.markerStyle;			 
		 if (conf.repeatbackground) this.Config.repeatbackground=conf.repeatbackground;
	  }
      	  
	  this.setBackground = function (o){
		this.Config.background = o;
		this._saveSettings();		
		};
		  
		  
		 this.getOrientation = function(){
			return(orientation);			
		 };
		
		 this.setChartOrientation = function (o){
			this.Config.orientation = o;	
		    this._saveSettings();				
		 };	  

		 this.getmarkerStyle = function(){
			return(markerStyle);
		 };
		
		 this.setmarkerStyle = function (o){
			this.Config.markerStyle = o;
  		   this._saveSettings();				
		 };	

		 this.getWrapAround = function(){
			return(wrapAround);
		 };
		
		 this.setWrapAround = function (o){
			this.Config.wrapAround = o;	
		this._saveSettings();				
		 };	

		 this.getmapKey = function(){
			return(mapKey);
		 };

		this.setMapKey = function (o){
			this.Config.mapKey = o;	
		this._saveSettings();				
		};  		 
	 };
	jsx.extend(LinesOnMap, dataviz.DataVisualization);
   /**
    * Called whenever new data is ready and this visualization needs to update.
    * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
    */

   var isNumber = function (n) {
   return !isNaN(parseFloat(n)) && isFinite(n);
   };
	
	
   LinesOnMap.prototype.generateData = function (oDataLayout,oTransientRenderingContext) {
       var oDataModel = this.getRootDataModel();
       if(!oDataModel || !oDataLayout){
           return;
       }
	   
	   var oDataLayoutHelper = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT_HELPER);	   
       var aAllMeasures = oDataModel.getColumnIDsIn(datamodelshapes.Physical.DATA);
       var nMeasures = aAllMeasures.length;
       var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
       var nRowLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
       var nCols = oDataLayout.getEdgeExtent(datamodelshapes.Physical.COLUMN);
       var nColLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.COLUMN);
       var aAllMeasures = this.getRootDataModel().getColumnIDsIn(datamodelshapes.Physical.DATA);
	   
	   
       // Color
       var oColorContext = this.getColorContext(oTransientRenderingContext);
       var oColorInterpolator = this.getCachedColorInterpolator(oTransientRenderingContext, datamodelshapes.Logical.COLOR);
	   

       var hasCategoryOrColor = function () {
          return nLastLayer >= 0;
       };
       
       // Measure labels layer
       var isMeasureLabelsLayer = function (eEdgeType, nLayer) {
          return oDataLayout.getLayerMetadata(eEdgeType, nLayer, data.LayerMetadata.LAYER_ISMEASURE_LABELS);
       };
       
       // Last layer: we get the data values and colors from this layer
       var getLastNonMeasureLayer = function (eEdge) {
          var nLayerCount = oDataLayout.getLayerCount(eEdge);
          for (var i = nLayerCount - 1; i >= 0; i--) {
             if (!isMeasureLabelsLayer(eEdge, i))
                return i;
          }
          return -1;
       };
       
       var nLastEdge = datamodelshapes.Physical.COLUMN; // check column edge first
       
       var nLastLayer = getLastNonMeasureLayer(datamodelshapes.Physical.COLUMN);
       if (nLastLayer < 0) { // if not on column edge look on row edge
          nLastEdge = datamodelshapes.Physical.ROW;
          nLastLayer = getLastNonMeasureLayer(datamodelshapes.Physical.ROW);
       }
	   
       var aOutput = [];
	   var sizes = [];
	   var row_count = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
	   var grammar = parseGrammar(row_count,oDataLayoutHelper,oDataLayout);
	   
       var lt, lg, sValue;
       for(var i=0;i<nRows;i++){
           var lineObj={};
           var source = {};
           var destination = {};
		   
		   if(grammar["row"].length != 0){
			  source["lat"]= Number(oDataLayout.getValue(datamodelshapes.Physical.ROW,grammar["row"][0],i));
			  source["long"]= Number(oDataLayout.getValue(datamodelshapes.Physical.ROW,grammar["row"][1],i));			  
		   }
		   
		   if(grammar["glyph"].length != 0){
			  destination["lat"]= Number(oDataLayout.getValue(datamodelshapes.Physical.ROW,grammar["glyph"][0],i));
			  destination["long"]= Number(oDataLayout.getValue(datamodelshapes.Physical.ROW,grammar["glyph"][1],i));			  
		   }
		   
		   if(grammar["color"].length != 0){
			   var arr = grammar["color"][0].split(',');
			   var str = arr[0] + " (color) : ";
			   if(isNumber(oDataLayout.getValue(datamodelshapes.Physical.ROW,Number(arr[1]),i))){
				 str = str.concat(fNum(oDataLayout.getValue(datamodelshapes.Physical.ROW,Number(arr[1]),i)));   
			   }else{
				 str = str.concat(oDataLayout.getValue(datamodelshapes.Physical.ROW,Number(arr[1]),i));  
			   }
			   lineObj["color"] = str;
		   }else{
			   lineObj["color"]= "NONE";
		   }
		   
		   if(grammar["size"].length != 0){
			   var arr = grammar["size"][0].split(',');
			   var str = arr[0] + " (size) : " + fNum(oDataLayout.getValue(datamodelshapes.Physical.ROW,Number(arr[1]),i));
			   lineObj["size"] = str;
  		       sizes.push((oDataLayout.getValue(datamodelshapes.Physical.ROW,Number(arr[1]),i)));
		   }else{
			   lineObj["size"] = "NONE";
		   }
		   
		   if(grammar["detail"].length != 0){
			   var arr = [];
			   for(var j=0;j<grammar["detail"].length;j++){
				   var split = grammar["detail"][j].split(",");
				   //arr.push(split[1] + " : " + oDataLayout.getValue(datamodelshapes.Physical.ROW,Number(split[0]),i));
				   var str = split[1] + " : ";
				   if(isNumber(oDataLayout.getValue(datamodelshapes.Physical.ROW,Number(split[0]),i))){
					   str = str.concat(fNum(oDataLayout.getValue(datamodelshapes.Physical.ROW,Number(split[0]),i)));
				   }else{
					   str = str.concat(oDataLayout.getValue(datamodelshapes.Physical.ROW,Number(split[0]),i));
				   }
				   arr.push(str);
			   }
			   lineObj["labels"] = arr;
		   }else{
			   var arr=[];
			   arr.push("NONE");
			   lineObj["labels"] = arr;
		   }
		   
		   var color_value = this.getDataItemColorInfo(oDataLayoutHelper, oColorContext, oColorInterpolator, i, 0);	
		   lineObj["fill_color"] = color_value.sColor;
           lineObj["source"] = source;
           lineObj["destination"] = destination;
           aOutput.push(lineObj);
       }

	   var result;
	   if(sizes.length != 0){
		 result  = convertRange(sizes);		   
	   }else{
		   result = Array(aOutput.length).fill(3);
	   }

	   for(var i=0;i<result.length;i++){
		   aOutput[i]["actual_size"] = result[i];
	   }
	   console.log(aOutput);
       return aOutput;
   };
   LinesOnMap.prototype.render = function(oTransientRenderingContext) {
      try {
         // Note: all events will be received after initialize and start complete.  We may get other events
         // such as 'resize' before the render, i.e. this might not be the first event.

         // Retrieve the data object for this visualization
         var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);

         // Determine the number of records available for rendering on ROW
         // Because we specified that Category should be placed on ROW in the data model handler,
         // this returns the number of rows for the data in Category.
         var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);

         // Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
         // but may be used to render.
		 this.loadConfig();
         var elContainer = this.getContainerElem();
		 console.log(orientation + "\t" + markerStyle + "\t" + this.Config);
         var data = this.generateData(oDataLayout,oTransientRenderingContext);
         rendermap(elContainer,data,this.Config);
         //$(elContainer).html(messages.TEXT_MESSAGE.format("LinesOnMap Plugin", "" + nRows));
      }
      finally {
         this._setIsRendered(true);
      }
    };
	
	LinesOnMap.prototype._addVizSpecificPropsDialog = function(oTabbedPanelsGadgetInfo){
	 
	   this.doAddVizSpecificPropsDialog(this, oTabbedPanelsGadgetInfo);
	   LinesOnMap.superClass._addVizSpecificPropsDialog.call(this, oTabbedPanelsGadgetInfo);
	   
	};	


	LinesOnMap.prototype.doAddVizSpecificPropsDialog = function (oTransientRenderingContext, oTabbedPanelsGadgetInfo) {
		  jsx.assertObject(oTransientRenderingContext, "oTransientRenderingContext");
		  jsx.assertInstanceOf(oTabbedPanelsGadgetInfo, gadgets.TabbedPanelsGadgetInfo, "oTabbedPanelsGadgetInfo", "obitech-application/gadgets.TabbedPanelsGadgetInfo");

		  var options = this.getViewConfig() || {};
		  //this._fillDefaultOptions(options, oTransientRenderingContext.get(viz.ContextProperty.ACTION_CONTEXT));
		  this._fillDefaultOptions(options, null);

		  var generalPanel = gadgetdialog.forcePanelByID(oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_GENERAL);

		  var orientVals = [];
		  orientVals.push(new gadgets.OptionInfo('Straight','Straight'));
		  orientVals.push(new gadgets.OptionInfo('Geodesic','Geodesic'));

		  var oOrientTypeGVP = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.orientation);
		  var oOrientTypeGadgetInfo = new gadgets.TextSwitcherGadgetInfo("orientTypeGadget", 'Line Type', 'Line Type', oOrientTypeGVP, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE, false, orientVals);
		  generalPanel.addChild(oOrientTypeGadgetInfo);

		  var oMarkerType = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.markerStyle);
		  var markerValues = [];
		  markerValues.push(new gadgets.OptionInfo('Yes','Yes'));
		  markerValues.push(new gadgets.OptionInfo('No','No'));	  
		 
		  var oOrientTypeMarkerInfo = new gadgets.TextSwitcherGadgetInfo("orientTypeGadget1", 'Show Arrows', 'Show Arrows', oMarkerType, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE, false, markerValues);
		  generalPanel.addChild(oOrientTypeMarkerInfo);
		  
		  /*var owrapperType = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.wrapAround);
		  var wrapperValues = [];
		  wrapperValues.push(new gadgets.OptionInfo('Yes','Yes'));
		  wrapperValues.push(new gadgets.OptionInfo('No','No'));	  
		  		  
		  var owrapperInfo = new gadgets.TextSwitcherGadgetInfo("wrapperGadget", 'Wrap Around', 'Wrap Around', owrapperType, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE, false, wrapperValues);
		  generalPanel.addChild(owrapperInfo);*/
		  
		  		  
		  var background = [];
		  background.push(new gadgets.OptionInfo('OpenStreetMap','OpenStreetMap'));
		  background.push(new gadgets.OptionInfo('Oracle Maps','Oracle Maps'));
		  background.push(new gadgets.OptionInfo('Google Maps','Google Maps'));
		  //background.push(new gadgets.OptionInfo('Mapbox Light','Mapbox Light'));
          background.push(new gadgets.OptionInfo('Carto Dark','Carto Dark'));
          background.push(new gadgets.OptionInfo('Carto Positron','Carto Positron'));          
          background.push(new gadgets.OptionInfo('None','None'));          
		
                            
		  var oBackgroundGVP = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.background);
		  var oBackgroundGadgetInfo = new gadgets.TextSwitcherGadgetInfo("backgroundGadget", 'Background Map', 'Background Map', oBackgroundGVP, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE, false, background);
		  generalPanel.addChild(oBackgroundGadgetInfo);		  
		  
		  var oGadgetFactory = this.getGadgetFactory();		  
		  var oMapKey = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.mapKey);
          var oMapKeyGadgetInfo = oGadgetFactory.createGadgetInfo("mapKeyGadget", 'Map Key (Google|MapBox)', 'Map Key (Google|MapBox)', oMapKey);
          generalPanel.addChild(oMapKeyGadgetInfo);		  
		  
		  if (LinesOnMap.superClass.doAddVizSpecificPropsDialog)
			LinesOnMap.superClass.doAddVizSpecificPropsDialog.apply(this, arguments);
	};

	LinesOnMap.prototype._handlePropChange = function (sGadgetID, oPropChange, oViewSettings, oActionContext){
	   var updateSettings = LinesOnMap.superClass._handlePropChange.call(this, sGadgetID, oPropChange, oViewSettings, oActionContext);      
		  if (updateSettings) {
			 return updateSettings; // super handled it
		  }

	   // Allow the super class an attempt to handle the changes
	   var conf = oViewSettings.getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
		  
		if (sGadgetID === "orientTypeGadget")
		  {
			 if (jsx.isNull(conf.styleDefaults))
			 {
				conf.styleDefaults = {};
			 }

			 this.setChartOrientation(oPropChange.value);
			 updateSettings = true;
		  }
		if (sGadgetID === "orientTypeGadget1")
		  {
			 if (jsx.isNull(conf.styleDefaults))
			 {
				conf.styleDefaults = {};
			 }

			 this.setmarkerStyle(oPropChange.value);
			 updateSettings = true;
		  }
		  
		if (sGadgetID === "backgroundGadget")
		  {
			 if (jsx.isNull(conf.styleDefaults))
			 {
				conf.styleDefaults = {};
			 }

			 this.setBackground(oPropChange.value);
			 updateSettings = true;
		  }

		if (sGadgetID === "wrapperGadget")
		  {
			 if (jsx.isNull(conf.styleDefaults))
			 {
				conf.styleDefaults = {};
			 }

			 this.setWrapAround(oPropChange.value);
			 updateSettings = true;
		  }	
		 if (sGadgetID === "mapKeyGadget")
		  {
			 if (jsx.isNull(conf.mapkey))
			 {
				conf.mapkey = '';
			 }
			 this.setMapKey(oPropChange.value);
			 updateSettings = true;
		  }		  
	   return updateSettings;
	};	
		
	

   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the visualization
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {string=} sVersion 
    * @returns {module:com-company-linesOnMap/linesOnMap.LinesOnMap}
    * @memberof module:com-company-linesOnMap/linesOnMap
    */
   function createClientComponent(sID, sDisplayName, sOrigin) {
     // Argument validation done by base class
      return new LinesOnMap(sID, sDisplayName, sOrigin, LinesOnMap.VERSION);
   };

   return {
      createClientComponent : createClientComponent
   };
});