define(['obitech-framework/jsx',
        'obitech-reportservices/datamodelshapes',
        'obitech-viz/genericDataModelHandler',
        'obitech-report/vizdatamodelsmanager'],
        function(jsx, 
                 datamodelshapes,
                 genericDataModelHandler,
                 vdm) {
   "use strict";
   var linesOnMapDataModelHandler = {};

   /**
    * @class The data model handler.
    * @constructor
    * @param {object=} oConfig
    * @param {string=} sId
    * @param {string=} sDisplayName
    * @param {string=} sOrigin
    * @param {string=} sVersion
    * @memberof module:com-company-linesOnMap/LinesOnMapDataModelHandler#
    * @extends module:obitech-viz/vizDataModelHandlerBase#VisualizationHandlerBase
    */
   function LinesOnMapDataModelHandler(oConfig, sId, sDisplayName, sOrigin, sVersion)
   {
      LinesOnMapDataModelHandler.baseConstructor.call(this, oConfig, sId, sDisplayName, sOrigin, sVersion);
   }
   jsx.extend(LinesOnMapDataModelHandler, genericDataModelHandler.GenericDataModelHandler);
   linesOnMapDataModelHandler.LinesOnMapDataModelHandler = LinesOnMapDataModelHandler;

   /**
    * @returns module:obitech-report/vizdatamodelsmanager#Mapper
    */
   LinesOnMapDataModelHandler.prototype.getLogicalMapper = function () {
      var oData = new datamodelshapes.PhysicalPlacement(datamodelshapes.Physical.DATA);
      var oRow = new datamodelshapes.PhysicalPlacement(datamodelshapes.Physical.ROW);
      var oCol = new datamodelshapes.PhysicalPlacement(datamodelshapes.Physical.COLUMN);

      var oMapper = new vdm.Mapper();

      oMapper.addCategoricalMapping(datamodelshapes.Logical.SIZE,   null); // don't place
      oMapper.addCategoricalMapping(datamodelshapes.Logical.COLOR,  oRow); // color -> row
	  oMapper.addCategoricalMapping(datamodelshapes.Logical.CATEGORY,  oRow); // det -> row
	  oMapper.addCategoricalMapping(datamodelshapes.Logical.GLYPH,  oRow); // gylph -> row
      oMapper.addCategoricalMapping(datamodelshapes.Logical.ROW, oRow); // row -> row

      oMapper.addMeasureMapping(datamodelshapes.Logical.SIZE,   oRow); // Don't place
      oMapper.addMeasureMapping(datamodelshapes.Logical.COLOR,  oRow); // Don't place
  	  oMapper.addMeasureMapping(datamodelshapes.Logical.CATEGORY,  oRow); // det -> row
	  oMapper.addMeasureMapping(datamodelshapes.Logical.GLYPH,  null); // gylph -> row
      oMapper.addMeasureMapping(datamodelshapes.Logical.MEASURES, oData);

      // where to place physical measure label in case no measure layer is present in logical
      oMapper.setDefaultPhysicalMeasureLabel(datamodelshapes.Physical.COLUMN, this.getMeasureLabelConfig().visibility);

      return oMapper;
   };

   /**
    * Returns the handler
    *@param {String} extensionPointName
    *@param {Object} config
    */
   linesOnMapDataModelHandler.getHandler = function(extensionPointName, config) {
      return new LinesOnMapDataModelHandler(config, extensionPointName);
   };

   return linesOnMapDataModelHandler;
});
