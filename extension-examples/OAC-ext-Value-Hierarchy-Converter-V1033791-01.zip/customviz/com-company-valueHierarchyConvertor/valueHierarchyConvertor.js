define(['jquery',
        'obitech-framework/jsx',
        'obitech-report/datavisualization',
        'obitech-reportservices/datamodelshapes',
        'obitech-reportservices/events',
        'obitech-appservices/logger',
        'ojL10n!com-company-valueHierarchyConvertor/nls/messages',
        'obitech-framework/messageformat',
        'skin!css!com-company-valueHierarchyConvertor/valueHierarchyConvertorstyles'],
        function($,
                 jsx,
                 dataviz,
                 datamodelshapes,
                 events,
                 logger,
                 messages) {
   "use strict";

   var MODULE_NAME = 'com-company-valueHierarchyConvertor/valueHierarchyConvertor';

   //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   jsx.assertAllNotNullExceptLastN(arguments, "valueHierarchyConvertor.js arguments", 2);

   var _logger = new logger.Logger(MODULE_NAME);

   // The version of our Plugin
   ValueHierarchyConvertor.VERSION = "1.0.0";

   /**
    * The implementation of the valueHierarchyConvertor visualization.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @extends {module:obitech-report/visualization.Visualization}
    * @memberof module:com-company-valueHierarchyConvertor/valueHierarchyConvertor#
    */
   function ValueHierarchyConvertor(sID, sDisplayName, sOrigin, sVersion) {
      // Argument validation done by base class
      ValueHierarchyConvertor.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);
   };
   jsx.extend(ValueHierarchyConvertor, dataviz.DataVisualization);
   
   
// JSON to CSV Converter
	function ConvertToCSV(objArray) {
		var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
		var str = '';

		for (var i = 0; i < array.length; i++) {
			var line = '';
			for (var index in array[i]) {
				if (line != '') line += ','

				line += array[i][index];
			}

			str += line + '\r\n';
		}

		return str;
	}
		
    function unflatten(arr) {
      var tree = [],
          mappedArr = {},
          arrElem,
          mappedElem;

      // First map the nodes of the array to an object
      for(var i = 0, len = arr.length; i < len; i++) {
        arrElem = arr[i];
        mappedArr[arrElem.child_id] = arrElem;
        mappedArr[arrElem.child_id]['children'] = [];
      }

      return mappedArr;
    }
	
	function generateResult(aOutput,mappedArr){
		
		var maxLen = 0;
		var output = [];
		for(var i=0;i<aOutput.length;i++){
			var myArr = [];
			var temp = aOutput[i];
			while(temp['parent_id'] != 'None'){
				if(temp['child_id'] != temp['parent_id']){
					myArr.push(temp['child_name']);
					myArr.push(temp['child_id']);
					var par_id = temp['parent_id'];
					if (typeof(mappedArr[par_id]) != "undefined"){
						temp = mappedArr[par_id];
					}else{
						myArr.push(temp['parent_name']);
						myArr.push(temp['parent_id']);
						break;
					}
				}else{
					return null;
				}
			}
			myArr = myArr.reverse();
			if(myArr.length > maxLen){
				maxLen = myArr.length;
			}
			output.push(myArr);
		}
		
		//now fill the remaining places with gaps
		for(var i=0;i<output.length;i++){
			var elem = output[i];
			var elem_length = elem.length;
			for(var j=elem_length;j<maxLen;j++){
				output[i].push('');
			}
		}
		
		return output;
	}
	ValueHierarchyConvertor.prototype.generate_data = function(oDataLayout){
		console.log("Inside generate data function");
	   	var oDataModel = this.getRootDataModel();
	    if(!oDataModel || !oDataLayout){
		   return;
	    }	
		
	   //--------------------------------------------------------
	   var aOutput = [];
	   var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
	   for (var i=0;i<nRows;i++){
		   var myObj = {};
		   myObj['child_id'] = oDataLayout.getValue(datamodelshapes.Physical.ROW, 0, i, false);
		   myObj['parent_id'] = oDataLayout.getValue(datamodelshapes.Physical.ROW, 3, i, false);
		   myObj['child_name'] = oDataLayout.getValue(datamodelshapes.Physical.ROW, 1, i, false);
		   myObj['parent_name'] = oDataLayout.getValue(datamodelshapes.Physical.ROW, 2, i, false);
		   aOutput.push(myObj);
	   }	
	  return aOutput;
	};   
   
   /**
    * Called whenever new data is ready and this visualization needs to update.
    * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
    */
   ValueHierarchyConvertor.prototype.render = function(oTransientRenderingContext) {
      try {
         var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
		 var oDataModel = this.getRootDataModel();
		   if(!oDataModel || !oDataLayout){
			  return;
		   }	
         // Determine the number of records available for rendering on ROW
         // Because we specified that Category should be placed on ROW in the data model handler,
         // this returns the number of rows for the data in Category.
         var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
		 var aOutput = this.generate_data(oDataLayout);
		 var result = unflatten(aOutput);
		 var output = generateResult(aOutput,result);
		 
		 var oViz = this;
         // Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
         // but may be used to render.
         var elContainer = this.getContainerElem();
		 if(output){
			 elContainer.className = "elContainer";
			 elContainer.innerHTML = "";
			 //var tableDiv = document.createElement("div");
			 //tableDiv.className = "myTableDiv";
			 var myTable = document.createElement("table");
			 myTable.className = "mytable";
			 myTable.style.border = "2";
			 var nRows = output.length;
			 var nCols = output[0].length;
			 var tHeaders = [];
			 for(var i=1;i<=(nCols/2);i++){
				 var id_col = 'L' + i + '_id';
				 var label_col = 'L' + i + '_label';
				 tHeaders.push(id_col);
				 tHeaders.push(label_col);
			 }
			 var myOutput = [];
			 myOutput = output.slice();
			 myOutput.unshift(tHeaders);
			 var headerTr = document.createElement("tr");
			 headerTr.className = "myHeaderTr";
			 for(var i=0;i<tHeaders.length;i++){
				 var headerTd = document.createElement("td");
				 headerTd.className = "myHeaderTd";
				 headerTd.style.fontWeight = "bolder";
				 headerTd.innerHTML = tHeaders[i];
				 headerTr.appendChild(headerTd);
			 }
			 myTable.appendChild(headerTr);
			 
			 for(var i=0;i<nRows;i++){
				 var tr = document.createElement("tr");
				 tr.className = "myTr";
				 for(var j=0;j<nCols;j++){
					 var td = document.createElement("td");
					 td.className = "myTd";
					 td.innerHTML = output[i][j];
					 tr.appendChild(td);
				 }
				 myTable.appendChild(tr);
			 }
			 //tableDiv.appendChild(myTable);
			 elContainer.appendChild(myTable);
			 //elContainer.appendChild(tableDiv);
			 //var breakElem = document.createElement("BR");
			 //tableDiv.appendChild(breakElem);
			 //var buttonDiv = document.createElement("div");
			 //buttonDiv.className = "myButtondiv";
			 var button = document.createElement("button");
			 button.className = "myButtonClass";
			 button.id = "myButton" + this.getID();
			 button.setAttribute('data-target', this.getID());
			 button.innerHTML = "Download Data";
			 elContainer.appendChild(button);
			 //buttonDiv.appendChild(button);
			 //elContainer.appendChild(tableDiv);
			 //elContainer.appendChild(buttonDiv);
			 //$(elContainer).css("overflow","auto");
			 $(elContainer).width("95%");
			 $(elContainer).height("95%");
			 var x = document.getElementsByClassName("bi_vizprogresspanecontainer");
			 console.log(x);
			 for (i = 0; i < x.length; i++) {
				x[i].style.cssText = 'overflow:auto !important;width:95% !important;height:95% !important;top:initial !important;left:initial !important';
			 }		 
		 }else{
			 elContainer.innerHTML = "Invalid data. Please check your data.";
		 }
		 //elContainer.appendChild(button);
		var download = function(content, fileName, mimeType) {
			  var a = document.createElement('a');
			  mimeType = mimeType || 'application/octet-stream';

			  if (navigator.msSaveBlob) { // IE10
				navigator.msSaveBlob(new Blob([content], {
				  type: mimeType
				}), fileName);
			  } else if (URL && 'download' in a) { //html5 A[download]
				a.href = URL.createObjectURL(new Blob([content], {
				  type: mimeType
				}));
				a.setAttribute('download', fileName);
				document.body.appendChild(a);
				a.click();
				document.body.removeChild(a);
			  } else {
				location.href = 'data:application/octet-stream,' + encodeURIComponent(content); // only this mime type is supported
			  }
		}
		
		$(".myButtonClass").click(function(){
			   if(oViz.getID() == this.getAttribute('data-target')){
				 var jsonObject = JSON.stringify(myOutput);
				 var data = ConvertToCSV(jsonObject);
				 download(data, 'dowload.csv', 'text/csv;encoding:utf-8');
				}			 
		});	
      }
      finally {
         this._setIsRendered(true);
      }
    };

   	ValueHierarchyConvertor.prototype.resizeVisualization = function(oVizDimensions, oTransientVizContext){
		var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
		this.render(oTransientRenderingContext);
	};	
	
   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the visualization
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {string=} sVersion 
    * @returns {module:com-company-valueHierarchyConvertor/valueHierarchyConvertor.ValueHierarchyConvertor}
    * @memberof module:com-company-valueHierarchyConvertor/valueHierarchyConvertor
    */
   function createClientComponent(sID, sDisplayName, sOrigin) {
     // Argument validation done by base class
      return new ValueHierarchyConvertor(sID, sDisplayName, sOrigin, ValueHierarchyConvertor.VERSION);
   };

   return {
      createClientComponent : createClientComponent
   };
});