define({
    "SCATTERPLOTMATRIX_DISPLAY_NAME": "ScatterPlotMatrix Plugin",
    "SCATTERPLOTMATRIX_SHORT_DISPLAY_NAME": "ScatterPlotMatrix Plugin",
    "SCATTERPLOTMATRIX_CATEGORY":"ScatterPlotMatrix Plugin",
    "SCATTERPLOTMATRIX_ROW_LABEL":"Category",
   // "SCATTERPLOTMATRIX_ITEM_SIZE":"Item Size",
    "TEXT_MESSAGE": "Hello!  This is the {0} visualization and I have {1} rows of data."

});