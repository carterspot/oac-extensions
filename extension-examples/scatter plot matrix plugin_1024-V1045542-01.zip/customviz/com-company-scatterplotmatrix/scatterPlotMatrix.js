define(['jquery',
  'obitech-framework/jsx',
  'obitech-report/datavisualization',
  'obitech-legend/legendandvizcontainer',
  'obitech-reportservices/datamodelshapes',
  'obitech-reportservices/events',
  'obitech-reportservices/interactionservice',
  'obitech-reportservices/markingservice',
  'obitech-application/gadgets',
  'obitech-report/visualization',
  'obitech-report/gadgetdialog',
  'obitech-application/bi-definitions',
  'obitech-appservices/logger',
  'ojL10n!com-company-scatterplotmatrix/nls/messages',
  'obitech-application/extendable-ui-definitions',
  'obitech-reportservices/data',
  'd3js',
  'knockout',
  'ojs/ojattributegrouphandler',
  'obitech-framework/messageformat',
  'skin!css!com-company-scatterplotmatrix/scatterPlotMatrixstyles'],
  function($,
   jsx,
   dataviz,
   legendandvizcontainer,
   datamodelshapes,
   events,
   interactions,
   marking,
  gadgets,
  viz,
  gadgetdialog,
  definitions,
   logger,
   messages,
   euidef,
   data,
   d3,
   ko,
   attributeGroupHandler) {
"use strict";

var MODULE_NAME = 'com-company-scatterplotmatrix/scatterPlotMatrix';

//Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
jsx.assertAllNotNullExceptLastN(arguments, "scatterPlotMatrix.js arguments", 2);

var _logger = new logger.Logger(MODULE_NAME);


// The version of our Plugin
ScatterPlotMatrix.VERSION = "1.0.0";

/**
* The implementation of the scatterPlotMatrix visualization.
* 
* @constructor
* @param {string} sID
* @param {string} sDisplayName
* @param {string} sOrigin
* @param {string} sVersion
* @extends {module:obitech-report/visualization.Visualization}
* @memberof module:com-company-scatterplotmatrix/scatterPlotMatrix#
*/

function ScatterPlotMatrix(sID, sDisplayName, sOrigin, sVersion) {
// Argument validation done by base class
ScatterPlotMatrix.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);
var tabInfo = '';
var cID = '';
var Color_Name='';

this.Config = {
  cID: '',
  Color_Name: '',
  Gridlines: 'Off',
  Size: 4,
  legendOption : 'On'
}

this._saveSettings = function() {
  this.getSettings().setViewConfigJSON(dataviz.SettingsNS.CHART, this.Config);
};
this.loadConfig = function (){
var conf = this.getSettings().getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
if (conf.cID) this.Config.cID = conf.cID;
if (conf.Color_Name) this.Config.Color_Name = conf.Color_Name;
if (conf.Gridlines) this.Config.Gridlines=conf.Gridlines;
if (!jsx.isNull(conf.Size)) this.Config.Size = conf.Size;
if (conf.legendOption) this.Config.legendOption=conf.legendOption; 
}

this.getCID = function(){
return(this.Config.cID);
};

this.setCID = function (o){
this.Config.cID = o;
};

this.getColor_Name = function(){
return(this.Config.Color_Name);
};

this.setColor_Name = function (o){
this.Config.Color_Name = o;
};
this.getTabInfo = function(){
return(tabInfo);
};

this.setTabInfo = function (o){
tabInfo = o;
};

this.getGridlines = function(){
return(this.Config.Gridlines);
};

this.setGridlines = function (o){
this.Config.Gridlines = o;
this._saveSettings();
};

this.getSize = function(){
return(this.Config.Size);
};

this.setSize = function (o){
this.Config.Size = o;
this._saveSettings();
};

this.getLegendOption = function(){
return(this.Config.legendOption);
};

this.setLegendOption = function (o){
this.Config.legendOption = o;
this._saveSettings();
};

/**
       * @type {Array.<String>} - The array of selected items
       */
var aSelectedItems = new Map();

/**
* @return  {Array.<String>} - The array of selected items
*/
this.getSelectedItems = function () {
return aSelectedItems;
};

/**
* Clears the current list of selected items
*/
this.clearSelectedItems = function () {
aSelectedItems = new Map();
};

};
jsx.extend(ScatterPlotMatrix, dataviz.DataVisualization);
/**
* Called whenever new data is ready and this visualization needs to update.
* @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
*/
var display_value = new Map();
var legend_title_set = "";
var color_map = {};
var category, category1;
var tooltip_1, tooltip_2, tooltip_3, tooltip_4, tooltip_5;


ScatterPlotMatrix.prototype._generateData = function(oDataLayout, oTransientRenderingContext){
 
var oDataModel = this.getRootDataModel();
    if(!oDataModel || !oDataLayout){
        return;
    }
    color_map = {};
   var aAllMeasures = oDataModel.getColumnIDsIn(datamodelshapes.Physical.DATA);         
    var nMeasures = aAllMeasures.length;
    var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
    var nRowLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
    var oDataLayoutHelper = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT_HELPER);
    var oColorContext = this.getColorContext(oTransientRenderingContext);
    var oColorInterpolator = this.getCachedColorInterpolator(oTransientRenderingContext, datamodelshapes.Logical.COLOR);
    var rowLabels = [];
    var cnt =0;
    var row_cnt = 0;
    var tooltip_container=[];
    var tooltip_displaynames = [];
  
 //  var xCaption = oDataLayout.getValue(datamodelshapes.Physical.COLUMN, 0, 0, false)
   for(var nRow = 0; nRow < nRowLayerCount; nRow++){
    
        var rowKey = oDataLayoutHelper.getLogicalEdgeName(datamodelshapes.Physical.ROW, nRow);
        var displayName = oDataLayout.getLayerMetadata(datamodelshapes.Physical.ROW, nRow, data.LayerMetadata.LAYER_DISPLAY_NAME);
        tooltip_displaynames.push(displayName);
      //  var row_tooltip = oDataLayout.getValue(datamodelshapes.Physical.ROW, 0, nRow, false);
        var newRowLayerCount = nRowLayerCount - 1;
       if(rowKey === 'color'){
        var newRowLayerCount = nRowLayerCount - 2;
       }


      //  var j = 0;
      // for(j; j<nRows; j=j+2){
      //   for(i=0; i< newRowLayerCount; i++){
      //     var row_tooltip = oDataLayout.getValue(datamodelshapes.Physical.ROW, i, j, false);
      //     tooltip_container.push(row_tooltip);
      //    }
      // }
       
    //    var row_tooltip = oDataLayout.getValue(datamodelshapes.Physical.ROW, 1, nRow, false);
       

        if(nRow === 0){
          category = displayName;
        } else if(nRow === 1){
         category1 = displayName;
        }

        
        if(!displayName == '' && rowKey == 'color'){
          legend_title_set = displayName;
          cnt = cnt + 1;
        }
        else if(cnt == 0){
          legend_title_set = '';
        }
        
    } 

      
       var outputMap = [];
       var xSet = new Set(), xArray;
       var attribute;
       var val_displayName;
       var color_hash, scatter_color;
       tooltip_1 = "", tooltip_2 = "", tooltip_3 = "", tooltip_4 = "", tooltip_5 = "";
       for(var nRow = 0; nRow < Math.max(nRows, 1); nRow++) {
          
        var colorObj, color = "", 
       // tooltip,
        row="";
        var value = parseFloat(oDataLayout.getValue(datamodelshapes.Physical.DATA, nRow, 0));
        var details = [];

        for (var nRowLayer = 0; nRowLayer < Math.max(nRowLayerCount, 1); nRowLayer++) {
            var rowType = oDataLayoutHelper.getLogicalEdgeName(datamodelshapes.Physical.ROW, nRowLayer);
           
        //   var row_tooltip =  oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);
         
        //   if(rowType === "row"){
        //     tooltipObj.push(row_tooltip);
        //  }
        
            
            switch (rowType) {                
                case "row":
                   attribute = row!="" ? row + ", " +oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false)
                            : oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false);

                  details.push(attribute);
                   break;
                case "color":
                   colorObj = this.getDataItemColorInfo(oDataLayoutHelper, oColorContext, oColorInterpolator, nRow, 0);
                   color_hash = colorObj.sColor;
                   scatter_color = colorObj.sSeriesColorLabel;
                   break;
            }

            
        }
      var aOutput =[];
      var resArray = [];
      
      if(scatter_color.includes(',')){
     var col_gram =  scatter_color.split(',');
     var col_name = scatter_color.split(',')[0];          
     col_gram = col_gram[1];

    
     
     if(nRow == 0){
      tooltip_1 = col_gram;
     } else if (nRow == 1){
      tooltip_2 = col_gram;
     } else if(nRow == 2){
      tooltip_3 = col_gram
     } else if(nRow == 3){
      tooltip_4 = col_gram
     } else if (nRow == 4){
      tooltip_5 = col_gram
     }

  
     aOutput = {attribute: attribute, value: value, color: color_hash, val_displayName: col_gram, col_name: col_name, row: nRow,details: details, tooltip_displaynames: tooltip_displaynames };  
      }
      else{
          aOutput = {attribute: attribute, value: value, color: color_hash, val_displayName: scatter_color, col_name: col_name, row: nRow, details: details, tooltip_displaynames: tooltip_displaynames};  
          if(nRow == 0){
            tooltip_1 = scatter_color;
           } else if (nRow == 1){
            tooltip_2 = scatter_color;
           } else if(nRow == 2){
            tooltip_3 = scatter_color
           } else if(nRow == 3){
            tooltip_4 = scatter_color
           } else if (nRow == 4){
            tooltip_5 = scatter_color
           }
        }
          outputMap.push(aOutput);       
    }
    var resOutput = [];
    var len = Math.round(outputMap.length / nMeasures);
    
   if(!tooltip_1 || !tooltip_2 || !tooltip_3 || !tooltip_3 || !tooltip_4 || !tooltip_5){
    tooltip_1 = aAllMeasures[0];
    tooltip_2 = aAllMeasures[1];
    tooltip_3 = aAllMeasures[2];
    tooltip_4 = aAllMeasures[3];
    tooltip_5 = aAllMeasures[4];
   }

     var j=0;
      for(var i = 0 ; i < len; i++)
    {
      if(nMeasures == 2) {
        resOutput = {species: outputMap[j].attribute, value1: outputMap[j].value, value2: outputMap[j + 1].value, color: outputMap[j].color, col_name: outputMap[j].col_name, row: outputMap[i].row, details: outputMap[j].details, tooltip_displaynames: outputMap[j].tooltip_displaynames};
        color_map[resOutput.col_name] = resOutput.color;
        display_value.set("value1", outputMap[j].val_displayName);
        display_value.set("value2", outputMap[j+1].val_displayName);
        resArray.push(resOutput);
        j=j+2;
      } else if(nMeasures == 3) {
        resOutput = {species: outputMap[j].attribute, value1: outputMap[j].value, value2: outputMap[j + 1].value, value3: outputMap[j + 2].value, color: outputMap[j].color, col_name: outputMap[j].col_name, row: outputMap[i].row, details: outputMap[j].details, tooltip_displaynames: outputMap[j].tooltip_displaynames};
        color_map[resOutput.col_name] = resOutput.color;
        display_value.set("value1", outputMap[j].val_displayName);
        display_value.set("value2", outputMap[j+1].val_displayName);
        display_value.set("value3", outputMap[j+2].val_displayName);
        resArray.push(resOutput);
        j=j+3;
      } else if(nMeasures == 4) {
        resOutput = {species: outputMap[j].attribute, value1: outputMap[j].value, value2: outputMap[j + 1].value, value3: outputMap[j + 2].value, value4: outputMap[j + 3].value, color: outputMap[j].color, col_name: outputMap[j].col_name, row: outputMap[i].row, details: outputMap[j].details, tooltip_displaynames: outputMap[j].tooltip_displaynames};
        color_map[resOutput.col_name] = resOutput.color;
        display_value.set("value1", outputMap[j].val_displayName);
        display_value.set("value2", outputMap[j+1].val_displayName);
        display_value.set("value3", outputMap[j+2].val_displayName);
        display_value.set("value4", outputMap[j+3].val_displayName);  
  resArray.push(resOutput);
        j=j+4;
      } else if(nMeasures == 5) {
             resOutput = {species: outputMap[j].attribute, value1: outputMap[j].value, value2: outputMap[j + 1].value, value3: outputMap[j + 2].value, value4: outputMap[j + 3].value, value5: outputMap[j + 4].value, color: outputMap[j].color , col_name: outputMap[j].col_name, row: outputMap[i].row, details: outputMap[j].details, tooltip_displaynames: outputMap[j].tooltip_displaynames};
             
              color_map[resOutput.col_name] = resOutput.color;
                               
             display_value.set("value1", outputMap[j].val_displayName);
             display_value.set("value2", outputMap[j+1].val_displayName);
             display_value.set("value3", outputMap[j+2].val_displayName);
             display_value.set("value4", outputMap[j+3].val_displayName);
             display_value.set("value5", outputMap[j+4].val_displayName);   
       resArray.push(resOutput);
             j=j+5;
           } 
    }
  
   
  return resArray;        

}


ScatterPlotMatrix.prototype.render = function(oTransientRenderingContext) {
try {
  this.loadConfig();
   // Note: all events will be received after initialize and start complete.  We may get other events
   // such as 'resize' before the render, i.e. this might not be the first event.

   // Retrieve the data object for this visualization
   var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
   if (!oDataLayout)
              return;
   var oData = this._generateData(oDataLayout, oTransientRenderingContext);             //to get the values from generate data
              if(!oData) {
                 return;
                 }     
    
   // Determine the number of records available for rendering on ROW
   // Because we specified that Category should be placed on ROW in the data model handler,
   // this returns the number of rows for the data in Category.
   var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);

   // Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
   // but may be used to render.
   var elContainer = this.getContainerElem();
//   var elContainer = oTransientRenderingContext.get(viz.ContextProperty.HTML_CONTAINER);
  elContainer.innerHTML = '';
   var sVizContainerId = this.getSubElementIdFromParent(this.getContainerElem(), "hvc");
   var pane = sVizContainerId.substring(sVizContainerId.indexOf("view")+5,sVizContainerId.indexOf("pane"));
   var conetentPane = sVizContainerId.substring(sVizContainerId.indexOf("contentpane_")+12,sVizContainerId.indexOf("vizCont")-1);
   var cId = pane+"_"+conetentPane;
   var oViz = this;
   this.setCID(cId);

   var width = $(elContainer).width() - 30;
   var height = $(elContainer).height() - 20;
   var legend_margin = 0.25*height + "px";
   var htmlContent = "<div class='scatterPlotMatrix' id=scatterchart" + cId + ">" + "</div>";
   if(this.getLegendOption() === 'On' && oData[0].col_name != undefined){
    htmlContent += "<div><div id=legendPane2_"+cId+" class='title' style='margin-top: "+ legend_margin +"'>"+
      "<span id=legendName2_"+cId+">" + 
    legend_title_set + "</span></div>" + "<div id=legend2_"+cId+" class='legend_scatterplotmatrix'></div>";
    htmlContent += "</div>";

    width = $(elContainer).width() - 150;
   }
    $(elContainer).html(htmlContent);
    var len1 = oData.length;
    var legnd_cnt = Math.round(nRows/len1);
    var tooltip;
    
   var ht_width_comparison;
   if(width<=height){
    ht_width_comparison = width
   } else ht_width_comparison = height;

    if(!document.getElementById("tooltip_scatter_"+cId)) {
      tooltip = d3.select("body")
      .append("div")
      .attr("id","tooltip_scatter_"+cId)
      .attr("class", "tooltip_scatter")
      .style("display", "none");     
    } else {
      tooltip = d3.select("#tooltip_scatter_"+cId)
    }

    // var tooltip = d3.select("body")
    // .append("div")
    // .attr("class", "tooltip_scatter")
    // .style("display", "none");      

      function kFormatter_tooltip(num) {
        var ret_val;
        if(num>=0){
          if(Math.abs(num) > 999999){
            ret_val = ((Math.abs(num)/1000000).toFixed(2)) + 'M';
            } else if(Math.abs(num) > 999) {
              ret_val = ((Math.abs(num)/1000).toFixed(2)) + 'K';
            } else {
              ret_val = (Math.abs(num).toFixed(2))+'';
            }
        } else if(num < 0){
          if(Math.abs(num) > 999999){
            ret_val = '-' + ((Math.abs(num)/1000000).toFixed(2)) + 'M';
            } else if(Math.abs(num) > 999) {
              ret_val = '-' + ((Math.abs(num)/1000).toFixed(2)) + 'K';
            } else {
              ret_val = '-' + (Math.abs(num).toFixed(2))+'';
            }
        } else if(isNaN(num)){
          ret_val = "-";
        }
        
   return ret_val;
        }
    

    function tooltipContent(d) { 
      
      var content = "";
      if(d.col_name === undefined && d.species === undefined){
        if(legnd_cnt === 2){
          content = "<table>" +
        "<tr><td class='tthead'>"+ tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>"; 
        } else if(legnd_cnt === 3){
          content = "<table>" +
        "<tr><td class='tthead'>"+ tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_3 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value3) + "</td></tr>"; 
        } else if(legnd_cnt === 4){
          content = "<table>" +
        "<tr><td class='tthead'>"+ tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_3 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value3) + "</td></tr>" + 
        "<tr><td class='tthead'>"+ tooltip_4 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value4) + "</td></tr>"; 
        } else  content = "<table>" +
        "<tr><td class='tthead'>"+ tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_3 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value3) + "</td></tr>" + 
        "<tr><td class='tthead'>"+ tooltip_4 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value4) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_5 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value5) + "</td></tr>";    

      } else
      if(d.col_name === undefined){
        if(legnd_cnt === 2){
          content = "<table>";
        // "<tr><td class='tthead'>"+ category +"</td><td class='ttval'>" + d.details[0] + "</td></tr>" +
        // "<tr><td class='tthead'>"+ category1 +"</td><td class='ttval'>" + d.details[1] + "</td></tr>" +
        for(var i=0; i<d.details.length; i++){
          content +=  "<tr><td class='tthead'>"+ d.tooltip_displaynames[i] +"<\/td><td class='ttval'>"+d.details[i]+"<\/td><\/tr>";
      }
     content +=  "<tr><td class='tthead'>"+ tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>"; 
        } else if(legnd_cnt === 3){
          content = "<table>";
          for(var i=0; i<d.details.length; i++){
            content +=  "<tr><td class='tthead'>"+ d.tooltip_displaynames[i] +"<\/td><td class='ttval'>"+d.details[i]+"<\/td><\/tr>";
        }
        content +=  "<tr><td class='tthead'>"+ tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_3 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value3) + "</td></tr>"; 
        } else if(legnd_cnt === 4){
          content = "<table>";
     //   "<tr><td class='tthead'>"+ category +"</td><td class='ttval'>" + d.species + "</td></tr>" +
     for(var i=0; i<d.details.length; i++){
      content +=  "<tr><td class='tthead'>"+ d.tooltip_displaynames[i] +"<\/td><td class='ttval'>"+d.details[i]+"<\/td><\/tr>";
  }
  content += "<tr><td class='tthead'>"+ tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_3 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value3) + "</td></tr>" + 
        "<tr><td class='tthead'>"+ tooltip_4 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value4) + "</td></tr>"; 
        } else  if(legnd_cnt === 5)
      
      {  content = "<table>";
        for(var i=0; i<d.details.length; i++){
          content +=  "<tr><td class='tthead'>"+ d.tooltip_displaynames[i] +"<\/td><td class='ttval'>"+d.details[i]+"<\/td><\/tr>";
      }
       // "<tr><td class='tthead'>"+ category +"</td><td class='ttval'>" + d.species + "</td></tr>" +
       content += "<tr><td class='tthead'>"  + tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_3 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value3) + "</td></tr>" + 
        "<tr><td class='tthead'>"+ tooltip_4 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value4) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_5 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value5) + "</td></tr>";    
    }

      } else 
      if(d.species === undefined){
        if(legnd_cnt === 2){
          content = "<table>" +
        "<tr><td class='tthead'>"+ legend_title_set +"</td><td class='ttval'>" + d.col_name+ "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>"; 
        } else if(legnd_cnt === 3){
          content = "<table>" +
        "<tr><td class='tthead'>"+ legend_title_set +"</td><td class='ttval'>" + d.col_name+ "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_3 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value3) + "</td></tr>"; 
        } else if(legnd_cnt === 4){
          content = "<table>" +
        "<tr><td class='tthead'>"+ legend_title_set +"</td><td class='ttval'>" + d.col_name+ "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_3 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value3) + "</td></tr>" + 
        "<tr><td class='tthead'>"+ tooltip_4 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value4) + "</td></tr>"; 
        } else  content = "<table>" +
        "<tr><td class='tthead'>"+ legend_title_set +"</td><td class='ttval'>" + d.col_name+ "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_3 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value3) + "</td></tr>" + 
        "<tr><td class='tthead'>"+ tooltip_4 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value4) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_5 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value5) + "</td></tr>"; 

      } else 
      if(legnd_cnt === 2){
        content = "<table>" +
      "<tr><td class='tthead'>"+ legend_title_set +"</td><td class='ttval'>" + d.col_name+ "</td></tr>";
  //    "<tr><td class='tthead'>"+ category +"</td><td class='ttval'>" + d.species + "</td></tr>" +
      for(var i=0; i<d.details.length; i++){
        content +=  "<tr><td class='tthead'>"+ d.tooltip_displaynames[i] +"<\/td><td class='ttval'>"+d.details[i]+"<\/td><\/tr>";
    }
    content +=   "<tr><td class='tthead'>"+ tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
      "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>"; 
      } else if(legnd_cnt === 3){
        content = "<table>" +
      "<tr><td class='tthead'>"+ legend_title_set +"</td><td class='ttval'>" + d.col_name+ "</td></tr>";
   //   "<tr><td class='tthead'>"+ category +"</td><td class='ttval'>" + d.species + "</td></tr>" +
   for(var i=0; i<d.details.length; i++){
    content +=  "<tr><td class='tthead'>"+ d.tooltip_displaynames[i] +"<\/td><td class='ttval'>"+d.details[i]+"<\/td><\/tr>";
}
   content +=   "<tr><td class='tthead'>"+ tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
      "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>" +
      "<tr><td class='tthead'>"+ tooltip_3 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value3) + "</td></tr>"; 
      } else if(legnd_cnt === 4){
        content = "<table>" +
      "<tr><td class='tthead'>"+ legend_title_set +"</td><td class='ttval'>" + d.col_name+ "</td></tr>";
      for(var i=0; i<d.details.length; i++){
        content +=  "<tr><td class='tthead'>"+ d.tooltip_displaynames[i] +"<\/td><td class='ttval'>"+d.details[i]+"<\/td><\/tr>";
    }
     // "<tr><td class='tthead'>"+ category +"</td><td class='ttval'>" + d.species + "</td></tr>" +
     content += "<tr><td class='tthead'>"+ tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
      "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>" +
      "<tr><td class='tthead'>"+ tooltip_3 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value3) + "</td></tr>" + 
      "<tr><td class='tthead'>"+ tooltip_4 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value4) + "</td></tr>"; 
      } else if (legnd_cnt === 5){
        content = "<table>" +
        "<tr><td class='tthead'>"+ legend_title_set +"</td><td class='ttval'>" + d.col_name+ "</td></tr>";
      //  "<tr><td class='tthead'>"+ category +"</td><td class='ttval'>" + d.species + "</td></tr>" +
      for(var i=0; i<d.details.length; i++){
        content +=  "<tr><td class='tthead'>"+ d.tooltip_displaynames[i] +"<\/td><td class='ttval'>"+d.details[i]+"<\/td><\/tr>";
    }
       content += "<tr><td class='tthead'>"+ tooltip_1 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value1) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_2 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value2) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_3 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value3) + "</td></tr>" + 
        "<tr><td class='tthead'>"+ tooltip_4 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value4) + "</td></tr>" +
        "<tr><td class='tthead'>"+ tooltip_5 +"</td><td class='ttval'>" + kFormatter_tooltip(d.value5) + "</td></tr>"; 
      }
      

      
     content += "</table>";    
     tooltip.style("display", null);
     return content;
    }

     
  //    elContainer.style.overflow = "auto";

  var size;

  switch (legnd_cnt) {
    case 2:
    size = (width < 370) ? 0.4 * ht_width_comparison : 0.46 * ht_width_comparison;
    break;
    
    case 3:
    size = (width < 376) ? 0.28 * ht_width_comparison : 0.31 * ht_width_comparison;
    break;
    
    case 4:
    if (width < 280) {
    size = 0.22 * ht_width_comparison;
    } else {
    size = (height <= width) ? 0.24 * height : 0.225 * width;
    }
    break;
    
    case 5:
    size = (height <= width) ? 0.19 * height : 0.175 * width;
    break;
    
    default:
    size = 0;  // Optional: Add a default case if you expect other values for legnd_cnt
    }

// switch (legnd_cnt) {
// case 2:
// size = (width < 370) ? 0.4 * width : 0.48 * height;
// break;

// case 3:
// size = (width < 376) ? 0.28 * width : 0.32 * height;
// break;

// case 4:
// if (width < 270) {
// size = 0.22 * width;
// } else {
// size = (height <= width) ? 0.24 * height : 0.225 * width;
// }
// break;

// case 5:
// size = (height <= width) ? 0.19 * height : 0.175 * width;
// break;

// default:
// size = 0;  // Optional: Add a default case if you expect other values for legnd_cnt
// }

      //var size;
    
//               if(legnd_cnt === 2){
//                 if(width<370){
//                   size = 0.4*width;
//                 } else 
//                 size = 0.48*height;
//              //   size = 0.4*width;
//           } 
//            else if (legnd_cnt === 3){
//             if(width<376){
//               size = 0.28*width;
//             } else
//         size = 0.32*height;
//      //   size = 0.28*width;
//       } else if (legnd_cnt === 4){
//         if(width<270){
//           size = 0.22*width
//         } else
//         // size = 0.23*width;
//         if(height<= width){
//           size = 0.24*height;
//         } else
//        size = 0.225*width;
//   } else if (legnd_cnt === 5){
//   // size = 0.17*width;
//   if(height<= width){
//     size = 0.19*height;
//   } else 
//    size = 0.175*width;
// }


      
      
   //   var size = 130;
          var padding = 20;
          var radius = this.getSize();
      var tick_cnt;
      if(legnd_cnt === 5){
        tick_cnt = 3;
      } else tick_cnt = 4;
    
      var x = d3.scale.linear()
          .range([padding / 2, size - padding / 2]);
      
      var y = d3.scale.linear()
          .range([size - padding / 2, padding / 2]);
      
      var xAxis = d3.svg.axis()
          .scale(x)
          .orient("bottom")
          .ticks(tick_cnt);

        //  .ticks(tick_cnt, "s");
      
      var yAxis = d3.svg.axis()
          .scale(y)
          .orient("left")
          .ticks(4);
      
      
        var domainByTrait = {},
            traits = d3.keys(oData[0]).filter(function(d) { return d !== "species"; }),
            traits = traits.filter(function(d) { return d !== "color"; }),
            traits = traits.filter(function(d) { return d !== "col_name"; }),
            traits = traits.filter(function(d) { return d !== "row"; }),
            traits = traits.filter(function(d) { return d !== "details"; }),
            traits = traits.filter(function(d) { return d !== "tooltip_displaynames"; }),
            n = traits.length;
            // n_traits = traits.length;
      
        traits.forEach(function(trait) {
          domainByTrait[trait] = d3.extent(oData, function(d) { return d[trait]; });
        });
    var value1_min, value1_max, value2_min, value2_max, value3_min, value3_max, value4_min, value4_max, value5_min, value5_max,
    value1_range, value2_range, value3_range, value4_range, value5_range;

            if(n == 2)
            {  
              value1_min = domainByTrait.value1[0];
              value1_max = domainByTrait.value1[1];
              value2_min = domainByTrait.value2[0];
              value2_max = domainByTrait.value2[1];
              value1_range = value1_max - value1_min;
              value2_range = value2_max - value2_min;

              domainByTrait.value1[0] = domainByTrait.value1[0] - (0.1*value1_range);
              domainByTrait.value1[1] = domainByTrait.value1[1] + (0.1*value1_range);

              domainByTrait.value2[0] = domainByTrait.value2[0]  - (0.1*value2_range);
              domainByTrait.value2[1] = domainByTrait.value2[1] + (0.1*value2_range);
              
            } else  if(n == 3)
              {
              value1_min = domainByTrait.value1[0];
              value1_max = domainByTrait.value1[1];
              value2_min = domainByTrait.value2[0];
              value2_max = domainByTrait.value2[1];
              value3_min = domainByTrait.value3[0];
              value3_max = domainByTrait.value3[1];
              value1_range = value1_max - value1_min;
              value2_range = value2_max - value2_min;
              value3_range = value3_max - value3_min;

              domainByTrait.value1[0] = domainByTrait.value1[0] - (0.1*value1_range);
              domainByTrait.value1[1] = domainByTrait.value1[1] + (0.1*value1_range);

              domainByTrait.value2[0] = domainByTrait.value2[0]  - (0.1*value2_range);
              domainByTrait.value2[1] = domainByTrait.value2[1] + (0.1*value2_range);

              domainByTrait.value3[0] = domainByTrait.value3[0]  - (0.1*value3_range);
              domainByTrait.value3[1] = domainByTrait.value3[1] + (0.1*value3_range);
                
               }  
             else  if(n == 4)
                {
              value1_min = domainByTrait.value1[0];
              value1_max = domainByTrait.value1[1];
              value2_min = domainByTrait.value2[0];
              value2_max = domainByTrait.value2[1];
              value3_min = domainByTrait.value3[0];
              value3_max = domainByTrait.value3[1];
              value4_min = domainByTrait.value4[0];
              value4_max = domainByTrait.value4[1];
              value1_range = value1_max - value1_min;
              value2_range = value2_max - value2_min;
              value3_range = value3_max - value3_min;
              value4_range = value4_max - value4_min;

              domainByTrait.value1[0] = domainByTrait.value1[0] - (0.1*value1_range);
              domainByTrait.value1[1] = domainByTrait.value1[1] + (0.1*value1_range);

              domainByTrait.value2[0] = domainByTrait.value2[0]  - (0.1*value2_range);
              domainByTrait.value2[1] = domainByTrait.value2[1] + (0.1*value2_range);

              domainByTrait.value3[0] = domainByTrait.value3[0]  - (0.1*value3_range);
              domainByTrait.value3[1] = domainByTrait.value3[1] + (0.1*value3_range);

              domainByTrait.value4[0] = domainByTrait.value4[0]  - (0.1*value4_range);
              domainByTrait.value4[1] = domainByTrait.value4[1] + (0.1*value4_range);
                } 
                else  if(n == 5)
                  {
              value1_min = domainByTrait.value1[0];
              value1_max = domainByTrait.value1[1];
              value2_min = domainByTrait.value2[0];
              value2_max = domainByTrait.value2[1];
              value3_min = domainByTrait.value3[0];
              value3_max = domainByTrait.value3[1];
              value4_min = domainByTrait.value4[0];
              value4_max = domainByTrait.value4[1];
              value5_min = domainByTrait.value5[0];
              value5_max = domainByTrait.value5[1];
              value1_range = value1_max - value1_min;
              value2_range = value2_max - value2_min;
              value3_range = value3_max - value3_min;
              value4_range = value4_max - value4_min;
              value5_range = value5_max - value5_min;

              domainByTrait.value1[0] = domainByTrait.value1[0] - (0.1*value1_range);
              domainByTrait.value1[1] = domainByTrait.value1[1] + (0.1*value1_range);

              domainByTrait.value2[0] = domainByTrait.value2[0]  - (0.1*value2_range);
              domainByTrait.value2[1] = domainByTrait.value2[1] + (0.1*value2_range);

              domainByTrait.value3[0] = domainByTrait.value3[0]  - (0.1*value3_range);
              domainByTrait.value3[1] = domainByTrait.value3[1] + (0.1*value3_range);

              domainByTrait.value4[0] = domainByTrait.value4[0]  - (0.1*value4_range);
              domainByTrait.value4[1] = domainByTrait.value4[1] + (0.1*value4_range);

              domainByTrait.value5[0] = domainByTrait.value5[0]  - (0.1*value5_range);
              domainByTrait.value5[1] = domainByTrait.value5[1] + (0.1*value5_range);
                  }
        
        var grid, grid1, xaxis_pos;
        if(this.getGridlines() === "On"){
          grid = size*n;
          grid1 = -(size*n);
       } else if(this.getGridlines() === "Off"){
          grid = 0
          grid1 = 0
       }
       
       if((value1_range || value2_range || value3_range || value4_range || value5_range) < 8 ){
        xAxis.tickSize(grid)
        .tickFormat(d3.format(".1f"));
        yAxis.tickSize(grid1)
        .tickFormat(d3.format(".1f"));
       } else {
        xAxis.tickSize(grid)
        .tickFormat(d => kFormatter(d));
        yAxis.tickSize(grid1)
        .tickFormat(d => kFormatter(d));
       }
        

        
        

      
  
        function kFormatter(num) {
          var ret_val;
          if(num>=0){
            if(Math.abs(num) > 999999){
              //  ret_val = Math.sign(num)*((Math.abs(num)/1000000).toFixed(1)) + 'M';
              ret_val = ((Math.abs(num)/1000000).toFixed(1)) + 'M';
              } else if(Math.abs(num) > 999) {
                ret_val = ((Math.abs(num)/1000).toFixed(0)) + 'K';
              } else {
                ret_val = (Math.abs(num).toFixed(0))+'';
              }
          } else if(num < 0){
            if(Math.abs(num) > 999999){
              //  ret_val = Math.sign(num)*((Math.abs(num)/1000000).toFixed(1)) + 'M';
              ret_val = '-' + ((Math.abs(num)/1000000).toFixed(1)) + 'M';
              } else if(Math.abs(num) > 999) {
                ret_val = '-' + ((Math.abs(num)/1000).toFixed(0)) + 'K';
              } else {
                ret_val = '-' + (Math.abs(num).toFixed(0))+'';
              }
          }
          
     return ret_val;
          }

          
           var y_axis_pos = size/2;
          var dx_x, right_text_x;
          if(legnd_cnt === 2){
            right_text_x = 0.6 * size;
            dx_x = -2 + "em";
          } else if(legnd_cnt === 3){
            right_text_x = 0.6 * size;
            dx_x = -2 + "em";
          } else if(legnd_cnt === 4){
            right_text_x = 1 * size;
            dx_x = -6 + "em";
          } else if(legnd_cnt === 5){
            right_text_x = 1.05 * size;
            dx_x = -6 + "em"
          }

          function onOutsideClick(d)
  {
      var event = d3.event;
      var circle = $("circle");
      var clicked = false;
      if(!event.ctrlKey){
          // if the target of the click isn't the container nor a descendant of the container
          if (!circle.is(event.target) && circle.has(event.target).length === 0)
          {
              $("circle").removeClass("scattermark");
              clicked = true;
          }
          if(clicked){
              var oMarkingService = oViz.getMarkingService();
              oMarkingService.clearMarksForDataLayout(oDataLayout);
              oViz._publishMarkEvent(oDataLayout/*, marking.EMarkContext.MARK_ALL*/);
          }
      }
  }
  //    var cell_font_sz = Math.round(0.4 * width);
      var axis_font_sz = Math.round(0.2 * width);

      var cell_font_sz = Math.round(0.4 * height);
        
      
      if(height>320){
      if(cell_font_sz>10){
        if(n === 3)
          {
          cell_font_sz = 8;
        }
        else if(n === 4){
            cell_font_sz = 9;
        } else if(n === 5){
          cell_font_sz = 8;
      } else {
        cell_font_sz = 10
      } 
      } 
      else cell_font_sz;
    } 
    else if(height<260){
       cell_font_sz = 7;
    } else cell_font_sz = 8;


      if(axis_font_sz>10){
        if((n === 3) && (width<320 || height<250)){
          axis_font_sz = 8;
        } else
        if(n === 4){
            axis_font_sz = 9;
        } else if(n === 5){
              axis_font_sz = 8;
          } else
        axis_font_sz = 10
      }
       else axis_font_sz; 

      // if(axis_font_sz>10){
      //   axis_font_sz = 10
      // } else axis_font_sz;



        var svg = d3.select("#scatterchart"+cId).append("svg")
            .attr("width", width)
            .attr("height", (((size != undefined ? size : 30) * n)+50))
            .attr("class", "scatterPlotMatrix")
            .on("click", function(d){                 
              onOutsideClick(d);
          })
          .append("g")
            .attr("transform", "translate(" + (padding+5) + "," + 0 + ")");
       //     .style("font-size", font_sz);

            var pos;

      if(this.getGridlines() === "On"){
        pos = 0;
      } else pos = (size*n);

            svg.selectAll(".x.axis")
            .data(traits)
          .enter().append("g")
            .attr("class", "x axis")
            .style("font-size", axis_font_sz)
            .attr("transform", function(d, i) { 
              return "translate(" + (n - i - 1) * (size != undefined ? size : 30) + ","+ pos +")"; })
            .each(function(d) { 
              x.domain(domainByTrait[d]);
              d3.select(this).call(xAxis); 
            });
          //   .selectAll("text")
          //   .style("text-anchor", "end")
          //   .attr("dx", "-.8em")
          //   .attr("dy", ".15em")
          //   .attr("transform", function (d) {
          //     return "rotate(-30)";
          // });
      
        svg.selectAll(".y.axis")
            .data(traits)
          .enter().append("g")
            .attr("class", "y axis")
            .style("font-size", axis_font_sz)
            .attr("transform", function(d, i) { return "translate(5," + i * size + ")"; })
            .each(function(d) { 
            y.domain(domainByTrait[d]); d3.select(this).call(yAxis); });
      
        var cell = svg.selectAll(".cell")
            .data(cross(traits, traits))
          .enter().append("g")
            .attr("class", "cell")
            .attr("transform", function(d) { return "translate(" + (n - d.i - 1) * size + "," + d.j * size + ")"; })
            .each(plot);
      var lenn;
      var count=0;
            cell.filter(function(d) {
                    return d.j ===0;
               }).append("text")
             .text(function(d) { 
              lenn = display_value.get(d.x).length;
             return display_value.get(d.x);
             
           }).attr("x", y_axis_pos)
           .attr("y", 0)
           .attr("dy", ".75em")
           .attr("text-anchor", "middle")
           .style("font-size", cell_font_sz)
           

           cell.filter(function(d) {
            return (d.j === 0 && d.i === d.j);
       }).append("text")
   .attr("x", right_text_x)
  .attr("y", size*(-1))
   .attr("dx", dx_x)
   .text(function(d) { 
     return display_value.get(d.x); 
   })
   .attr("transform","rotate(90)")
   .attr("dominant-baseline","middle")
   .attr("text-anchor", "middle")
   .style("font-size", cell_font_sz);

   cell.filter(function(d) {
    return (d.j === 1 && d.i === d.j);
   }).append("text")
   .attr("x", right_text_x)
   .attr("y",size*(-2))
  .attr("dx", dx_x)
 .text(function(d) { 
  return display_value.get(d.x); 
  })
  .attr("transform","rotate(90)")
  .attr("dominant-baseline","middle")
  .attr("text-anchor", "middle")
  .style("font-size", cell_font_sz);

   cell.filter(function(d) {
   return (d.j === 2 && d.i === d.j);
   }).append("text")
   .attr("x", right_text_x)
   .attr("y",size*(-3))
   //    .attr("y", padding)
  .attr("dx", dx_x)
 .text(function(d) { 
  return display_value.get(d.x); 
  })
  .attr("transform","rotate(90)")
  .attr("dominant-baseline","middle")
  .attr("text-anchor", "middle")
  .style("font-size", cell_font_sz);


  cell.filter(function(d) {
  return (d.j === 3 && d.i === d.j);
  }).append("text")
  .attr("x", right_text_x)
  .attr("y",size*(-4))
 .attr("dx", dx_x)
.text(function(d) { 
 return display_value.get(d.x); 
 })
 .attr("transform","rotate(90)")
 .attr("dominant-baseline","middle")
 .attr("text-anchor", "middle")
 .style("font-size", cell_font_sz);

 cell.filter(function(d) {
return (d.j === 4 && d.i === d.j);
}).append("text")
.attr("x", right_text_x)
   .attr("y",size*(-5))
  .attr("dx", dx_x)
 .text(function(d) { 
  return display_value.get(d.x); 
  })
  .attr("transform","rotate(90)")
  .attr("dominant-baseline","middle")
  .attr("text-anchor", "middle")
  .style("font-size", cell_font_sz);
   

    //         // Titles for the diagonal.
    //     cell.filter(function(d) {
    //        return d.i === d.j; 
    //       }).append("text")
    //     .attr("x", padding)
    //     .attr("y", 0)
    // //    .attr("y", padding)
    //     .attr("dy", ".71em")
    //     .text(function(d) { 
    //       return display_value.get(d.x); 
    //     });
      
        function plot(p) {
          var cell = d3.select(this);
      
          x.domain(domainByTrait[p.x]);
          y.domain(domainByTrait[p.y]);
      
          cell.append("rect")
              .attr("class", "frame")
              .attr("x", padding / 2)
              .attr("y", padding / 2)
              .attr("width", size - padding)
              .attr("height", size - padding);
        
              

          cell.selectAll("circle")
              .data(oData)
            .enter().append("circle")
            .attr("data-row", function(d) {
              return d.row;
          })
              .attr("cx", function(d) { 
           //     if(!isNaN(d[p.x])){
         //   console.log(d[p.x])
                  if(d[p.x]){
                    
                  return x(d[p.x]); 
                } else if(d[p.x] === 0){
                  return x(d[p.x]); 
                } else 
                return null; })
              .attr("cy", function(d) { 
            //    console.log(d[p.y])
                if(d[p.y]){
               
                  return y(d[p.y]);
                } else if(d[p.y] === 0){
                  return y(d[p.y]);
                }
                else 
                return null; })
              .attr("r", radius)
              .style("fill", function(d) { 
                if(d[p.x] && d[p.y]){
                  return d.color; 
                } else if((d[p.x] === 0 && d[p.y] === 0)){
                  return d.color;
                } else if(d[p.x] || d[p.y]){
                  if((d[p.x] === 0 || d[p.y] === 0))
                    { 
                    return d.color; 
                    }  else return '#ffffff00' }
                      else return '#ffffff00';
                
                
               

                // if(d[p.x] && d[p.y]){
                //   return d.color; 
                // } else if(d[p.x] || d[p.y])
                //   {
                //   if((d[p.x] === 0 || d[p.y] === 0))
                //     { 
                //     return d.color; 
                 
                // } else if((d[p.x] === 0 && d[p.y] === 0)){
                //   return d.color;
                // }
                // else if(!d[p.x] || !d[p.y]){
                //   return '#ffffff00';
                // }
                   
                // } 
                // else return '#ffffff00';
             

            } 
          )
              .on("mouseover", function(d) {
                return tooltip.style("display", "none").html(tooltipContent(d));
            })
            .on("mousemove", function(d) {
               var  event = d3.event;
                tooltipContent(d);
              return tooltip.style("top", (event.pageY - 20) + "px").style("left", (event.pageX + 10)+ "px");
            })
            .on("mouseout", function(d) {
                return tooltip.style("display", "none");
                
            })
            .on("click", function(d, i){         
              var event = d3.event;    
              event.preventDefault();
              event.stopPropagation();
              var oMarkingService = oViz.getMarkingService();
              if(!event.ctrlKey) {                
                oMarkingService.clearMarksForDataLayout(oDataLayout);
              }
              oMarkingService.setMark(oDataLayout, datamodelshapes.Physical.DATA, parseInt(d.row), 0);

              $(this).addClass("scattermark");   
              $("circle[data-row='"+ d.row +"']").addClass("scattermark");
       //      oViz._publishMarkEvent(oDataLayout);
              tooltip.style("display", "none");
          })
          .on("contextmenu", function (d, i) {
            var event = d3.event;
            event.preventDefault();
            var oMarkingService = oViz.getMarkingService();
            oMarkingService.setMark(oDataLayout, datamodelshapes.Physical.DATA, parseInt(d.row), 0);
            oViz._publishMarkEvent(oDataLayout);  
            $("circle").removeClass("scattermark");
            $(this).addClass("scattermark");          
            $("circle[data-row='"+ d.row +"']").addClass("scattermark");                       
            tooltip.style("display", "none");
        });
        }
      
      function cross(a, b) {
        var c = [], n = a.length, m = b.length, i, j;
        for (i = -1; ++i < n;) for (j = -1; ++j < m;) c.push({x: a[i], i: i, y: b[j], j: j});
        return c;
      }
      
      if(this.getLegendOption() === "On" && oData[0].col_name != undefined){
        addLegendPane();
      }
     

      function addLegendPane(){
          
         var legend_data = [];
         var legend_color = [];
          var legendVals = d3.set(oData.map(function (d) {
            if(!legend_data.includes(d.col_name)){
              legend_data.push(d.col_name)
            }
                  legend_color.push(d.color);              
                  return legend_data;
               }));
          
               var legendHeight = 20 * legend_data.length;
               var legendMaxHt = height * 0.6;
               var marginOffset = 25;
              var legendMarginTop = 100;
           //    legendMarginTop = legendMaxHt >= legendHeight ? ((legendMaxHt-legendHeight)/2)+marginOffset : marginOffset;
          
          var ellegend = document.createElement("div");
          
        var ellegenddiv =  d3.select("#legend2_"+cId)[0][0];
        ellegend.style.display = "grid";

          var svgLegend = d3.select("#legend2_"+cId).append("svg")
          .attr("width", 110)
          .attr("height", legendHeight)
          .attr("max-height",legendMaxHt)
          ;
          
          
          var legendN2 = svgLegend.selectAll("#legend2_"+cId)
          .data(legend_data)
          .enter().append('g')
          .attr("transform", function (d, i) {
              return "translate(0," + i * 20 + ")";
          });
          

          legendN2.append('rect')
                         .attr("x", 0)
                          .attr("y", 0)
                          .attr("width",10)
                          .attr("height",10)
                          .style("fill", function (d) {
                              return color_map[d];
                          });
                  
                          
                   legendN2.append('text')
                        .attr("x", 20)
                          .attr("y", 10)
                          .text(function (d, i) {
                                if(d != undefined){
                                  var t_len = d.length;
                                  if(t_len>13){
                                         d = d.substring(0,11) + "...";
                                  }
                                   return d;
                                }
                           

                          })
                          .attr("class", "textselected")
                          .style("text-anchor", "start")
                          .style("font-size", 10);
                 
                          $("#legend2_"+cId).css("max-height", legendMaxHt);
                          ellegend.appendChild(legendN2[0].parentNode);
                          ellegenddiv.appendChild(ellegend);  

      }

     
}
finally {
   this._setIsRendered(true);
}
};

ScatterPlotMatrix.prototype.getDataCountsLabel = function (oTransientVizContext, oTransientRenderingContext) {
// This will show 100 in that section
return "100 points";
};

ScatterPlotMatrix.prototype.resizeVisualization = function(oVizDimensions, oTransientVizContext){
var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
this.render(oTransientRenderingContext);
};

ScatterPlotMatrix.prototype._onDefaultSettingsChanged = function(){
  
var oTransientVizContext = this.assertOrCreateVizContext();
var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
this.render(oTransientRenderingContext);
this._setIsRendered(true);
};

ScatterPlotMatrix.prototype._publishMarkEvent = function (oDataLayout, eMarkContext) {

try {

// Create the marking event
var markingEvent = new interactions.MarkingEvent(this.getID(), this.getViewName(), oDataLayout, null, eMarkContext);
var eventRouter = this.getEventRouter();
if (eventRouter) {
    // Publish the event to listeners
    eventRouter.publish(markingEvent);
}
}
catch (e) {
console.log("Error during mark", e);
}
};

/**
   * Override to add in options to the context menu
   *
   * @param {module:obitech-report/vizcontext#VizContext} oTransientVizContext the viz context
   * @param {string} sMenuType The menu type associated with the context menu being populated
   * @param {Array} The array of resulting menu options
   * @param {module:obitech-appservices/contextmenu} contextmenu The contextmenu namespace object (used to reduce dependencies)
   * @param {object} evtParams The entire 'params' object that is extracted from client evt
   * @param {object} oTransientRenderingContext the current transient rendering context
   */

ScatterPlotMatrix.prototype._addVizSpecificMenuOptions = function(oTransientVizContext, sMenuType, aResults, contextmenu, evtParams, oTransientRenderingContext){
aResults.shift();

ScatterPlotMatrix.superClass._addVizSpecificMenuOptions.call(this, oTransientVizContext, sMenuType, aResults, contextmenu, evtParams, oTransientRenderingContext);
if (sMenuType === euidef.CM_TYPE_VIZ_PROPS) {

// Set up the column context for the last column in the ROWS bucket
var oColumnContext = this.getDrillPathColumnContext(oTransientVizContext, datamodelshapes.Logical.ROW);

// Set up events
    if(!this.isViewOnlyLimit()){
        
  //       this._addFilterMenuOption(oTransientVizContext, aResults, null, null, oTransientRenderingContext);
   //     this._addRemoveSelectedMenuOption(oTransientVizContext, aResults, null, null, oTransientRenderingContext);
    }

}
};

ScatterPlotMatrix.prototype._addVizSpecificPropsDialog = function (oTabbedPanelsGadgetInfo) {
  
this.doAddVizSpecificPropsDialog(this, oTabbedPanelsGadgetInfo);
ScatterPlotMatrix.superClass._addVizSpecificPropsDialog.call(this, oTabbedPanelsGadgetInfo);

};

/**
   * TODO: Legend should take care of this
   * Given an options / config object, configure it with default options for the visualization.
   *
   * @param {object} oOptions the options
   * @param {module:obitech-framework/actioncontext#ActionContext} oActionContext The ActionContext instance associated with this action
   * @protected
   */


ScatterPlotMatrix.prototype.doAddVizSpecificPropsDialog = function (oTransientRenderingContext, oTabbedPanelsGadgetInfo) {

jsx.assertObject(oTransientRenderingContext, "oTransientRenderingContext");
jsx.assertInstanceOf(oTabbedPanelsGadgetInfo, gadgets.TabbedPanelsGadgetInfo, "oTabbedPanelsGadgetInfo", "obitech-application/gadgets.TabbedPanelsGadgetInfo");

var oDataModel = this.getRootDataModel();

this.setTabInfo(oTabbedPanelsGadgetInfo);
var viewConfig = this.getViewConfig() || {};
var options = this.getViewConfig() || {};
this._fillDefaultOptions(options, null);
var generalPanel = gadgetdialog.forcePanelByID(oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_GENERAL);

var oGadgetFactory = this.getGadgetFactory();


var Gridlines = [];
Gridlines.push(new gadgets.OptionInfo('On','On'));
Gridlines.push(new gadgets.OptionInfo('Off','Off'));                      
var oGridlinesTypeGVP = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.Gridlines);
var oGridlinesTypeGadgetInfo = new gadgets.TextSwitcherGadgetInfo("GridlinesTypeGadget", 'Gridlines', 'Gridlines', oGridlinesTypeGVP, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE + 1, false, Gridlines);
generalPanel.addChild(oGridlinesTypeGadgetInfo);

var oSizeValueProperties = new gadgets.SliderGadgetValueProperties(euidef.GadgetTypeIDs.SLIDER, this.getSize(),1,20);
var oSizeFieldGadgetInfo = new gadgets.SliderGadgetInfo("SizeGadget", 'Dot Size','Dot Size',  oSizeValueProperties);
generalPanel.addChild(oSizeFieldGadgetInfo);

var legendOption = [];
      legendOption.push(new gadgets.OptionInfo('On','On'));
      legendOption.push(new gadgets.OptionInfo('Off','Off'));

      var oLegendOptionTypeGVP = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.legendOption);
      var oLegendOptionTypeGadgetInfo = new gadgets.TextSwitcherGadgetInfo("legendOptionTypeGadget", 'Legends', 'Legends', oLegendOptionTypeGVP, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE, false, legendOption);
      generalPanel.addChild(oLegendOptionTypeGadgetInfo);


if (ScatterPlotMatrix.superClass.doAddVizSpecificPropsDialog)
ScatterPlotMatrix.superClass.doAddVizSpecificPropsDialog.apply(this, arguments);
};

ScatterPlotMatrix.prototype._handlePropChange = function (sGadgetID, oPropChange, oViewSettings, oActionContext){
   
var updateSettings = ScatterPlotMatrix.superClass._handlePropChange.call(this, sGadgetID, oPropChange, oViewSettings, oActionContext);
if (updateSettings) {
return updateSettings; // super handled it
}
var conf = oViewSettings.getViewConfigJSON(dataviz.SettingsNS.CHART) || {};

                        if (sGadgetID === "GridlinesTypeGadget")
                            {
                                if (jsx.isNull(conf.styleDefaults))
                                {
                                    conf.styleDefaults = {};
                                }
               
                                this.setGridlines(oPropChange.value);
                                updateSettings = true;
                            }

                            if (sGadgetID === "SizeGadget")
                              {
                                 if (jsx.isNull(conf.styleDefaults))
                                 {
                                    conf.styleDefaults = {};
                                 }
                                 this.setSize(oPropChange.value);
                                 updateSettings = true;
                              }

                              if (sGadgetID === "legendOptionTypeGadget")
                                {
                                    if (jsx.isNull(conf.styleDefaults))
                                    {
                                        conf.styleDefaults = {};
                                    }
                    
                                    this.setLegendOption(oPropChange.value);
                                    updateSettings = true;
                                }

return updateSettings;
};

ScatterPlotMatrix.prototype._buildSelectedItems = function(oTransientRenderingContext){

var oViz = this;
var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
var oMarkingService = oViz.getMarkingService();

function fMarksReadyCallback() {
oViz.clearSelectedItems();
var aSelectedItems = oViz.getSelectedItems();

if(!oViz.isStarted()) {
    return;
}
oMarkingService.traverseDataEdgeMarks(oDataLayout, function (nRow, nCol) {
    aSelectedItems.set(nRow, nCol);
});
$("circle").removeClass("scattermark");
for(let row of aSelectedItems.keys()){
 $("circle[data-row='"+ row +"']").addClass("scattermark");
}
}
oMarkingService.getUpdatedMarkingSet(oDataLayout, marking.EMarkOperation.MARK_RELATED, fMarksReadyCallback);
};

ScatterPlotMatrix.prototype.onHighlight = function(){
var oTransientVizContext = this.assertOrCreateVizContext();
var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
//  this._buildSelectedItems(oTransientRenderingContext);
};

ScatterPlotMatrix.prototype._onDefaultColorsSettingsChange = function(/*oClientEvent*/){
var oTransientVizContext = this.createVizContext();
if(!this._handleVizPlaceholderState(oTransientVizContext)){
//this.readyForData({aEventTriggers:[DEFAULT_COLOR_SETTINGS_CHANGED_EVENT_TRIGGER]});
var oTransientVizContext = this.assertOrCreateVizContext();
var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
this.render(oTransientRenderingContext);
}
};

ScatterPlotMatrix.prototype._doInitializeComponent = function() {
  
ScatterPlotMatrix.superClass._doInitializeComponent.call(this);

this.subscribeToEvent(events.types.INTERACTION_HIGHLIGHT, this.onHighlight, this.getViewName() + "." + events.types.INTERACTION_HIGHLIGHT);
this.subscribeToEvent(events.types.DEFAULT_COLOR_SETTINGS_CHANGED, this._onDefaultColorsSettingsChange, "**");

};

/**
* Factory method declared in the plugin configuration
* @param {string} sID Component ID for the visualization
* @param {string=} sDisplayName Component display name
* @param {string=} sOrigin Component host identifier
* @param {string=} sVersion 
* @returns {module:com-company-scatterplotmatrix/scatterPlotMatrix.ScatterPlotMatrix}
* @memberof module:com-company-scatterplotmatrix/scatterPlotMatrix
*/
function createClientComponent(sID, sDisplayName, sOrigin) {
// Argument validation done by base class
return new ScatterPlotMatrix(sID, sDisplayName, sOrigin, ScatterPlotMatrix.VERSION);
};

return {
createClientComponent : createClientComponent
};
});